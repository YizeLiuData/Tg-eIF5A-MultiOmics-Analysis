#!/usr/bin/env python3


from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import zipfile
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence
import xml.etree.ElementTree as ET

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import Circle


XML_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
REL_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PKG_REL_NS = "{http://schemas.openxmlformats.org/package/2006/relationships}"

SOURCE_SHEET = "图中gene主表"
VALIDATION_SHEET = "WTTEST_QCTR共同APR"
FIELD_SHEET = "字段说明"

GENE_ID = "gene_id"
GENE_NAME = "gene_name"
DESCRIPTION = "description"
WT_FLAG = "WT_TEST_严格APR"
Q_FLAG = "Q_CTR_严格APR"
WT_PLOTTED = "WT_TEST_入图"
Q_PLOTTED = "Q_CTR_入图"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def cell_value(cell: ET.Element) -> str:
    if cell.attrib.get("t") == "inlineStr":
        return "".join((node.text or "") for node in cell.iter(XML_NS + "t"))
    value = cell.find(XML_NS + "v")
    return "" if value is None else (value.text or "")


def cell_column(reference: str) -> str:
    match = re.match(r"([A-Z]+)", reference)
    if not match:
        raise ValueError(f"Invalid cell reference: {reference}")
    return match.group(1)


def workbook_sheet_paths(archive: zipfile.ZipFile) -> Dict[str, str]:
    workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    targets = {
        rel.attrib["Id"]: rel.attrib["Target"].lstrip("/")
        for rel in relationships.findall(PKG_REL_NS + "Relationship")
    }
    result: Dict[str, str] = {}
    sheets = workbook.find(XML_NS + "sheets")
    if sheets is None:
        raise ValueError("Workbook contains no worksheets")
    for sheet in sheets:
        rel_id = sheet.attrib[REL_NS + "id"]
        target = targets[rel_id]
        if not target.startswith("xl/"):
            target = "xl/" + target
        result[sheet.attrib["name"]] = target
    return result


def read_sheet_rows(
    archive: zipfile.ZipFile, sheet_path: str
) -> Iterable[Dict[str, str]]:
    headers: Dict[str, str] | None = None
    for _, element in ET.iterparse(archive.open(sheet_path), events=("end",)):
        if element.tag != XML_NS + "row":
            continue
        by_column = {
            cell_column(cell.attrib["r"]): cell_value(cell)
            for cell in element.findall(XML_NS + "c")
        }
        if headers is None:
            headers = by_column
        else:
            yield {
                header: by_column.get(column, "")
                for column, header in headers.items()
                if header
            }
        element.clear()


def read_sheet(path: Path, sheet_name: str) -> List[Dict[str, str]]:
    with zipfile.ZipFile(path) as archive:
        sheets = workbook_sheet_paths(archive)
        if sheet_name not in sheets:
            raise ValueError(f"Required worksheet not found: {sheet_name}")
        return list(read_sheet_rows(archive, sheets[sheet_name]))


def write_csv(path: Path, rows: Sequence[Mapping[str, object]], fields: Sequence[str]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def overlap_area(r1: float, r2: float, distance: float) -> float:
    if distance >= r1 + r2:
        return 0.0
    if distance <= abs(r1 - r2):
        return math.pi * min(r1, r2) ** 2
    a1 = math.acos((distance**2 + r1**2 - r2**2) / (2 * distance * r1))
    a2 = math.acos((distance**2 + r2**2 - r1**2) / (2 * distance * r2))
    radical = (
        (-distance + r1 + r2)
        * (distance + r1 - r2)
        * (distance - r1 + r2)
        * (distance + r1 + r2)
    )
    return r1**2 * a1 + r2**2 * a2 - 0.5 * math.sqrt(max(0.0, radical))


def solve_distance(r1: float, r2: float, target_overlap: float) -> float:
    low = abs(r1 - r2)
    high = r1 + r2
    if target_overlap >= math.pi * min(r1, r2) ** 2:
        return low
    if target_overlap <= 0:
        return high
    for _ in range(100):
        mid = (low + high) / 2
        if overlap_area(r1, r2, mid) > target_overlap:
            low = mid
        else:
            high = mid
    return (low + high) / 2


def draw_venn(counts: Mapping[str, int], output_dir: Path) -> None:
    wt_total = counts["wt_total"]
    q_total = counts["q_total"]
    both = counts["intersection"]
    wt_only = counts["wt_only"]
    q_only = counts["q_only"]

    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 6.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "axes.linewidth": 0.6,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
        }
    )

    
    q_radius = 1.0
    wt_radius = math.sqrt(wt_total / q_total)
    target_overlap = math.pi * both / q_total
    distance = solve_distance(wt_radius, q_radius, target_overlap)

    
    wt_x_raw = 0.0
    q_x_raw = distance
    raw_left = min(wt_x_raw - wt_radius, q_x_raw - q_radius)
    raw_right = max(wt_x_raw + wt_radius, q_x_raw + q_radius)
    scale = 0.68 / (raw_right - raw_left)
    x_offset = 0.50 - scale * (raw_left + raw_right) / 2
    wt_x = x_offset + scale * wt_x_raw
    q_x = x_offset + scale * q_x_raw
    wt_r = scale * wt_radius
    q_r = scale * q_radius
    y = 0.49

    blue = "#0072B2"
    orange = "#E69F00"
    fig = plt.figure(figsize=(89 / 25.4, 89 / 25.4))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_aspect("equal")
    ax.axis("off")

    ax.add_patch(Circle((q_x, y), q_r, facecolor=orange, edgecolor=orange,
                        linewidth=0.8, alpha=0.46, zorder=1))
    ax.add_patch(Circle((wt_x, y), wt_r, facecolor=blue, edgecolor=blue,
                        linewidth=0.8, alpha=0.50, zorder=2))

    
    ax.text(0.08, 0.90, f"WT test / WT ctr\n$n$ = {wt_total}",
            ha="left", va="top", fontsize=7, color="black", linespacing=1.15)
    ax.text(0.92, 0.90, f"Q ctr / WT ctr\n$n$ = {q_total}",
            ha="right", va="top", fontsize=7, color="black", linespacing=1.15)

    
    crescent_x = wt_x - 0.86 * wt_r
    ax.annotate(
        str(wt_only),
        xy=(crescent_x, y + 0.02),
        xytext=(0.13, 0.49),
        ha="center",
        va="center",
        fontsize=7,
        fontweight="bold",
        color="black",
        arrowprops={"arrowstyle": "-", "color": "black", "lw": 0.5},
        zorder=5,
    )
    ax.text(wt_x + 0.05 * wt_r, y, str(both), ha="center", va="center",
            fontsize=7, fontweight="bold", color="black", zorder=5)
    ax.text(q_x + 0.48 * q_r, y, str(q_only), ha="center", va="center",
            fontsize=7, fontweight="bold", color="black", zorder=5)

    ax.text(0.13, 0.39, "WT only", ha="center", va="top", fontsize=5.5, color="black")
    ax.text(wt_x + 0.05 * wt_r, y - 0.07, "Shared", ha="center", va="top",
            fontsize=5.5, color="black")
    ax.text(q_x + 0.48 * q_r, y - 0.07, "Q only", ha="center", va="top",
            fontsize=5.5, color="black")
    ax.text(0.50, 0.075, "Area proportional to set size", ha="center", va="center",
            fontsize=5, color="black")

    stem = output_dir / "APR_pause_gene_venn_Nature_1to1"
    fig.savefig(stem.with_suffix(".svg"), format="svg")
    fig.savefig(stem.with_suffix(".pdf"), format="pdf")
    fig.savefig(stem.with_suffix(".png"), format="png", dpi=600)
    fig.savefig(
        stem.with_suffix(".tiff"),
        format="tiff",
        dpi=600,
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    input_path = args.input.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    source_rows = read_sheet(input_path, SOURCE_SHEET)
    required = {GENE_ID, GENE_NAME, DESCRIPTION, WT_FLAG, Q_FLAG, WT_PLOTTED, Q_PLOTTED}
    if not source_rows or not required.issubset(source_rows[0]):
        missing = sorted(required - set(source_rows[0] if source_rows else []))
        raise ValueError(f"Missing required columns: {missing}")

    gene_ids = [row[GENE_ID].strip() for row in source_rows]
    if any(not gene_id for gene_id in gene_ids):
        raise ValueError("Blank gene_id found in source worksheet")
    if len(gene_ids) != len(set(gene_ids)):
        raise ValueError("gene_id is not unique in source worksheet")

    for flag in (WT_FLAG, Q_FLAG, WT_PLOTTED, Q_PLOTTED):
        observed = {row[flag] for row in source_rows}
        if not observed.issubset({"是", "否"}):
            raise ValueError(f"Unexpected values in {flag}: {sorted(observed)}")

    wt_ids = {row[GENE_ID] for row in source_rows if row[WT_FLAG] == "是"}
    q_ids = {row[GENE_ID] for row in source_rows if row[Q_FLAG] == "是"}
    shared_ids = wt_ids & q_ids
    if any(row[WT_FLAG] == "是" and row[WT_PLOTTED] != "是" for row in source_rows):
        raise ValueError("WT strict-APR gene found outside WT plotted set")
    if any(row[Q_FLAG] == "是" and row[Q_PLOTTED] != "是" for row in source_rows):
        raise ValueError("Q strict-APR gene found outside Q plotted set")

    validation_ids = {row[GENE_ID] for row in read_sheet(input_path, VALIDATION_SHEET)}
    if shared_ids != validation_ids:
        raise ValueError(
            "Intersection does not match validation worksheet "
            f"(intersection={len(shared_ids)}, validation={len(validation_ids)})"
        )

    fields = read_sheet(input_path, FIELD_SHEET)
    definitions = {
        row.get("字段", ""): row.get("说明", "")
        for row in fields
        if row.get("字段") in {WT_FLAG, Q_FLAG}
    }
    if set(definitions) != {WT_FLAG, Q_FLAG}:
        raise ValueError("Strict-APR field definitions are incomplete")

    tidy_rows: List[Dict[str, object]] = []
    for row in source_rows:
        gene_id = row[GENE_ID]
        in_wt = gene_id in wt_ids
        in_q = gene_id in q_ids
        if not (in_wt or in_q):
            continue
        membership = "Shared" if in_wt and in_q else ("WT only" if in_wt else "Q only")
        tidy_rows.append(
            {
                "gene_id": gene_id,
                "gene_name": row[GENE_NAME],
                "description": row[DESCRIPTION],
                "wt_test_vs_wt_ctr_pause": in_wt,
                "q_ctr_vs_wt_ctr_pause": in_q,
                "membership": membership,
            }
        )
    tidy_rows.sort(key=lambda row: (str(row["membership"]), str(row["gene_id"])))

    source_fields = [
        "gene_id",
        "gene_name",
        "description",
        "wt_test_vs_wt_ctr_pause",
        "q_ctr_vs_wt_ctr_pause",
        "membership",
    ]
    write_csv(output_dir / "APR_pause_gene_venn_source_data.csv", tidy_rows, source_fields)
    write_csv(
        output_dir / "WT_test_vs_WT_ctr_pause_genes.csv",
        [row for row in tidy_rows if row["wt_test_vs_wt_ctr_pause"]],
        source_fields,
    )
    write_csv(
        output_dir / "Q_ctr_vs_WT_ctr_pause_genes.csv",
        [row for row in tidy_rows if row["q_ctr_vs_wt_ctr_pause"]],
        source_fields,
    )
    write_csv(
        output_dir / "shared_pause_genes.csv",
        [row for row in tidy_rows if row["membership"] == "Shared"],
        source_fields,
    )

    counts = {
        "wt_total": len(wt_ids),
        "q_total": len(q_ids),
        "intersection": len(shared_ids),
        "wt_only": len(wt_ids - q_ids),
        "q_only": len(q_ids - wt_ids),
        "union": len(wt_ids | q_ids),
    }
    write_csv(
        output_dir / "APR_pause_gene_venn_counts.csv",
        [
            {"region": "WT test vs WT ctr total", "n": counts["wt_total"]},
            {"region": "Q ctr vs WT ctr total", "n": counts["q_total"]},
            {"region": "WT only", "n": counts["wt_only"]},
            {"region": "Shared", "n": counts["intersection"]},
            {"region": "Q only", "n": counts["q_only"]},
            {"region": "Union", "n": counts["union"]},
        ],
        ["region", "n"],
    )
    draw_venn(counts, output_dir)

    qc = {
        "input_file": input_path.name,
        "input_sha256": sha256(input_path),
        "source_sheet": SOURCE_SHEET,
        "gene_key": GENE_ID,
        "source_rows": len(source_rows),
        "set_columns": {"WT": WT_FLAG, "Q": Q_FLAG},
        "field_definitions": definitions,
        "counts": counts,
        "validation_sheet": VALIDATION_SHEET,
        "validation_exact_match": True,
        "figure_size_mm": [89, 89],
        "area_proportional": True,
    }
    (output_dir / "APR_pause_gene_venn_QC.json").write_text(
        json.dumps(qc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(qc, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
