#!/usr/bin/env python3


from __future__ import annotations

import argparse
import itertools
import math
import shutil
import textwrap
from collections import OrderedDict
from datetime import datetime
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import gridspec
from matplotlib.colors import TwoSlopeNorm
from scipy import stats
from scipy.cluster import hierarchy
from scipy.spatial.distance import squareform


STOP_CODONS = ["TAA", "TAG", "TGA"]
GROUP_ORDER = ["WT_ctr", "WT_test", "R_ctr", "R_test", "Q_ctr", "Q_test"]
GENOTYPES = ["WT", "R", "Q"]
CONDITIONS = ["ctr", "test"]
VERSION_DEFAULT = "v1.2"

SAMPLE_ORDER = [
    "wt_ctr1",
    "wt_ctr2",
    "wt_ctr3",
    "wt_test1",
    "wt_test2",
    "wt_test3",
    "R_ctr1",
    "R_ctr2",
    "R_ctr3",
    "R_test1",
    "R_test2",
    "R_test3",
    "Q_ctr1",
    "Q_ctr2",
    "Q_ctr3",
    "Q_test1",
    "Q_test2",
    "Q_test3",
]

GROUPS = OrderedDict(
    [
        ("WT_ctr", ["wt_ctr1", "wt_ctr2", "wt_ctr3"]),
        ("WT_test", ["wt_test1", "wt_test2", "wt_test3"]),
        ("R_ctr", ["R_ctr1", "R_ctr2", "R_ctr3"]),
        ("R_test", ["R_test1", "R_test2", "R_test3"]),
        ("Q_ctr", ["Q_ctr1", "Q_ctr2", "Q_ctr3"]),
        ("Q_test", ["Q_test1", "Q_test2", "Q_test3"]),
    ]
)

GROUP_COLORS = {
    "WT_ctr": "#9ecae1",
    "WT_test": "#08519c",
    "R_ctr": "#a1d99b",
    "R_test": "#006d2c",
    "Q_ctr": "#fdae6b",
    "Q_test": "#a63603",
}

GENOTYPE_COLORS = {"WT": "#08519c", "R": "#006d2c", "Q": "#a63603"}
CONDITION_MARKERS = {"ctr": "o", "test": "s"}
FEATURE_COLORS = {"ATG": "#d62728", "GAA": "#1f77b4", "GAG": "#17becf"}

AA3 = {
    "A": "Ala",
    "R": "Arg",
    "N": "Asn",
    "D": "Asp",
    "C": "Cys",
    "Q": "Gln",
    "E": "Glu",
    "G": "Gly",
    "H": "His",
    "I": "Ile",
    "L": "Leu",
    "K": "Lys",
    "M": "Met",
    "F": "Phe",
    "P": "Pro",
    "S": "Ser",
    "T": "Thr",
    "W": "Trp",
    "Y": "Tyr",
    "V": "Val",
    "*": "Stop",
}

CODON_TO_AA1 = {
    "TTT": "F",
    "TTC": "F",
    "TTA": "L",
    "TTG": "L",
    "TCT": "S",
    "TCC": "S",
    "TCA": "S",
    "TCG": "S",
    "TAT": "Y",
    "TAC": "Y",
    "TAA": "*",
    "TAG": "*",
    "TGT": "C",
    "TGC": "C",
    "TGA": "*",
    "TGG": "W",
    "CTT": "L",
    "CTC": "L",
    "CTA": "L",
    "CTG": "L",
    "CCT": "P",
    "CCC": "P",
    "CCA": "P",
    "CCG": "P",
    "CAT": "H",
    "CAC": "H",
    "CAA": "Q",
    "CAG": "Q",
    "CGT": "R",
    "CGC": "R",
    "CGA": "R",
    "CGG": "R",
    "ATT": "I",
    "ATC": "I",
    "ATA": "I",
    "ATG": "M",
    "ACT": "T",
    "ACC": "T",
    "ACA": "T",
    "ACG": "T",
    "AAT": "N",
    "AAC": "N",
    "AAA": "K",
    "AAG": "K",
    "AGT": "S",
    "AGC": "S",
    "AGA": "R",
    "AGG": "R",
    "GTT": "V",
    "GTC": "V",
    "GTA": "V",
    "GTG": "V",
    "GCT": "A",
    "GCC": "A",
    "GCA": "A",
    "GCG": "A",
    "GAT": "D",
    "GAC": "D",
    "GAA": "E",
    "GAG": "E",
    "GGT": "G",
    "GGC": "G",
    "GGA": "G",
    "GGG": "G",
}

AA_ORDER = [
    "Met",
    "Glu",
    "Gly",
    "Asp",
    "Lys",
    "Asn",
    "Leu",
    "Ser",
    "Arg",
    "Val",
    "Ala",
    "Thr",
    "Ile",
    "Pro",
    "Gln",
    "His",
    "Phe",
    "Tyr",
    "Cys",
    "Trp",
]

KEY_CODONS = ["ATG", "GAA", "GAG", "GAC", "GAT", "AAG", "AAC", "GGA"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", default=".", help="Directory with codon64 TSV files")
    parser.add_argument("--out", default="codon64_analysis_v1.2", help="Output directory")
    parser.add_argument("--version", default=VERSION_DEFAULT, help="Version suffix for outputs")
    return parser.parse_args()


def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def setup_output(out_arg: str) -> tuple[Path, dict[str, Path]]:
    out = Path(out_arg)
    if out.exists():
        entries = [p.name for p in out.iterdir()]
        allowed_skeleton = set(entries).issubset({"scripts"})
        if not allowed_skeleton:
            out = out.with_name(f"{out.name}_{timestamp()}")
    dirs = {
        "root": out,
        "input": out / "00_input",
        "qc": out / "01_qc",
        "codon": out / "02_codon_summary",
        "atg_gaa": out / "03_ATG_GAA",
        "tests": out / "04_all_codon_tests",
        "aa": out / "05_amino_acid",
        "similarity": out / "06_similarity_state",
        "figures": out / "07_figures",
        "style": out / "07_figures" / "00_style_legend",
        "fig_qc": out / "07_figures" / "01_qc",
        "fig_atg": out / "07_figures" / "02_ATG",
        "fig_gaa": out / "07_figures" / "03_GAA",
        "fig_codon": out / "07_figures" / "04_codon_landscape",
        "fig_aa": out / "07_figures" / "05_amino_acid",
        "fig_similarity": out / "07_figures" / "06_similarity_state",
        "fig_response": out / "07_figures" / "07_R_WT_Q_response",
        "fig_rtest2": out / "07_figures" / "08_Rtest2_diagnostics",
        "fig_assemblies": out / "07_figures" / "09_main_figure_assemblies",
        "fig_supp": out / "07_figures" / "10_supplementary",
        "report": out / "08_report",
        "source": out / "09_figure_source_tables",
        "scripts": out / "scripts",
    }
    for path in dirs.values():
        path.mkdir(parents=True, exist_ok=True)
    return out, dirs


def copy_self_and_inputs(input_dir: Path, dirs: dict[str, Path]) -> None:
    for name in [
        "codon64_raw_counts.tsv",
        "codon64_rpm.tsv",
        "codon64_proportions.tsv",
        "codon64_raw_rpm_proportion.tsv",
    ]:
        shutil.copy2(input_dir / name, dirs["input"] / name)
    this_file = Path(__file__)
    target = dirs["scripts"] / this_file.name
    if this_file.resolve() != target.resolve():
        shutil.copy2(this_file, target)


def sample_metadata() -> pd.DataFrame:
    rows = []
    for sample in SAMPLE_ORDER:
        if sample.startswith("wt_"):
            genotype = "WT"
            rest = sample.replace("wt_", "")
        else:
            genotype = sample.split("_")[0]
            rest = sample.split("_", 1)[1]
        condition = "ctr" if rest.startswith("ctr") else "test"
        replicate = int(rest[-1])
        group = f"{genotype}_{condition}"
        rows.append(
            {
                "sample": sample,
                "genotype": genotype,
                "condition": condition,
                "replicate": replicate,
                "group": group,
                "group_order": GROUP_ORDER.index(group) + 1,
                "sample_order": SAMPLE_ORDER.index(sample) + 1,
            }
        )
    return pd.DataFrame(rows)


def codon_metadata(codons: list[str]) -> pd.DataFrame:
    rows = []
    for codon in codons:
        aa1 = CODON_TO_AA1.get(codon, "?")
        aa3 = AA3.get(aa1, "Unknown")
        rows.append(
            {
                "codon": codon,
                "amino_acid_1letter": aa1,
                "amino_acid": aa3,
                "is_stop": codon in STOP_CODONS,
                "is_sense": codon not in STOP_CODONS,
                "is_key_codon": codon in KEY_CODONS,
            }
        )
    return pd.DataFrame(rows)


def read_inputs(input_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    raw = pd.read_csv(input_dir / "codon64_raw_counts.tsv", sep="\t").set_index("codon")
    rpm = pd.read_csv(input_dir / "codon64_rpm.tsv", sep="\t").set_index("codon")
    prop = pd.read_csv(input_dir / "codon64_proportions.tsv", sep="\t").set_index("codon")
    long = pd.read_csv(input_dir / "codon64_raw_rpm_proportion.tsv", sep="\t")
    return raw, rpm, prop, long


def bh_adjust(pvalues: list[float] | np.ndarray) -> np.ndarray:
    p = np.asarray(pvalues, dtype=float)
    q = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    if valid.sum() == 0:
        return q
    pv = p[valid]
    order = np.argsort(pv)
    ranked = pv[order]
    n = len(ranked)
    adj = ranked * n / np.arange(1, n + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    adj = np.clip(adj, 0, 1)
    out = np.empty_like(pv)
    out[order] = adj
    q[valid] = out
    return q


def safe_ttest_ind(a: np.ndarray, b: np.ndarray) -> tuple[float, float]:
    if np.nanstd(a, ddof=1) == 0 and np.nanstd(b, ddof=1) == 0 and np.nanmean(a) == np.nanmean(b):
        return 0.0, 1.0
    res = stats.ttest_ind(a, b, equal_var=False, nan_policy="omit")
    return float(res.statistic), float(res.pvalue)


def safe_ttest_rel(a: np.ndarray, b: np.ndarray) -> tuple[float, float]:
    diff = np.asarray(a) - np.asarray(b)
    if np.nanstd(diff, ddof=1) == 0:
        return (0.0, 1.0) if np.nanmean(diff) == 0 else (np.inf, 0.0)
    res = stats.ttest_rel(a, b, nan_policy="omit")
    return float(res.statistic), float(res.pvalue)


def safe_1sample_ttest(x: np.ndarray, popmean: float = 0.0) -> tuple[float, float]:
    x = np.asarray(x, dtype=float)
    if np.nanstd(x, ddof=1) == 0:
        return (0.0, 1.0) if np.nanmean(x) == popmean else (np.inf, 0.0)
    res = stats.ttest_1samp(x, popmean=popmean, nan_policy="omit")
    return float(res.statistic), float(res.pvalue)


def mean_ci95(x: np.ndarray) -> tuple[float, float, float]:
    x = np.asarray(x, dtype=float)
    n = np.isfinite(x).sum()
    mean = float(np.nanmean(x))
    if n < 2:
        return mean, np.nan, np.nan
    sem = stats.sem(x, nan_policy="omit")
    margin = stats.t.ppf(0.975, n - 1) * sem
    return mean, float(mean - margin), float(mean + margin)


def welch_ci_diff(test: np.ndarray, ctr: np.ndarray) -> tuple[float, float]:
    test = np.asarray(test, dtype=float)
    ctr = np.asarray(ctr, dtype=float)
    diff = float(np.nanmean(test) - np.nanmean(ctr))
    n1 = np.isfinite(test).sum()
    n0 = np.isfinite(ctr).sum()
    v1 = np.nanvar(test, ddof=1)
    v0 = np.nanvar(ctr, ddof=1)
    se = math.sqrt(v1 / n1 + v0 / n0)
    if se == 0 or not np.isfinite(se):
        return diff, diff
    df_num = (v1 / n1 + v0 / n0) ** 2
    df_den = (v1**2 / (n1**2 * (n1 - 1))) + (v0**2 / (n0**2 * (n0 - 1)))
    df = df_num / df_den if df_den else n1 + n0 - 2
    margin = stats.t.ppf(0.975, df) * se
    return float(diff - margin), float(diff + margin)


def signif_label(p: float) -> str:
    if not np.isfinite(p):
        return "NA"
    if p < 0.0001:
        return "****"
    if p < 0.001:
        return "***"
    if p < 0.01:
        return "**"
    if p < 0.05:
        return "*"
    return "ns"


def fmt_p(p: float) -> str:
    if not np.isfinite(p):
        return "NA"
    if p < 0.001:
        return f"{p:.2e}"
    return f"{p:.4f}".rstrip("0").rstrip(".")


def qc_checks(
    raw: pd.DataFrame, rpm: pd.DataFrame, prop: pd.DataFrame, long: pd.DataFrame, dirs: dict[str, Path]
) -> pd.DataFrame:
    expected_samples = set(SAMPLE_ORDER)
    checks = []

    def add(check: str, passed: bool, observed: str) -> None:
        checks.append({"check": check, "passed": bool(passed), "observed": observed})

    for name, df in [("raw", raw), ("rpm", rpm), ("proportion", prop)]:
        add(f"{name}: 64 codons", df.shape[0] == 64, str(df.shape[0]))
        add(f"{name}: unique codons", df.index.nunique() == df.shape[0], str(df.index.nunique()))
        add(f"{name}: expected 18 samples", set(df.columns) == expected_samples, ",".join(df.columns))
        add(f"{name}: no NA", not df.isna().any().any(), str(int(df.isna().sum().sum())))
        add(f"{name}: no negative", not (df < 0).any().any(), str(int((df < 0).sum().sum())))
    add("long table: 1152 rows", len(long) == 64 * 18, str(len(long)))
    add("long table: expected columns", {"codon", "raw_count", "sample", "RPM", "proportion"}.issubset(long.columns), ",".join(long.columns))

    prop_sums = prop[SAMPLE_ORDER].sum(axis=0)
    rpm_sums = rpm[SAMPLE_ORDER].sum(axis=0)
    add("proportion column sums equal 1", np.allclose(prop_sums, 1.0, atol=1e-10), f"{prop_sums.min():.16g}-{prop_sums.max():.16g}")
    add("RPM column sums equal 1,000,000", np.allclose(rpm_sums, 1_000_000.0, atol=1e-5), f"{rpm_sums.min():.6f}-{rpm_sums.max():.6f}")

    recomputed = raw[SAMPLE_ORDER].div(raw[SAMPLE_ORDER].sum(axis=0), axis=1)
    max_err = float((recomputed - prop[SAMPLE_ORDER]).abs().to_numpy().max())
    add("proportion recomputes from raw count", max_err < 1e-12, f"max_abs_error={max_err:.3e}")

    library = raw[SAMPLE_ORDER].sum(axis=0).rename("library_size").reset_index().rename(columns={"index": "sample"})
    smeta = sample_metadata()
    library = library.merge(smeta, on="sample", how="left").sort_values("sample_order")
    library.to_csv(dirs["qc"] / "library_size.tsv", sep="\t", index=False)

    norm = pd.DataFrame(
        {
            "sample": SAMPLE_ORDER,
            "proportion_sum": prop_sums.loc[SAMPLE_ORDER].values,
            "proportion_sum_error": prop_sums.loc[SAMPLE_ORDER].values - 1.0,
            "rpm_sum": rpm_sums.loc[SAMPLE_ORDER].values,
            "rpm_sum_error": rpm_sums.loc[SAMPLE_ORDER].values - 1_000_000.0,
        }
    ).merge(smeta, on="sample", how="left")
    norm.to_csv(dirs["qc"] / "normalization_sums.tsv", sep="\t", index=False)

    stop = (prop.loc[STOP_CODONS, SAMPLE_ORDER] * 100).T
    stop = stop.reset_index().rename(columns={"index": "sample"}).merge(smeta, on="sample", how="left")
    stop["stop_total_percent"] = stop[STOP_CODONS].sum(axis=1)
    stop.to_csv(dirs["qc"] / "stop_codon_qc.tsv", sep="\t", index=False)

    checks_df = pd.DataFrame(checks)
    checks_df.to_csv(dirs["qc"] / "qc_checks.tsv", sep="\t", index=False)
    if not checks_df["passed"].all():
        failed = checks_df.loc[~checks_df["passed"], "check"].tolist()
        raise RuntimeError(f"Critical QC checks failed: {failed}")
    return checks_df


def build_long_table(raw: pd.DataFrame, rpm: pd.DataFrame, prop: pd.DataFrame, dirs: dict[str, Path]) -> pd.DataFrame:
    smeta = sample_metadata()
    cmeta = codon_metadata(list(prop.index))
    rows = []
    for codon in prop.index:
        for sample in SAMPLE_ORDER:
            rows.append(
                {
                    "sample": sample,
                    "codon": codon,
                    "raw_count": int(raw.loc[codon, sample]),
                    "rpm": float(rpm.loc[codon, sample]),
                    "proportion": float(prop.loc[codon, sample]),
                    "percent": float(prop.loc[codon, sample] * 100.0),
                }
            )
    long = pd.DataFrame(rows).merge(smeta, on="sample", how="left").merge(cmeta, on="codon", how="left")
    long = long[
        [
            "sample",
            "genotype",
            "condition",
            "replicate",
            "group",
            "sample_order",
            "codon",
            "amino_acid",
            "amino_acid_1letter",
            "is_stop",
            "raw_count",
            "rpm",
            "proportion",
            "percent",
        ]
    ].sort_values(["sample_order", "codon"])
    long.to_csv(dirs["codon"] / "codon_sample_percent.tsv", sep="\t", index=False)
    smeta.to_csv(dirs["codon"] / "sample_metadata.tsv", sep="\t", index=False)
    cmeta.to_csv(dirs["codon"] / "codon_metadata.tsv", sep="\t", index=False)
    return long


def compute_codon_stats(prop: pd.DataFrame, dirs: dict[str, Path]) -> dict[str, pd.DataFrame]:
    cmeta = codon_metadata(list(prop.index))
    rank_df = prop[SAMPLE_ORDER].rank(axis=0, method="min", ascending=False).astype(int)
    rank_long = (
        rank_df.reset_index()
        .melt(id_vars="codon", var_name="sample", value_name="rank")
        .merge(sample_metadata(), on="sample", how="left")
        .merge(cmeta, on="codon", how="left")
        .sort_values(["sample_order", "rank"])
    )
    rank_long.to_csv(dirs["codon"] / "codon_rank_each_sample.tsv", sep="\t", index=False)

    group_rows = []
    for codon in prop.index:
        for group, samples in GROUPS.items():
            values = prop.loc[codon, samples].to_numpy(dtype=float) * 100.0
            mean, ci_low, ci_high = mean_ci95(values)
            sd = float(np.std(values, ddof=1))
            sem = float(stats.sem(values))
            cv = float(sd / mean) if mean else np.nan
            group_rows.append(
                {
                    "codon": codon,
                    "group": group,
                    "genotype": group.split("_")[0],
                    "condition": group.split("_")[1],
                    "n": len(values),
                    "mean_percent": mean,
                    "sd_percent": sd,
                    "sem_percent": sem,
                    "ci95_low_percent": ci_low,
                    "ci95_high_percent": ci_high,
                    "cv": cv,
                    "min_percent": float(np.min(values)),
                    "max_percent": float(np.max(values)),
                    "mean_rank": float(rank_df.loc[codon, samples].mean()),
                }
            )
    group_stats = pd.DataFrame(group_rows).merge(cmeta, on="codon", how="left")
    group_stats.to_csv(dirs["codon"] / "codon_group_mean_sd.tsv", sep="\t", index=False)

    test_rows = []
    paired_rows = []
    delta_compare_rows = []
    for codon in prop.index:
        for genotype in GENOTYPES:
            ctr_samples = GROUPS[f"{genotype}_ctr"]
            test_samples = GROUPS[f"{genotype}_test"]
            ctr = prop.loc[codon, ctr_samples].to_numpy(dtype=float)
            test = prop.loc[codon, test_samples].to_numpy(dtype=float)
            ctr_pct = ctr * 100.0
            test_pct = test * 100.0
            t_stat, p_welch = safe_ttest_ind(test, ctr)
            diff_pp = float(np.mean(test_pct) - np.mean(ctr_pct))
            ci_low, ci_high = welch_ci_diff(test_pct, ctr_pct)
            fold = float(np.mean(test) / np.mean(ctr)) if np.mean(ctr) else np.nan
            log2fc = float(np.log2(fold)) if fold > 0 else np.nan
            test_rows.append(
                {
                    "codon": codon,
                    "genotype": genotype,
                    "ctr_mean_percent": float(np.mean(ctr_pct)),
                    "ctr_sd_percent": float(np.std(ctr_pct, ddof=1)),
                    "test_mean_percent": float(np.mean(test_pct)),
                    "test_sd_percent": float(np.std(test_pct, ddof=1)),
                    "difference_pp": diff_pp,
                    "ci95_low_pp": ci_low,
                    "ci95_high_pp": ci_high,
                    "fold_change": fold,
                    "log2FC": log2fc,
                    "welch_t": t_stat,
                    "welch_p": p_welch,
                    "significance_label": signif_label(p_welch),
                }
            )

            paired_t, paired_p = safe_ttest_rel(test, ctr)
            delta = (test - ctr) * 100.0
            one_t, one_p = safe_1sample_ttest(delta, 0.0)
            paired_rows.append(
                {
                    "codon": codon,
                    "genotype": genotype,
                    "delta_rep1_pp": float(delta[0]),
                    "delta_rep2_pp": float(delta[1]),
                    "delta_rep3_pp": float(delta[2]),
                    "delta_mean_pp": float(np.mean(delta)),
                    "delta_sd_pp": float(np.std(delta, ddof=1)),
                    "paired_t": paired_t,
                    "paired_p": paired_p,
                    "delta_one_sample_t": one_t,
                    "delta_one_sample_p": one_p,
                }
            )
        for a, b in [("R", "WT"), ("Q", "WT"), ("Q", "R")]:
            a_delta = (prop.loc[codon, GROUPS[f"{a}_test"]].to_numpy(dtype=float) - prop.loc[codon, GROUPS[f"{a}_ctr"]].to_numpy(dtype=float)) * 100.0
            b_delta = (prop.loc[codon, GROUPS[f"{b}_test"]].to_numpy(dtype=float) - prop.loc[codon, GROUPS[f"{b}_ctr"]].to_numpy(dtype=float)) * 100.0
            t_stat, p_val = safe_ttest_ind(a_delta, b_delta)
            delta_compare_rows.append(
                {
                    "codon": codon,
                    "comparison": f"delta_{a}_vs_delta_{b}",
                    "mean_delta_a_pp": float(np.mean(a_delta)),
                    "mean_delta_b_pp": float(np.mean(b_delta)),
                    "difference_pp": float(np.mean(a_delta) - np.mean(b_delta)),
                    "welch_t": t_stat,
                    "welch_p": p_val,
                    "significance_label": signif_label(p_val),
                }
            )

    tests = pd.DataFrame(test_rows).merge(cmeta, on="codon", how="left")
    tests["BH_q"] = np.nan
    for genotype in GENOTYPES:
        mask = (tests["genotype"] == genotype) & (~tests["is_stop"])
        tests.loc[mask, "BH_q"] = bh_adjust(tests.loc[mask, "welch_p"].to_numpy())
    tests["BH_significance_label"] = tests["BH_q"].apply(signif_label)
    tests.to_csv(dirs["codon"] / "codon_test_vs_ctr_statistics.tsv", sep="\t", index=False)
    tests.to_csv(dirs["tests"] / "codon_test_vs_ctr_statistics.tsv", sep="\t", index=False)

    paired = pd.DataFrame(paired_rows).merge(cmeta, on="codon", how="left")
    paired.to_csv(dirs["tests"] / "codon_paired_delta_statistics.tsv", sep="\t", index=False)

    delta_compare = pd.DataFrame(delta_compare_rows).merge(cmeta, on="codon", how="left")
    delta_compare.to_csv(dirs["tests"] / "codon_delta_genotype_comparisons.tsv", sep="\t", index=False)

    delta_rows = []
    for codon in prop.index:
        row = {"codon": codon}
        for genotype in GENOTYPES:
            row[f"{genotype}_delta_pp"] = float(
                (prop.loc[codon, GROUPS[f"{genotype}_test"]].mean() - prop.loc[codon, GROUPS[f"{genotype}_ctr"]].mean()) * 100.0
            )
            row[f"{genotype}_abs_delta_rank"] = np.nan
        delta_rows.append(row)
    delta_rank = pd.DataFrame(delta_rows).merge(cmeta, on="codon", how="left")
    for genotype in GENOTYPES:
        delta_rank[f"{genotype}_abs_delta_rank"] = delta_rank[f"{genotype}_delta_pp"].abs().rank(method="min", ascending=False).astype(int)
    delta_rank.to_csv(dirs["codon"] / "codon_delta_rank.tsv", sep="\t", index=False)

    return {
        "rank": rank_long,
        "group": group_stats,
        "tests": tests,
        "paired": paired,
        "delta_compare": delta_compare,
        "delta_rank": delta_rank,
    }


def compute_special_atg_gaa(prop: pd.DataFrame, stats_tables: dict[str, pd.DataFrame], dirs: dict[str, Path]) -> dict[str, pd.DataFrame]:
    tests = stats_tables["tests"]
    paired = stats_tables["paired"]
    delta_compare = stats_tables["delta_compare"]
    special = tests[tests["codon"].isin(["ATG", "GAA"])].copy()
    special.to_csv(dirs["atg_gaa"] / "ATG_GAA_summary.tsv", sep="\t", index=False)
    paired[paired["codon"].isin(["ATG", "GAA"])].to_csv(dirs["atg_gaa"] / "ATG_GAA_paired_delta.tsv", sep="\t", index=False)
    delta_compare[delta_compare["codon"].isin(["ATG", "GAA"])].to_csv(dirs["atg_gaa"] / "ATG_GAA_delta_pairwise.tsv", sep="\t", index=False)

    rows = []
    for sample in SAMPLE_ORDER:
        gaa = prop.loc["GAA", sample]
        gag = prop.loc["GAG", sample]
        total = gaa + gag
        rows.append(
            {
                "sample": sample,
                "GAA_proportion": gaa,
                "GAG_proportion": gag,
                "Glu_total_proportion": total,
                "GAA_share": gaa / total if total else np.nan,
                "GAG_share": gag / total if total else np.nan,
            }
        )
    share = pd.DataFrame(rows).merge(sample_metadata(), on="sample", how="left")
    share.to_csv(dirs["atg_gaa"] / "GAA_GAG_synonymous_share.tsv", sep="\t", index=False)
    return {"special": special, "share": share}


def compute_response_similarity(prop: pd.DataFrame, dirs: dict[str, Path]) -> dict[str, pd.DataFrame]:
    cmeta = codon_metadata(list(prop.index))
    rows = []
    for codon in prop.index:
        row = {"codon": codon}
        for genotype in GENOTYPES:
            row[f"{genotype}_delta_proportion"] = float(
                prop.loc[codon, GROUPS[f"{genotype}_test"]].mean() - prop.loc[codon, GROUPS[f"{genotype}_ctr"]].mean()
            )
            row[f"{genotype}_delta_pp"] = row[f"{genotype}_delta_proportion"] * 100.0
        rows.append(row)
    delta = pd.DataFrame(rows).merge(cmeta, on="codon", how="left")
    delta.to_csv(dirs["tests"] / "codon_delta_vectors.tsv", sep="\t", index=False)

    corr_rows = []
    sets = {
        "all_64": list(prop.index),
        "sense_61": [c for c in prop.index if c not in STOP_CODONS],
        "sense_without_ATG_60": [c for c in prop.index if c not in STOP_CODONS and c != "ATG"],
    }
    comparisons = [("R", "WT"), ("Q", "WT"), ("Q", "R")]
    for set_name, codons in sets.items():
        for a, b in comparisons:
            x = delta.set_index("codon").loc[codons, f"{a}_delta_proportion"]
            y = delta.set_index("codon").loc[codons, f"{b}_delta_proportion"]
            pearson_r, pearson_p = stats.pearsonr(x, y)
            spearman_r, spearman_p = stats.spearmanr(x, y)
            corr_rows.append(
                {
                    "feature_set": set_name,
                    "comparison": f"{a}_vs_{b}",
                    "n": len(codons),
                    "pearson_r": pearson_r,
                    "pearson_p": pearson_p,
                    "spearman_r": spearman_r,
                    "spearman_p": spearman_p,
                }
            )
    corr = pd.DataFrame(corr_rows)
    corr.to_csv(dirs["tests"] / "codon_response_correlations.tsv", sep="\t", index=False)

    quad_rows = []
    sense = [c for c in prop.index if c not in STOP_CODONS]
    for target in ["R", "Q"]:
        for codon in sense:
            wt = float(delta.loc[delta["codon"] == codon, "WT_delta_pp"].iloc[0])
            other = float(delta.loc[delta["codon"] == codon, f"{target}_delta_pp"].iloc[0])
            label = f"WT {'up' if wt >= 0 else 'down'} / {target} {'up' if other >= 0 else 'down'}"
            quad_rows.append({"comparison": f"WT_vs_{target}", "codon": codon, "WT_delta_pp": wt, f"{target}_delta_pp": other, "quadrant": label})
    quadrants = pd.DataFrame(quad_rows)
    quadrants.to_csv(dirs["tests"] / "direction_quadrants.tsv", sep="\t", index=False)
    return {"delta": delta, "corr": corr, "quadrants": quadrants}


def compute_amino_acids(prop: pd.DataFrame, dirs: dict[str, Path]) -> dict[str, pd.DataFrame]:
    cmeta = codon_metadata(list(prop.index))
    sense_meta = cmeta[cmeta["is_sense"]].copy()
    aa_prop = pd.DataFrame(index=sorted(sense_meta["amino_acid"].unique()), columns=SAMPLE_ORDER, dtype=float)
    for aa in aa_prop.index:
        codons = sense_meta.loc[sense_meta["amino_acid"] == aa, "codon"].tolist()
        aa_prop.loc[aa, SAMPLE_ORDER] = prop.loc[codons, SAMPLE_ORDER].sum(axis=0)
    aa_prop = aa_prop.loc[[aa for aa in AA_ORDER if aa in aa_prop.index]]

    rows = []
    for aa in aa_prop.index:
        for sample in SAMPLE_ORDER:
            rows.append({"amino_acid": aa, "sample": sample, "proportion": float(aa_prop.loc[aa, sample]), "percent": float(aa_prop.loc[aa, sample] * 100.0)})
    aa_long = pd.DataFrame(rows).merge(sample_metadata(), on="sample", how="left")
    aa_long.to_csv(dirs["aa"] / "amino_acid_sample_percent.tsv", sep="\t", index=False)

    group_rows = []
    for aa in aa_prop.index:
        for group, samples in GROUPS.items():
            vals = aa_prop.loc[aa, samples].to_numpy(dtype=float) * 100.0
            mean, ci_low, ci_high = mean_ci95(vals)
            group_rows.append(
                {
                    "amino_acid": aa,
                    "group": group,
                    "genotype": group.split("_")[0],
                    "condition": group.split("_")[1],
                    "n": len(vals),
                    "mean_percent": mean,
                    "sd_percent": float(np.std(vals, ddof=1)),
                    "sem_percent": float(stats.sem(vals)),
                    "ci95_low_percent": ci_low,
                    "ci95_high_percent": ci_high,
                    "rank": np.nan,
                }
            )
    aa_group = pd.DataFrame(group_rows)
    for group in GROUP_ORDER:
        mask = aa_group["group"] == group
        aa_group.loc[mask, "rank"] = aa_group.loc[mask, "mean_percent"].rank(method="min", ascending=False).astype(int)
    aa_group.to_csv(dirs["aa"] / "amino_acid_group_mean_sd.tsv", sep="\t", index=False)

    test_rows = []
    for aa in aa_prop.index:
        for genotype in GENOTYPES:
            ctr = aa_prop.loc[aa, GROUPS[f"{genotype}_ctr"]].to_numpy(dtype=float)
            test = aa_prop.loc[aa, GROUPS[f"{genotype}_test"]].to_numpy(dtype=float)
            t_stat, p_val = safe_ttest_ind(test, ctr)
            ctr_pct = ctr * 100.0
            test_pct = test * 100.0
            ci_low, ci_high = welch_ci_diff(test_pct, ctr_pct)
            fold = float(np.mean(test) / np.mean(ctr)) if np.mean(ctr) else np.nan
            test_rows.append(
                {
                    "amino_acid": aa,
                    "genotype": genotype,
                    "ctr_mean_percent": float(np.mean(ctr_pct)),
                    "ctr_sd_percent": float(np.std(ctr_pct, ddof=1)),
                    "test_mean_percent": float(np.mean(test_pct)),
                    "test_sd_percent": float(np.std(test_pct, ddof=1)),
                    "difference_pp": float(np.mean(test_pct) - np.mean(ctr_pct)),
                    "ci95_low_pp": ci_low,
                    "ci95_high_pp": ci_high,
                    "fold_change": fold,
                    "log2FC": float(np.log2(fold)) if fold > 0 else np.nan,
                    "welch_t": t_stat,
                    "welch_p": p_val,
                    "significance_label": signif_label(p_val),
                }
            )
    aa_tests = pd.DataFrame(test_rows)
    aa_tests["BH_q"] = np.nan
    for genotype in GENOTYPES:
        mask = aa_tests["genotype"] == genotype
        aa_tests.loc[mask, "BH_q"] = bh_adjust(aa_tests.loc[mask, "welch_p"])
    aa_tests["BH_significance_label"] = aa_tests["BH_q"].apply(signif_label)
    aa_tests.to_csv(dirs["aa"] / "amino_acid_test_vs_ctr_statistics.tsv", sep="\t", index=False)

    top5 = aa_group[aa_group["rank"] <= 5].sort_values(["group", "rank"])
    top5.to_csv(dirs["aa"] / "amino_acid_top5_each_group.tsv", sep="\t", index=False)

    family_rows = []
    families = ["Glu", "Lys", "Asn", "Asp", "Gly", "Leu", "Arg"]
    for aa in families:
        codons = sense_meta.loc[sense_meta["amino_acid"] == aa, "codon"].tolist()
        for sample in SAMPLE_ORDER:
            total = prop.loc[codons, sample].sum()
            for codon in codons:
                family_rows.append(
                    {
                        "amino_acid": aa,
                        "codon": codon,
                        "sample": sample,
                        "proportion": float(prop.loc[codon, sample]),
                        "percent": float(prop.loc[codon, sample] * 100.0),
                        "family_share": float(prop.loc[codon, sample] / total) if total else np.nan,
                    }
                )
    families_df = pd.DataFrame(family_rows).merge(sample_metadata(), on="sample", how="left")
    families_df.to_csv(dirs["aa"] / "synonymous_codon_family_shares.tsv", sep="\t", index=False)
    return {"aa_prop": aa_prop, "long": aa_long, "group": aa_group, "tests": aa_tests, "top5": top5, "families": families_df}


def euclidean_matrix(df_samples_by_features: pd.DataFrame) -> pd.DataFrame:
    arr = df_samples_by_features.to_numpy(dtype=float)
    dist = np.sqrt(((arr[:, None, :] - arr[None, :, :]) ** 2).sum(axis=2))
    return pd.DataFrame(dist, index=df_samples_by_features.index, columns=df_samples_by_features.index)


def classical_mds(dist: pd.DataFrame, n_components: int = 2) -> tuple[pd.DataFrame, np.ndarray]:
    d = dist.to_numpy(dtype=float)
    n = d.shape[0]
    j = np.eye(n) - np.ones((n, n)) / n
    b = -0.5 * j @ (d**2) @ j
    eigvals, eigvecs = np.linalg.eigh(b)
    order = np.argsort(eigvals)[::-1]
    eigvals = eigvals[order]
    eigvecs = eigvecs[:, order]
    pos = np.maximum(eigvals[:n_components], 0)
    coords = eigvecs[:, :n_components] * np.sqrt(pos)
    columns = [f"MDS{i+1}" for i in range(n_components)]
    return pd.DataFrame(coords, index=dist.index, columns=columns), eigvals


def compute_similarity(prop: pd.DataFrame, dirs: dict[str, Path]) -> dict[str, pd.DataFrame]:
    sense = [c for c in prop.index if c not in STOP_CODONS]
    sample_feature = prop.loc[sense, SAMPLE_ORDER].T
    pearson = sample_feature.T.corr(method="pearson")
    spearman = sample_feature.T.corr(method="spearman")
    euclid = euclidean_matrix(sample_feature)
    pearson.to_csv(dirs["similarity"] / "sample_pearson_matrix.tsv", sep="\t")
    spearman.to_csv(dirs["similarity"] / "sample_spearman_matrix.tsv", sep="\t")
    euclid.to_csv(dirs["similarity"] / "sample_euclidean_distance.tsv", sep="\t")

    group_centers = pd.DataFrame(index=GROUP_ORDER, columns=sense, dtype=float)
    for group, samples in GROUPS.items():
        group_centers.loc[group, :] = prop.loc[sense, samples].mean(axis=1).to_numpy()
    group_centers.to_csv(dirs["similarity"] / "group_centroid_proportions.tsv", sep="\t")
    centroid_corr = group_centers.T.corr(method="spearman")
    centroid_dist = euclidean_matrix(group_centers)
    centroid_corr.to_csv(dirs["similarity"] / "group_centroid_spearman.tsv", sep="\t")
    centroid_dist.to_csv(dirs["similarity"] / "group_centroid_euclidean.tsv", sep="\t")

    wt_ctr_center = prop.loc[sense, GROUPS["WT_ctr"]].mean(axis=1).to_numpy(dtype=float)
    wt_test_center = prop.loc[sense, GROUPS["WT_test"]].mean(axis=1).to_numpy(dtype=float)
    state_rows = []
    for sample in SAMPLE_ORDER:
        if sample.startswith("wt_"):
            continue
        vec = prop.loc[sense, sample].to_numpy(dtype=float)
        d_ctr = float(np.linalg.norm(vec - wt_ctr_center))
        d_test = float(np.linalg.norm(vec - wt_test_center))
        state_rows.append(
            {
                "sample": sample,
                "distance_to_WT_ctr": d_ctr,
                "distance_to_WT_test": d_test,
                "StateAffinity": d_ctr - d_test,
            }
        )
    state = pd.DataFrame(state_rows).merge(sample_metadata(), on="sample", how="left")
    state.to_csv(dirs["similarity"] / "WT_state_affinity_by_sample.tsv", sep="\t", index=False)

    state_group_rows = []
    for group in ["Q_ctr", "Q_test", "R_ctr", "R_test"]:
        vals = state.loc[state["group"] == group, "StateAffinity"].to_numpy(dtype=float)
        t_stat, p_val = safe_1sample_ttest(vals, 0.0)
        state_group_rows.append(
            {
                "group": group,
                "n": len(vals),
                "mean_StateAffinity": float(np.mean(vals)),
                "sd_StateAffinity": float(np.std(vals, ddof=1)),
                "one_sample_t": t_stat,
                "one_sample_p": p_val,
                "significance_label": signif_label(p_val),
            }
        )
    state_group = pd.DataFrame(state_group_rows)
    state_group.to_csv(dirs["similarity"] / "WT_state_affinity_group_stats.tsv", sep="\t", index=False)

    x = sample_feature.to_numpy(dtype=float)
    x_centered = x - x.mean(axis=0)
    u, s, vt = np.linalg.svd(x_centered, full_matrices=False)
    coords = u[:, :4] * s[:4]
    variance = (s**2) / (len(sample_feature) - 1)
    explained = variance / variance.sum()
    pca = pd.DataFrame(coords[:, :4], index=sample_feature.index, columns=["PC1", "PC2", "PC3", "PC4"]).reset_index().rename(columns={"index": "sample"})
    pca = pca.merge(sample_metadata(), on="sample", how="left")
    pca.to_csv(dirs["similarity"] / "sample_PCA_coordinates.tsv", sep="\t", index=False)
    pd.DataFrame({"PC": [f"PC{i+1}" for i in range(len(explained))], "explained_variance_ratio": explained}).to_csv(
        dirs["similarity"] / "sample_PCA_explained_variance.tsv", sep="\t", index=False
    )

    loadings = pd.DataFrame(vt[:4, :].T, index=sense, columns=["PC1_loading", "PC2_loading", "PC3_loading", "PC4_loading"]).reset_index().rename(columns={"index": "codon"})
    loadings = loadings.merge(codon_metadata(sense), on="codon", how="left")
    loadings.to_csv(dirs["similarity"] / "sample_PCA_loadings.tsv", sep="\t", index=False)

    mds, eigvals = classical_mds(euclid)
    mds = mds.reset_index().rename(columns={"index": "sample"}).merge(sample_metadata(), on="sample", how="left")
    mds.to_csv(dirs["similarity"] / "sample_MDS_coordinates.tsv", sep="\t", index=False)
    pd.DataFrame({"component": np.arange(1, len(eigvals) + 1), "eigenvalue": eigvals}).to_csv(dirs["similarity"] / "sample_MDS_eigenvalues.tsv", sep="\t", index=False)

    nn_rows = []
    for sample in SAMPLE_ORDER:
        scores = spearman.loc[sample].drop(sample).sort_values(ascending=False)
        for rank, (neighbor, rho) in enumerate(scores.items(), start=1):
            nn_rows.append({"sample": sample, "neighbor": neighbor, "rank": rank, "spearman": float(rho)})
    nearest = pd.DataFrame(nn_rows)
    nearest.to_csv(dirs["similarity"] / "nearest_neighbor_rank.tsv", sep="\t", index=False)

    return {
        "sample_feature": sample_feature,
        "pearson": pearson,
        "spearman": spearman,
        "euclid": euclid,
        "group_centers": group_centers,
        "centroid_corr": centroid_corr,
        "centroid_dist": centroid_dist,
        "state": state,
        "state_group": state_group,
        "pca": pca,
        "mds": mds,
        "nearest": nearest,
    }


def validate_numeric_gates(codon_tests: pd.DataFrame, corr: pd.DataFrame, dirs: dict[str, Path]) -> pd.DataFrame:
    expected = [
        ("ATG", "WT", "ctr_mean_percent", 3.6099, 0.02),
        ("ATG", "WT", "test_mean_percent", 9.5678, 0.02),
        ("ATG", "WT", "welch_p", 0.005195, 0.0005),
        ("ATG", "R", "ctr_mean_percent", 4.6216, 0.02),
        ("ATG", "R", "test_mean_percent", 10.5587, 0.02),
        ("ATG", "R", "welch_p", 0.1611, 0.005),
        ("ATG", "Q", "ctr_mean_percent", 16.1701, 0.02),
        ("ATG", "Q", "test_mean_percent", 6.5110, 0.02),
        ("ATG", "Q", "welch_p", 0.0001666, 0.00005),
        ("GAA", "WT", "ctr_mean_percent", 8.4486, 0.02),
        ("GAA", "WT", "test_mean_percent", 5.9709, 0.02),
        ("GAA", "WT", "welch_p", 0.005615, 0.0005),
        ("GAA", "R", "ctr_mean_percent", 9.4704, 0.02),
        ("GAA", "R", "test_mean_percent", 7.7169, 0.02),
        ("GAA", "R", "welch_p", 0.1301, 0.005),
        ("GAA", "Q", "ctr_mean_percent", 6.3883, 0.02),
        ("GAA", "Q", "test_mean_percent", 6.3887, 0.02),
        ("GAA", "Q", "welch_p", 0.9991, 0.002),
    ]
    rows = []
    for codon, genotype, field, exp, tol in expected:
        value = float(codon_tests.loc[(codon_tests["codon"] == codon) & (codon_tests["genotype"] == genotype), field].iloc[0])
        rows.append({"gate": f"{codon}_{genotype}_{field}", "observed": value, "expected": exp, "tolerance": tol, "passed": abs(value - exp) <= tol})

    corr_expected = [
        ("sense_61", "R_vs_WT", 0.8874, 0.005),
        ("sense_without_ATG_60", "R_vs_WT", 0.7207, 0.005),
        ("sense_61", "Q_vs_WT", -0.7185, 0.005),
        ("sense_without_ATG_60", "Q_vs_WT", 0.2518, 0.005),
        ("sense_61", "Q_vs_R", -0.8558, 0.005),
        ("sense_without_ATG_60", "Q_vs_R", 0.4226, 0.005),
    ]
    for feature_set, comparison, exp, tol in corr_expected:
        value = float(corr.loc[(corr["feature_set"] == feature_set) & (corr["comparison"] == comparison), "pearson_r"].iloc[0])
        rows.append({"gate": f"{feature_set}_{comparison}_pearson_r", "observed": value, "expected": exp, "tolerance": tol, "passed": abs(value - exp) <= tol})
    gate = pd.DataFrame(rows)
    gate.to_csv(dirs["qc"] / "numeric_gates.tsv", sep="\t", index=False)
    if not gate["passed"].all():
        failed = gate.loc[~gate["passed"], "gate"].tolist()
        raise RuntimeError(f"Numeric gates failed: {failed}")
    return gate


def set_plot_style() -> None:
    sns.set_theme(style="whitegrid", context="paper")
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "figure.titlesize": 11,
            "axes.linewidth": 0.6,
            "lines.linewidth": 0.9,
        }
    )


def save_figure(fig: plt.Figure, out_dir: Path, stem: str) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_dir / f"{stem}.pdf")
    fig.savefig(out_dir / f"{stem}.svg")
    fig.savefig(out_dir / f"{stem}.png", dpi=600)
    plt.close(fig)


def write_source(dirs: dict[str, Path], stem: str, df: pd.DataFrame) -> None:
    df.to_csv(dirs["source"] / f"{stem}_source.tsv", sep="\t", index=False)


def annotate_panel(ax: plt.Axes, label: str) -> None:
    ax.text(-0.12, 1.08, label, transform=ax.transAxes, fontsize=10, fontweight="bold", va="top")


def add_group_background(ax: plt.Axes) -> None:
    for i, group in enumerate(GROUP_ORDER):
        ax.axvspan(i - 0.45, i + 0.45, color=GROUP_COLORS[group], alpha=0.06, zorder=0)


def plot_group_dot(ax: plt.Axes, prop: pd.DataFrame, codon: str, tests: pd.DataFrame, title: str) -> pd.DataFrame:
    rows = []
    x_positions = {group: i for i, group in enumerate(GROUP_ORDER)}
    add_group_background(ax)
    for group, samples in GROUPS.items():
        vals = prop.loc[codon, samples].to_numpy(dtype=float) * 100.0
        for j, sample in enumerate(samples):
            x = x_positions[group] + (j - 1) * 0.08
            ax.scatter(x, vals[j], s=30, color=GROUP_COLORS[group], edgecolor="black", linewidth=0.4, zorder=3)
            rows.append(
                {
                    "sample": sample,
                    "genotype": group.split("_")[0],
                    "condition": group.split("_")[1],
                    "replicate": j + 1,
                    "feature": codon,
                    "value": vals[j],
                    "group": group,
                    "group_mean": float(np.mean(vals)),
                    "SD": float(np.std(vals, ddof=1)),
                }
            )
        ax.errorbar(
            x_positions[group],
            np.mean(vals),
            yerr=np.std(vals, ddof=1),
            fmt="_",
            color="black",
            capsize=3,
            markersize=14,
            zorder=4,
        )
        ax.text(x_positions[group], np.mean(vals), f"{np.mean(vals):.2f}%", ha="center", va="bottom", fontsize=6)
    ymax = max(prop.loc[codon, SAMPLE_ORDER].to_numpy(dtype=float) * 100.0) * 1.18
    for genotype in GENOTYPES:
        p = tests.loc[(tests["codon"] == codon) & (tests["genotype"] == genotype), "welch_p"].iloc[0]
        x0 = x_positions[f"{genotype}_ctr"]
        x1 = x_positions[f"{genotype}_test"]
        y = ymax * (0.92 - 0.04 * GENOTYPES.index(genotype))
        ax.plot([x0, x0, x1, x1], [y * 0.98, y, y, y * 0.98], color="black", linewidth=0.6)
        ax.text((x0 + x1) / 2, y * 1.01, f"P={fmt_p(p)}", ha="center", va="bottom", fontsize=6)
    ax.set_xticks(range(len(GROUP_ORDER)))
    ax.set_xticklabels(GROUP_ORDER, rotation=35, ha="right")
    ax.set_ylabel("% of total codon P-site counts")
    ax.set_title(title)
    ax.set_ylim(bottom=0, top=ymax * 1.05)
    return pd.DataFrame(rows)


def plot_paired_slope(axs: list[plt.Axes], prop: pd.DataFrame, codon: str, title_prefix: str) -> pd.DataFrame:
    rows = []
    for ax, genotype in zip(axs, GENOTYPES):
        ctr_samples = GROUPS[f"{genotype}_ctr"]
        test_samples = GROUPS[f"{genotype}_test"]
        ctr = prop.loc[codon, ctr_samples].to_numpy(dtype=float) * 100.0
        test = prop.loc[codon, test_samples].to_numpy(dtype=float) * 100.0
        for i in range(3):
            ax.plot([0, 1], [ctr[i], test[i]], color=GENOTYPE_COLORS[genotype], alpha=0.8, marker="o")
            ax.text(1.03, test[i], f"{genotype}_test{i+1}", fontsize=6, va="center")
            rows.append(
                {
                    "sample": test_samples[i],
                    "genotype": genotype,
                    "condition": "test",
                    "replicate": i + 1,
                    "feature": codon,
                    "value": test[i],
                    "paired_ctr_value": ctr[i],
                    "difference": test[i] - ctr[i],
                }
            )
        ax.axhline(0, color="black", linewidth=0.5)
        ax.set_xticks([0, 1])
        ax.set_xticklabels(["ctr", "test"])
        ax.set_title(f"{title_prefix}: {genotype}")
        ax.set_ylabel("% of total codon P-site counts")
    return pd.DataFrame(rows)


def plot_delta_dot(ax: plt.Axes, prop: pd.DataFrame, codon: str, delta_compare: pd.DataFrame, title: str) -> pd.DataFrame:
    rows = []
    for i, genotype in enumerate(GENOTYPES):
        ctr = prop.loc[codon, GROUPS[f"{genotype}_ctr"]].to_numpy(dtype=float) * 100.0
        test = prop.loc[codon, GROUPS[f"{genotype}_test"]].to_numpy(dtype=float) * 100.0
        delta = test - ctr
        for rep, value in enumerate(delta, start=1):
            ax.scatter(i + (rep - 2) * 0.08, value, s=35, color=GENOTYPE_COLORS[genotype], edgecolor="black", linewidth=0.4)
            rows.append({"sample": f"{genotype}_rep{rep}", "genotype": genotype, "condition": "test-ctr", "replicate": rep, "feature": codon, "value": value})
        ax.errorbar(i, delta.mean(), yerr=delta.std(ddof=1), fmt="_", color="black", capsize=4, markersize=14)
        ax.text(i, delta.mean(), f"{delta.mean():+.2f} pp", ha="center", va="bottom" if delta.mean() >= 0 else "top", fontsize=7)
    ax.axhline(0, color="black", linewidth=0.7)
    ax.set_xticks(range(3))
    ax.set_xticklabels(GENOTYPES)
    ax.set_ylabel("test - ctr (percentage points)")
    ax.set_title(title)
    ymin, ymax = ax.get_ylim()
    y = ymax
    for comp in ["delta_R_vs_delta_WT", "delta_Q_vs_delta_WT", "delta_Q_vs_delta_R"]:
        p = delta_compare.loc[(delta_compare["codon"] == codon) & (delta_compare["comparison"] == comp), "welch_p"].iloc[0]
        ax.text(0.98, 0.96 - 0.06 * ["delta_R_vs_delta_WT", "delta_Q_vs_delta_WT", "delta_Q_vs_delta_R"].index(comp), f"{comp}: P={fmt_p(p)}", transform=ax.transAxes, ha="right", fontsize=6)
    return pd.DataFrame(rows)


def plot_effect_forest(ax: plt.Axes, tests: pd.DataFrame, feature: str, title: str) -> pd.DataFrame:
    data = tests[(tests["codon"] == feature) & (tests["genotype"].isin(GENOTYPES))].copy()
    y_positions = np.arange(len(GENOTYPES))
    for i, genotype in enumerate(GENOTYPES):
        row = data[data["genotype"] == genotype].iloc[0]
        color = GENOTYPE_COLORS[genotype]
        ax.errorbar(
            row["difference_pp"],
            i,
            xerr=[[row["difference_pp"] - row["ci95_low_pp"]], [row["ci95_high_pp"] - row["difference_pp"]]],
            fmt="o",
            color=color,
            ecolor=color,
            capsize=3,
        )
        ax.text(row["ci95_high_pp"], i + 0.08, f"P={fmt_p(row['welch_p'])}, FC={row['fold_change']:.2f}", fontsize=6, va="center")
    ax.axvline(0, color="black", linewidth=0.7)
    ax.set_yticks(y_positions)
    ax.set_yticklabels(GENOTYPES)
    ax.set_xlabel("test - ctr (percentage points)")
    ax.set_title(title)
    return data


def plot_rank_shift(ax: plt.Axes, rank: pd.DataFrame, feature: str, title: str) -> pd.DataFrame:
    data = rank[rank["codon"] == feature].copy()
    for genotype in GENOTYPES:
        color = GENOTYPE_COLORS[genotype]
        for rep in [1, 2, 3]:
            ctr_sample = GROUPS[f"{genotype}_ctr"][rep - 1]
            test_sample = GROUPS[f"{genotype}_test"][rep - 1]
            ctr_rank = data.loc[data["sample"] == ctr_sample, "rank"].iloc[0]
            test_rank = data.loc[data["sample"] == test_sample, "rank"].iloc[0]
            x0 = GENOTYPES.index(genotype) * 2
            x1 = x0 + 1
            ax.plot([x0, x1], [ctr_rank, test_rank], color=color, marker="o", alpha=0.8)
            ax.text(x1 + 0.03, test_rank, f"r{rep}", fontsize=6, va="center")
    ax.invert_yaxis()
    ax.set_xticks([0, 1, 2, 3, 4, 5])
    ax.set_xticklabels(["WT ctr", "WT test", "R ctr", "R test", "Q ctr", "Q test"], rotation=35, ha="right")
    ax.set_ylabel("rank (1 = highest)")
    ax.set_title(title)
    return data


def plot_response_scatter(ax: plt.Axes, delta: pd.DataFrame, x_genotype: str, y_genotype: str, title: str, include_atg: bool = True) -> pd.DataFrame:
    data = delta[delta["is_sense"]].copy()
    if not include_atg:
        data = data[data["codon"] != "ATG"].copy()
    xcol = f"{x_genotype}_delta_pp"
    ycol = f"{y_genotype}_delta_pp"
    for _, row in data.iterrows():
        codon = row["codon"]
        color = FEATURE_COLORS.get(codon, "#666666")
        size = 42 if codon in ["ATG", "GAA"] else 18
        alpha = 0.95 if codon in ["ATG", "GAA"] else 0.55
        ax.scatter(row[xcol], row[ycol], s=size, color=color, alpha=alpha, edgecolor="black" if codon in ["ATG", "GAA"] else "none", linewidth=0.4)
        if codon in ["ATG", "GAA"]:
            ax.text(row[xcol], row[ycol], codon, fontsize=7, fontweight="bold")
    lim = max(abs(data[xcol]).max(), abs(data[ycol]).max()) * 1.15
    ax.axhline(0, color="black", linewidth=0.6)
    ax.axvline(0, color="black", linewidth=0.6)
    ax.plot([-lim, lim], [-lim, lim], linestyle="--", color="gray", linewidth=0.6)
    r, p = stats.pearsonr(data[xcol], data[ycol])
    ax.text(0.03, 0.97, f"Pearson r={r:.3f}\nP={fmt_p(p)}\nn={len(data)}", transform=ax.transAxes, va="top", fontsize=7)
    ax.set_xlim(-lim, lim)
    ax.set_ylim(-lim, lim)
    ax.set_xlabel(f"{x_genotype} test - ctr (pp)")
    ax.set_ylabel(f"{y_genotype} test - ctr (pp)")
    ax.set_title(title)
    return data


def heatmap(ax: plt.Axes, data: pd.DataFrame, title: str, center: float | None = None, cmap: str = "viridis", cbar: bool = True) -> None:
    if center is None:
        sns.heatmap(data, ax=ax, cmap=cmap, cbar=cbar, xticklabels=True, yticklabels=True)
    else:
        vmax = np.nanmax(np.abs(data.to_numpy() - center))
        norm = TwoSlopeNorm(vcenter=center, vmin=center - vmax, vmax=center + vmax)
        sns.heatmap(data, ax=ax, cmap=cmap, cbar=cbar, xticklabels=True, yticklabels=True, norm=norm)
    ax.set_title(title)


def plot_all_figures(
    prop: pd.DataFrame,
    raw: pd.DataFrame,
    rpm: pd.DataFrame,
    long: pd.DataFrame,
    stats_tables: dict[str, pd.DataFrame],
    special: dict[str, pd.DataFrame],
    response: dict[str, pd.DataFrame],
    aa: dict[str, pd.DataFrame],
    sim: dict[str, pd.DataFrame],
    dirs: dict[str, Path],
    version: str,
) -> None:
    set_plot_style()
    tests = stats_tables["tests"]
    delta_compare = stats_tables["delta_compare"]
    rank = stats_tables["rank"]
    delta = response["delta"]
    cmeta = codon_metadata(list(prop.index)).set_index("codon")
    smeta = sample_metadata()

    
    fig, ax = plt.subplots(figsize=(6, 2))
    for i, group in enumerate(GROUP_ORDER):
        ax.scatter(i, 0, s=80, color=GROUP_COLORS[group], edgecolor="black", label=group)
    ax.legend(ncol=3, loc="center")
    ax.axis("off")
    save_figure(fig, dirs["style"], f"Style_group_color_legend_{version}")

    
    library = pd.read_csv(dirs["qc"] / "library_size.tsv", sep="\t")
    norm = pd.read_csv(dirs["qc"] / "normalization_sums.tsv", sep="\t")
    stop = pd.read_csv(dirs["qc"] / "stop_codon_qc.tsv", sep="\t")
    entropy_rows = []
    for sample in SAMPLE_ORDER:
        p = prop[sample].to_numpy(dtype=float)
        h = -np.sum(p[p > 0] * np.log(p[p > 0]))
        entropy_rows.append({"sample": sample, "entropy": h, "effective_codon_number": math.exp(h)})
    entropy = pd.DataFrame(entropy_rows).merge(smeta, on="sample", how="left")
    entropy.to_csv(dirs["qc"] / "codon_diversity.tsv", sep="\t", index=False)

    fig, axs = plt.subplots(2, 3, figsize=(12, 7))
    ax = axs[0, 0]
    ax.bar(range(len(library)), library["library_size"], color=[GROUP_COLORS[g] for g in library["group"]])
    ax.set_xticks(range(len(library)))
    ax.set_xticklabels(library["sample"], rotation=60, ha="right")
    ax.set_ylabel("raw P-site codon counts")
    ax.set_title("Fig1A library size")
    annotate_panel(ax, "A")
    ax = axs[0, 1]
    ax.scatter(range(len(norm)), norm["proportion_sum"], color=[GROUP_COLORS[g] for g in norm["group"]])
    ax.axhline(1.0, color="black", linewidth=0.7)
    ax.set_xticks(range(len(norm)))
    ax.set_xticklabels(norm["sample"], rotation=60, ha="right")
    ax.set_title("Fig1B proportion sum")
    annotate_panel(ax, "B")
    ax = axs[0, 2]
    ax.scatter(range(len(norm)), norm["rpm_sum"], color=[GROUP_COLORS[g] for g in norm["group"]])
    ax.axhline(1_000_000, color="black", linewidth=0.7)
    ax.set_xticks(range(len(norm)))
    ax.set_xticklabels(norm["sample"], rotation=60, ha="right")
    ax.set_title("Fig1C RPM sum")
    annotate_panel(ax, "C")
    ax = axs[1, 0]
    sns.heatmap(sim["spearman"].loc[SAMPLE_ORDER, SAMPLE_ORDER], ax=ax, cmap="mako", vmin=0.8, vmax=1.0, cbar_kws={"label": "Spearman"})
    ax.set_title("Fig1D replicate Spearman")
    annotate_panel(ax, "D")
    ax = axs[1, 1]
    for group in GROUP_ORDER:
        sub = entropy[entropy["group"] == group]
        ax.scatter(sub["sample_order"], sub["effective_codon_number"], color=GROUP_COLORS[group], edgecolor="black", linewidth=0.4, label=group)
    ax.set_xticks(entropy["sample_order"])
    ax.set_xticklabels(entropy["sample"], rotation=60, ha="right")
    ax.set_ylabel("exp(entropy)")
    ax.set_title("Fig1E codon diversity")
    annotate_panel(ax, "E")
    ax = axs[1, 2]
    stop_m = stop.melt(id_vars=["sample", "group", "sample_order"], value_vars=STOP_CODONS, var_name="codon", value_name="percent")
    sns.scatterplot(data=stop_m, x="sample_order", y="percent", hue="codon", style="codon", ax=ax, s=30)
    ax.set_xticks(stop["sample_order"])
    ax.set_xticklabels(stop["sample"], rotation=60, ha="right")
    ax.set_ylabel("stop codon percent")
    ax.set_title("Fig1F stop codon QC")
    annotate_panel(ax, "F")
    save_figure(fig, dirs["fig_qc"], f"Fig1_QC_normalization_replicates_{version}")
    write_source(dirs, "Fig1A_library_size", library)
    write_source(dirs, "Fig1B_C_normalization_sums", norm)
    write_source(dirs, "Fig1E_codon_diversity", entropy)
    write_source(dirs, "Fig1F_stop_codon_qc", stop_m)

    
    fig, axs = plt.subplots(2, 3, figsize=(12, 7))
    src = plot_group_dot(axs[0, 0], prop, "ATG", tests, "Fig2A ATG group dotplot")
    annotate_panel(axs[0, 0], "A")
    write_source(dirs, "Fig2A_ATG_group_dotplot", src.merge(tests[tests["codon"] == "ATG"], on="genotype", how="left", suffixes=("", "_stat")))
    paired_src = plot_paired_slope([axs[0, 1], axs[0, 2], axs[1, 0]], prop, "ATG", "Fig2B ATG paired slope")
    annotate_panel(axs[0, 1], "B")
    annotate_panel(axs[0, 2], "B")
    annotate_panel(axs[1, 0], "B")
    write_source(dirs, "Fig2B_ATG_paired_slope", paired_src)
    delta_src = plot_delta_dot(axs[1, 1], prop, "ATG", delta_compare, "Fig2C delta ATG")
    annotate_panel(axs[1, 1], "C")
    forest_src = plot_effect_forest(axs[1, 2], tests, "ATG", "Fig2E ATG effect forest")
    annotate_panel(axs[1, 2], "D/E")
    write_source(dirs, "Fig2C_delta_ATG", delta_src)
    write_source(dirs, "Fig2E_ATG_effect_forest", forest_src)
    save_figure(fig, dirs["fig_atg"], f"Fig2_ATG_multi_angle_{version}")

    fig, ax = plt.subplots(figsize=(7, 4))
    rank_src = plot_rank_shift(ax, rank, "ATG", "Fig2F ATG rank shift")
    save_figure(fig, dirs["fig_atg"], f"Fig2F_ATG_rank_shift_{version}")
    write_source(dirs, "Fig2F_ATG_rank_shift", rank_src)

    
    fig, axs = plt.subplots(2, 3, figsize=(12, 8))
    write_source(dirs, "Fig3A_WT_R_response", plot_response_scatter(axs[0, 0], delta, "WT", "R", "Fig3A WT vs R response"))
    annotate_panel(axs[0, 0], "A")
    write_source(dirs, "Fig3B_WT_Q_response", plot_response_scatter(axs[0, 1], delta, "WT", "Q", "Fig3B WT vs Q response"))
    annotate_panel(axs[0, 1], "B")
    write_source(dirs, "Fig3C_R_Q_response", plot_response_scatter(axs[0, 2], delta, "R", "Q", "Fig3C R vs Q response"))
    annotate_panel(axs[0, 2], "C")
    ax = axs[1, 0]
    corr_src = response["corr"][response["corr"]["feature_set"].isin(["sense_61", "sense_without_ATG_60"])].copy()
    for comp, sub in corr_src.groupby("comparison"):
        sub = sub.set_index("feature_set").loc[["sense_61", "sense_without_ATG_60"]].reset_index()
        y = ["R_vs_WT", "Q_vs_WT", "Q_vs_R"].index(comp)
        ax.plot(sub["pearson_r"], [y, y], marker="o", label=comp)
        ax.text(sub["pearson_r"].iloc[0], y + 0.07, "all61", fontsize=6)
        ax.text(sub["pearson_r"].iloc[1], y - 0.12, "no ATG", fontsize=6)
    ax.axvline(0, color="black", linewidth=0.7)
    ax.set_yticks(range(3))
    ax.set_yticklabels(["R-WT", "Q-WT", "Q-R"])
    ax.set_xlabel("Pearson r")
    ax.set_title("Fig3D ATG sensitivity")
    annotate_panel(ax, "D")
    write_source(dirs, "Fig3D_correlation_ATG_sensitivity", corr_src)
    ax = axs[1, 1]
    qdata = response["quadrants"].copy()
    sns.countplot(data=qdata, y="quadrant", hue="comparison", ax=ax, palette=["#006d2c", "#a63603"])
    ax.set_title("Fig3E direction quadrant counts")
    annotate_panel(ax, "E")
    write_source(dirs, "Fig3E_direction_quadrant", qdata)
    ax = axs[1, 2]
    aa_delta_rows = []
    for aa_name in aa["aa_prop"].index:
        row = {"amino_acid": aa_name}
        for genotype in GENOTYPES:
            row[f"{genotype}_delta_pp"] = float(
                (aa["aa_prop"].loc[aa_name, GROUPS[f"{genotype}_test"]].mean() - aa["aa_prop"].loc[aa_name, GROUPS[f"{genotype}_ctr"]].mean()) * 100.0
            )
        aa_delta_rows.append(row)
    aa_delta = pd.DataFrame(aa_delta_rows)
    ax.scatter(aa_delta["WT_delta_pp"], aa_delta["R_delta_pp"], color="#006d2c", label="R vs WT")
    ax.scatter(aa_delta["WT_delta_pp"], aa_delta["Q_delta_pp"], color="#a63603", label="Q vs WT")
    for _, row in aa_delta.iterrows():
        if row["amino_acid"] in ["Met", "Glu", "Gly", "Asp", "Lys"]:
            ax.text(row["WT_delta_pp"], row["R_delta_pp"], row["amino_acid"], fontsize=6)
            ax.text(row["WT_delta_pp"], row["Q_delta_pp"], row["amino_acid"], fontsize=6)
    ax.axhline(0, color="black", linewidth=0.6)
    ax.axvline(0, color="black", linewidth=0.6)
    ax.set_xlabel("WT amino acid delta (pp)")
    ax.set_ylabel("R/Q amino acid delta (pp)")
    ax.legend(loc="best")
    ax.set_title("Fig3F amino acid response")
    annotate_panel(ax, "F")
    write_source(dirs, "Fig3F_amino_acid_response_validation", aa_delta)
    save_figure(fig, dirs["fig_response"], f"Fig3_R_WT_Q_response_{version}")

    
    fig, axs = plt.subplots(2, 3, figsize=(12, 7))
    write_source(dirs, "Fig4A_GAA_group_dotplot", plot_group_dot(axs[0, 0], prop, "GAA", tests, "Fig4A GAA group dotplot"))
    annotate_panel(axs[0, 0], "A")
    paired_src = plot_paired_slope([axs[0, 1], axs[0, 2], axs[1, 0]], prop, "GAA", "Fig4B GAA paired slope")
    annotate_panel(axs[0, 1], "B")
    write_source(dirs, "Fig4B_GAA_paired_slope", paired_src)
    write_source(dirs, "Fig4C_delta_GAA", plot_delta_dot(axs[1, 1], prop, "GAA", delta_compare, "Fig4C delta GAA"))
    annotate_panel(axs[1, 1], "C")
    glu_values = aa["long"][aa["long"]["amino_acid"] == "Glu"].copy()
    ax = axs[1, 2]
    for group in GROUP_ORDER:
        sub = glu_values[glu_values["group"] == group]
        x = GROUP_ORDER.index(group)
        ax.scatter([x + (r - 2) * 0.08 for r in sub["replicate"]], sub["percent"], color=GROUP_COLORS[group], edgecolor="black", linewidth=0.4)
        ax.errorbar(x, sub["percent"].mean(), yerr=sub["percent"].std(ddof=1), fmt="_", color="black", capsize=3, markersize=12)
    ax.set_xticks(range(len(GROUP_ORDER)))
    ax.set_xticklabels(GROUP_ORDER, rotation=35, ha="right")
    ax.set_ylabel("Glu percent")
    ax.set_title("Fig4D Glu total")
    annotate_panel(ax, "D")
    write_source(dirs, "Fig4D_Glu_total_dotplot", glu_values)
    save_figure(fig, dirs["fig_gaa"], f"Fig4_GAA_Glu_core_{version}")

    fig, axs = plt.subplots(1, 2, figsize=(11, 4))
    share = special["share"].copy()
    share_ordered = share.sort_values("sample_order")
    axs[0].bar(range(len(share_ordered)), share_ordered["GAA_share"], color=FEATURE_COLORS["GAA"], label="GAA")
    axs[0].bar(range(len(share_ordered)), share_ordered["GAG_share"], bottom=share_ordered["GAA_share"], color=FEATURE_COLORS["GAG"], label="GAG")
    axs[0].set_xticks(range(len(share_ordered)))
    axs[0].set_xticklabels(share_ordered["sample"], rotation=60, ha="right")
    axs[0].set_ylabel("share within GAA+GAG")
    axs[0].set_title("Fig4E GAA/GAG synonymous share")
    axs[0].legend()
    annotate_panel(axs[0], "E")
    state_rows = []
    for group, samples in GROUPS.items():
        for sample in samples:
            state_rows.append({"sample": sample, "group": group, "ATG_percent": prop.loc["ATG", sample] * 100, "GAA_percent": prop.loc["GAA", sample] * 100})
    state_df = pd.DataFrame(state_rows).merge(smeta, on=["sample", "group"], how="left")
    for group in GROUP_ORDER:
        sub = state_df[state_df["group"] == group]
        axs[1].scatter(sub["ATG_percent"], sub["GAA_percent"], color=GROUP_COLORS[group], edgecolor="black", linewidth=0.4, label=group)
    for genotype in GENOTYPES:
        ctr_center = state_df[state_df["group"] == f"{genotype}_ctr"][["ATG_percent", "GAA_percent"]].mean()
        test_center = state_df[state_df["group"] == f"{genotype}_test"][["ATG_percent", "GAA_percent"]].mean()
        axs[1].annotate("", xy=test_center, xytext=ctr_center, arrowprops=dict(arrowstyle="->", color=GENOTYPE_COLORS[genotype], lw=1.2))
        axs[1].text(test_center["ATG_percent"], test_center["GAA_percent"], genotype, fontsize=7)
    axs[1].set_xlabel("ATG percent")
    axs[1].set_ylabel("GAA percent")
    axs[1].set_title("Fig4F ATG-GAA state plane")
    annotate_panel(axs[1], "F")
    save_figure(fig, dirs["fig_gaa"], f"Fig4E_F_GAA_GAG_state_plane_{version}")
    write_source(dirs, "Fig4E_GAA_GAG_synonymous_share", share)
    write_source(dirs, "Fig4F_ATG_GAA_state_plane", state_df)

    
    codon_percent = prop[SAMPLE_ORDER] * 100.0
    z = codon_percent.sub(codon_percent.mean(axis=1), axis=0).div(codon_percent.std(axis=1).replace(0, np.nan), axis=0)
    group_mean = pd.DataFrame({group: prop[samples].mean(axis=1) * 100.0 for group, samples in GROUPS.items()})
    delta_heat = delta.set_index("codon").loc[[c for c in prop.index if c not in STOP_CODONS], ["WT_delta_pp", "R_delta_pp", "Q_delta_pp"]]
    fig, axs = plt.subplots(2, 3, figsize=(13, 10))
    heatmap(axs[0, 0], codon_percent, "Fig5A sample percent heatmap", cmap="rocket_r", cbar=True)
    annotate_panel(axs[0, 0], "A")
    heatmap(axs[0, 1], group_mean, "Fig5B group mean heatmap", cmap="rocket_r", cbar=True)
    annotate_panel(axs[0, 1], "B")
    heatmap(axs[0, 2], delta_heat, "Fig5C test-ctr delta heatmap", center=0, cmap="vlag", cbar=True)
    annotate_panel(axs[0, 2], "C")
    ax = axs[1, 0]
    for i, genotype in enumerate(GENOTYPES):
        sub = tests[(tests["genotype"] == genotype) & (~tests["is_stop"])].copy()
        ax.scatter(sub["log2FC"] + i * 0.015, -np.log10(sub["welch_p"]), s=12, alpha=0.55, label=genotype, color=GENOTYPE_COLORS[genotype])
        for codon in ["ATG", "GAA"]:
            r = sub[sub["codon"] == codon].iloc[0]
            ax.text(r["log2FC"] + i * 0.015, -np.log10(r["welch_p"]), f"{genotype}:{codon}", fontsize=6)
    ax.axhline(-np.log10(0.05), color="gray", linestyle="--", linewidth=0.6)
    ax.set_xlabel("log2FC")
    ax.set_ylabel("-log10(P)")
    ax.set_title("Fig5D codon volcano")
    ax.legend()
    annotate_panel(ax, "D")
    ax = axs[1, 1]
    top = delta.copy()
    for genotype in GENOTYPES:
        top[f"{genotype}_abs"] = top[f"{genotype}_delta_pp"].abs()
    top_rows = []
    for genotype in GENOTYPES:
        sub = top[top["is_sense"]].nlargest(15, f"{genotype}_abs")
        for _, row in sub.iterrows():
            top_rows.append({"genotype": genotype, "codon": row["codon"], "delta_pp": row[f"{genotype}_delta_pp"]})
    top_df = pd.DataFrame(top_rows)
    sns.stripplot(data=top_df, x="delta_pp", y="codon", hue="genotype", dodge=True, ax=ax, palette=GENOTYPE_COLORS, size=4)
    ax.axvline(0, color="black", linewidth=0.7)
    ax.set_title("Fig5E top 15 codon deltas")
    annotate_panel(ax, "E")
    ax = axs[1, 2]
    for codon in KEY_CODONS:
        means = [rank[(rank["codon"] == codon) & (rank["group"] == group)]["rank"].mean() for group in GROUP_ORDER]
        ax.plot(range(len(GROUP_ORDER)), means, marker="o", label=codon)
    ax.invert_yaxis()
    ax.set_xticks(range(len(GROUP_ORDER)))
    ax.set_xticklabels(GROUP_ORDER, rotation=35, ha="right")
    ax.set_ylabel("mean rank")
    ax.set_title("Fig5F key codon rank flow")
    ax.legend(ncol=2, fontsize=6)
    annotate_panel(ax, "F")
    save_figure(fig, dirs["fig_codon"], f"Fig5_codon64_landscape_{version}")
    write_source(dirs, "Fig5A_codon64_sample_heatmap", codon_percent.reset_index().rename(columns={"index": "codon"}))
    write_source(dirs, "Fig5A_codon64_sample_zscore_heatmap", z.reset_index().rename(columns={"index": "codon"}))
    write_source(dirs, "Fig5B_codon64_group_mean_heatmap", group_mean.reset_index().rename(columns={"index": "codon"}))
    write_source(dirs, "Fig5C_codon_delta_heatmap", delta_heat.reset_index().rename(columns={"index": "codon"}))
    write_source(dirs, "Fig5D_codon_volcano_triptych", tests)
    write_source(dirs, "Fig5E_top15_codon_delta_lollipop", top_df)
    write_source(dirs, "Fig5F_codon_rank_flow", rank[rank["codon"].isin(KEY_CODONS)])

    
    fig, axs = plt.subplots(2, 3, figsize=(13, 8))
    ax = axs[0, 0]
    top5 = aa["top5"].copy()
    sns.barplot(data=top5, x="mean_percent", y="amino_acid", hue="group", ax=ax, palette=GROUP_COLORS)
    ax.set_title("Fig6A top 5 amino acids")
    annotate_panel(ax, "A")
    ax = axs[0, 1]
    for genotype in GENOTYPES:
        for aa_name in aa["group"]["amino_acid"].unique():
            ctr_rank = aa["group"].loc[(aa["group"]["group"] == f"{genotype}_ctr") & (aa["group"]["amino_acid"] == aa_name), "rank"].iloc[0]
            test_rank = aa["group"].loc[(aa["group"]["group"] == f"{genotype}_test") & (aa["group"]["amino_acid"] == aa_name), "rank"].iloc[0]
            if ctr_rank <= 5 or test_rank <= 5 or aa_name == "Met":
                x0 = GENOTYPES.index(genotype) * 2
                x1 = x0 + 1
                color = GENOTYPE_COLORS[genotype] if aa_name == "Met" else "#999999"
                ax.plot([x0, x1], [ctr_rank, test_rank], marker="o", color=color, alpha=0.8 if aa_name == "Met" else 0.35)
                if aa_name == "Met":
                    ax.text(x1 + 0.03, test_rank, f"{genotype} Met", fontsize=6)
    ax.invert_yaxis()
    ax.set_xticks(range(6))
    ax.set_xticklabels(["WT ctr", "WT test", "R ctr", "R test", "Q ctr", "Q test"], rotation=35, ha="right")
    ax.set_ylabel("rank")
    ax.set_title("Fig6B amino acid rank bump")
    annotate_panel(ax, "B")
    ax = axs[0, 2]
    aa_comp = aa["long"].copy()
    top_aa = aa["group"].groupby("amino_acid")["mean_percent"].mean().sort_values(ascending=False).head(10).index
    aa_comp["display_aa"] = np.where(aa_comp["amino_acid"].isin(top_aa), aa_comp["amino_acid"], "Other")
    comp = aa_comp.groupby(["sample", "sample_order", "display_aa"], as_index=False)["percent"].sum().sort_values("sample_order")
    bottom = np.zeros(len(SAMPLE_ORDER))
    for aa_name, sub in comp.pivot(index="sample", columns="display_aa", values="percent").loc[SAMPLE_ORDER].fillna(0).items():
        ax.bar(range(len(SAMPLE_ORDER)), sub.values, bottom=bottom, label=aa_name)
        bottom += sub.values
    ax.set_xticks(range(len(SAMPLE_ORDER)))
    ax.set_xticklabels(SAMPLE_ORDER, rotation=60, ha="right")
    ax.set_ylabel("amino acid percent")
    ax.set_title("Fig6C amino acid composition")
    ax.legend(ncol=2, fontsize=5, bbox_to_anchor=(1.02, 1), loc="upper left")
    annotate_panel(ax, "C")
    ax = axs[1, 0]
    aa_tests = aa["tests"].copy()
    sns.stripplot(data=aa_tests, x="difference_pp", y="amino_acid", hue="genotype", dodge=True, palette=GENOTYPE_COLORS, ax=ax, size=4)
    ax.axvline(0, color="black", linewidth=0.7)
    ax.set_title("Fig6D amino acid delta")
    annotate_panel(ax, "D")
    ax = axs[1, 1]
    sub = aa_tests[aa_tests["amino_acid"].isin(["Met", "Glu", "Gly", "Asp", "Lys", "Asn", "Leu", "Ser", "Arg"])].copy()
    sns.pointplot(data=sub, x="difference_pp", y="amino_acid", hue="genotype", dodge=0.4, palette=GENOTYPE_COLORS, ax=ax, errorbar=None)
    ax.axvline(0, color="black", linewidth=0.7)
    ax.set_title("Fig6E amino acid effect forest")
    annotate_panel(ax, "E")
    ax = axs[1, 2]
    fam = aa["families"].copy()
    fam_summary = fam.groupby(["amino_acid", "codon"], as_index=False)["family_share"].mean()
    sns.barplot(data=fam_summary, x="amino_acid", y="family_share", hue="codon", ax=ax)
    ax.set_title("Fig6F synonymous codon families")
    ax.tick_params(axis="x", rotation=35)
    annotate_panel(ax, "F")
    save_figure(fig, dirs["fig_aa"], f"Fig6_amino_acid_changes_{version}")
    write_source(dirs, "Fig6A_top5_amino_acids_each_group", top5)
    write_source(dirs, "Fig6B_amino_acid_rank_bump", aa["group"])
    write_source(dirs, "Fig6C_amino_acid_composition", comp)
    write_source(dirs, "Fig6D_amino_acid_delta_lollipop", aa_tests)
    write_source(dirs, "Fig6E_amino_acid_effect_forest", sub)
    write_source(dirs, "Fig6F_synonymous_codon_families", fam)

    
    fig, axs = plt.subplots(2, 3, figsize=(13, 8))
    sns.heatmap(sim["spearman"].loc[SAMPLE_ORDER, SAMPLE_ORDER], ax=axs[0, 0], cmap="mako", vmin=0.8, vmax=1.0)
    axs[0, 0].set_title("Fig7A sample Spearman")
    annotate_panel(axs[0, 0], "A")
    ax = axs[0, 1]
    condensed = squareform(sim["euclid"].loc[SAMPLE_ORDER, SAMPLE_ORDER].to_numpy(), checks=False)
    linkage = hierarchy.linkage(condensed, method="average")
    hierarchy.dendrogram(linkage, labels=SAMPLE_ORDER, ax=ax, leaf_rotation=90, leaf_font_size=6)
    ax.set_title("Fig7B sample dendrogram")
    annotate_panel(ax, "B")
    ax = axs[0, 2]
    for group in GROUP_ORDER:
        sub = sim["pca"][sim["pca"]["group"] == group]
        ax.scatter(sub["PC1"], sub["PC2"], color=GROUP_COLORS[group], edgecolor="black", linewidth=0.4, label=group)
    for genotype in GENOTYPES:
        ctr = sim["pca"][sim["pca"]["group"] == f"{genotype}_ctr"][["PC1", "PC2"]].mean()
        test = sim["pca"][sim["pca"]["group"] == f"{genotype}_test"][["PC1", "PC2"]].mean()
        ax.annotate("", xy=test, xytext=ctr, arrowprops=dict(arrowstyle="->", color=GENOTYPE_COLORS[genotype]))
    ax.set_title("Fig7C PCA state arrows")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    annotate_panel(ax, "C")
    ax = axs[1, 0]
    for group in GROUP_ORDER:
        sub = sim["mds"][sim["mds"]["group"] == group]
        ax.scatter(sub["MDS1"], sub["MDS2"], color=GROUP_COLORS[group], edgecolor="black", linewidth=0.4, label=group)
    ax.set_title("Fig7D MDS")
    ax.set_xlabel("MDS1")
    ax.set_ylabel("MDS2")
    annotate_panel(ax, "D")
    ax = axs[1, 1]
    state = sim["state"].copy()
    for i, group in enumerate(["Q_ctr", "Q_test", "R_ctr", "R_test"]):
        sub = state[state["group"] == group]
        ax.scatter([i + (r - 2) * 0.08 for r in sub["replicate"]], sub["StateAffinity"], color=GROUP_COLORS[group], edgecolor="black", linewidth=0.4)
        ax.errorbar(i, sub["StateAffinity"].mean(), yerr=sub["StateAffinity"].std(ddof=1), fmt="_", color="black", capsize=3, markersize=12)
        p = sim["state_group"].loc[sim["state_group"]["group"] == group, "one_sample_p"].iloc[0]
        ax.text(i, sub["StateAffinity"].max(), f"P={fmt_p(p)}", ha="center", va="bottom", fontsize=6)
    ax.axhline(0, color="black", linewidth=0.7)
    ax.set_xticks(range(4))
    ax.set_xticklabels(["Q_ctr", "Q_test", "R_ctr", "R_test"], rotation=35, ha="right")
    ax.set_ylabel("StateAffinity")
    ax.set_title("Fig7E WT state affinity")
    annotate_panel(ax, "E")
    ax = axs[1, 2]
    for i, row in state.sort_values(["group_order", "replicate"]).reset_index(drop=True).iterrows():
        ax.plot([row["distance_to_WT_ctr"], row["distance_to_WT_test"]], [i, i], color="#777777", linewidth=0.8)
        ax.scatter(row["distance_to_WT_ctr"], i, color="#9ecae1", label="WT_ctr" if i == 0 else None)
        ax.scatter(row["distance_to_WT_test"], i, color="#08519c", label="WT_test" if i == 0 else None)
        ax.text(max(row["distance_to_WT_ctr"], row["distance_to_WT_test"]), i, row["sample"], fontsize=6, va="center")
    ax.set_xlabel("Euclidean distance")
    ax.set_yticks([])
    ax.legend()
    ax.set_title("Fig7F distance to WT centroids")
    annotate_panel(ax, "F")
    save_figure(fig, dirs["fig_similarity"], f"Fig7_similarity_state_affinity_{version}")
    write_source(dirs, "Fig7A_sample_spearman_heatmap", sim["spearman"].reset_index().rename(columns={"index": "sample"}))
    write_source(dirs, "Fig7C_sample_PCA_state_arrows", sim["pca"])
    write_source(dirs, "Fig7D_sample_MDS", sim["mds"])
    write_source(dirs, "Fig7E_state_affinity", state.merge(sim["state_group"], on="group", how="left"))
    write_source(dirs, "Fig7F_distance_to_WT_centroids", state)

    
    fig, axs = plt.subplots(1, 3, figsize=(13, 4))
    coords = sim["pca"].set_index("sample")
    nn_top = sim["nearest"][sim["nearest"]["rank"] <= 2].copy()
    for _, edge in nn_top.iterrows():
        a = coords.loc[edge["sample"]]
        b = coords.loc[edge["neighbor"]]
        axs[0].plot([a["PC1"], b["PC1"]], [a["PC2"], b["PC2"]], color="#999999", alpha=0.35 + 0.6 * (edge["spearman"] - 0.8) / 0.2, linewidth=0.8)
    for group in GROUP_ORDER:
        sub = sim["pca"][sim["pca"]["group"] == group]
        axs[0].scatter(sub["PC1"], sub["PC2"], color=GROUP_COLORS[group], edgecolor="black", linewidth=0.4, label=group)
    axs[0].set_title("Fig8A nearest-neighbor network")
    sns.heatmap(sim["centroid_corr"].loc[GROUP_ORDER, GROUP_ORDER], ax=axs[1], cmap="mako", vmin=0.8, vmax=1.0, annot=True, fmt=".2f")
    axs[1].set_title("Fig8C group centroid similarity")
    pairs = []
    for a_group, b_group in itertools.combinations(GROUP_ORDER, 2):
        pairs.append({"pair": f"{a_group} vs {b_group}", "spearman": sim["centroid_corr"].loc[a_group, b_group], "euclidean": sim["centroid_dist"].loc[a_group, b_group]})
    pairs_df = pd.DataFrame(pairs).sort_values("spearman", ascending=False)
    sns.barplot(data=pairs_df, x="spearman", y="pair", ax=axs[2], color="#4c78a8")
    axs[2].set_title("Fig8D all 15 group-pair ranks")
    save_figure(fig, dirs["fig_similarity"], f"Fig8_nearest_neighbor_centroids_{version}")
    write_source(dirs, "Fig8A_nearest_neighbor_network", nn_top)
    write_source(dirs, "Fig8C_group_centroid_similarity", sim["centroid_corr"].reset_index().rename(columns={"index": "group"}))
    write_source(dirs, "Fig8D_all15_pairwise_rank", pairs_df)

    
    fig, axs = plt.subplots(2, 3, figsize=(13, 8))
    r_samples = GROUPS["R_ctr"] + GROUPS["R_test"]
    ax = axs[0, 0]
    vals = prop.loc["ATG", r_samples] * 100.0
    ax.scatter(range(len(r_samples)), vals, color=[GROUP_COLORS["R_ctr"]] * 3 + [GROUP_COLORS["R_test"]] * 3, edgecolor="black", linewidth=0.4)
    ax.text(r_samples.index("R_test2"), vals["R_test2"], "R_test2", fontsize=7, fontweight="bold")
    ax.set_xticks(range(len(r_samples)))
    ax.set_xticklabels(r_samples, rotation=35, ha="right")
    ax.set_ylabel("ATG percent")
    ax.set_title("Fig9A R ATG replicate detail")
    annotate_panel(ax, "A")
    ax = axs[0, 1]
    rtest_state = state[state["sample"].isin(GROUPS["R_test"])]
    for i, row in rtest_state.reset_index(drop=True).iterrows():
        ax.plot([0, 1], [row["distance_to_WT_ctr"], row["distance_to_WT_test"]], marker="o", color=GROUP_COLORS["R_test"])
        ax.text(1.03, row["distance_to_WT_test"], row["sample"], fontsize=7)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["WT_ctr", "WT_test"])
    ax.set_ylabel("Euclidean distance")
    ax.set_title("Fig9B R_test WT distance")
    annotate_panel(ax, "B")
    ax = axs[0, 2]
    codon_order = group_mean["R_test"].sort_values(ascending=False).index
    for sample in GROUPS["R_test"]:
        ax.plot(range(len(codon_order)), prop.loc[codon_order, sample] * 100.0, label=sample, linewidth=0.8)
    atg_idx = list(codon_order).index("ATG")
    ax.axvline(atg_idx, color=FEATURE_COLORS["ATG"], linestyle="--", linewidth=0.8)
    ax.set_xticks([])
    ax.set_ylabel("percent")
    ax.set_title("Fig9C R_test codon profiles")
    ax.legend()
    annotate_panel(ax, "C")
    ax = axs[1, 0]
    residual = (prop["R_test2"] - prop[["R_test1", "R_test3"]].mean(axis=1)) * 100.0
    residual_df = residual.rename("R_test2_residual_pp").reset_index().rename(columns={"index": "codon"}).merge(cmeta.reset_index(), on="codon", how="left")
    residual_top = residual_df.reindex(residual_df["R_test2_residual_pp"].abs().sort_values(ascending=False).index).head(20)
    sns.barplot(data=residual_top, x="R_test2_residual_pp", y="codon", ax=ax, color="#756bb1")
    ax.axvline(0, color="black", linewidth=0.7)
    ax.set_title("Fig9D R_test2 residual top codons")
    annotate_panel(ax, "D")
    ax = axs[1, 1]
    rtest = prop[GROUPS["R_test"]]
    corr_all = rtest.corr(method="pearson")
    corr_no_atg = rtest.drop(index="ATG").corr(method="pearson")
    dep_rows = []
    for a, b in itertools.combinations(GROUPS["R_test"], 2):
        dep_rows.append({"pair": f"{a}-{b}", "feature_set": "all64", "pearson": corr_all.loc[a, b]})
        dep_rows.append({"pair": f"{a}-{b}", "feature_set": "without_ATG", "pearson": corr_no_atg.loc[a, b]})
    dep_df = pd.DataFrame(dep_rows)
    sns.barplot(data=dep_df, x="pair", y="pearson", hue="feature_set", ax=ax)
    ax.set_ylim(0.8, 1.0)
    ax.tick_params(axis="x", rotation=35)
    ax.set_title("Fig9E R_test ATG dependency")
    annotate_panel(ax, "E")
    ax = axs[1, 2]
    loo_rows = []
    for dropped in ["none", "R_test1", "R_test2", "R_test3"]:
        test_samples = GROUPS["R_test"] if dropped == "none" else [s for s in GROUPS["R_test"] if s != dropped]
        diff = (prop.loc["ATG", test_samples].mean() - prop.loc["ATG", GROUPS["R_ctr"]].mean()) * 100.0
        loo_rows.append({"dropped": dropped, "ATG_difference_pp": diff})
    loo_df = pd.DataFrame(loo_rows)
    sns.barplot(data=loo_df, x="dropped", y="ATG_difference_pp", ax=ax, color=GROUP_COLORS["R_test"])
    ax.axhline(0, color="black", linewidth=0.7)
    ax.tick_params(axis="x", rotation=35)
    ax.set_title("Fig9F R ATG leave-one-out")
    annotate_panel(ax, "F")
    save_figure(fig, dirs["fig_rtest2"], f"Fig9_Rtest2_diagnostics_{version}")
    write_source(dirs, "Fig9A_R_ATG_replicate_detail", pd.DataFrame({"sample": r_samples, "ATG_percent": vals.values}))
    write_source(dirs, "Fig9B_Rtest_WT_distance", rtest_state)
    write_source(dirs, "Fig9C_Rtest_codon_profiles", prop.loc[codon_order, GROUPS["R_test"]].reset_index().rename(columns={"index": "codon"}))
    write_source(dirs, "Fig9D_Rtest2_residual", residual_df)
    write_source(dirs, "Fig9E_Rtest_ATG_dependency", dep_df)
    write_source(dirs, "Fig9F_R_ATG_leave_one_out", loo_df)

    
    fig = plt.figure(figsize=(13, 8))
    gs = gridspec.GridSpec(2, 3, figure=fig)
    ax1 = fig.add_subplot(gs[0, 0])
    plot_group_dot(ax1, prop, "ATG", tests, "Fig10A ATG")
    annotate_panel(ax1, "A")
    ax2 = fig.add_subplot(gs[0, 1])
    plot_delta_dot(ax2, prop, "ATG", delta_compare, "Fig10B delta ATG")
    annotate_panel(ax2, "B")
    ax3 = fig.add_subplot(gs[0, 2])
    plot_response_scatter(ax3, delta, "WT", "R", "Fig10C WT-R")
    plot_response_scatter(ax3, delta, "WT", "Q", "Fig10C WT-Q")
    annotate_panel(ax3, "C")
    ax4 = fig.add_subplot(gs[1, 0])
    for comp, sub in corr_src.groupby("comparison"):
        sub = sub.set_index("feature_set").loc[["sense_61", "sense_without_ATG_60"]].reset_index()
        y = ["R_vs_WT", "Q_vs_WT", "Q_vs_R"].index(comp)
        ax4.plot(sub["pearson_r"], [y, y], marker="o")
    ax4.axvline(0, color="black", linewidth=0.7)
    ax4.set_yticks(range(3))
    ax4.set_yticklabels(["R-WT", "Q-WT", "Q-R"])
    ax4.set_xlabel("Pearson r")
    ax4.set_title("Fig10D ATG sensitivity")
    annotate_panel(ax4, "D")
    ax5 = fig.add_subplot(gs[1, 1])
    met = aa["group"][aa["group"]["amino_acid"] == "Met"].copy()
    sns.barplot(data=met, x="group", y="rank", ax=ax5, palette=GROUP_COLORS, hue="group", legend=False)
    ax5.invert_yaxis()
    ax5.tick_params(axis="x", rotation=35)
    ax5.set_title("Fig10E Met rank")
    annotate_panel(ax5, "E")
    ax6 = fig.add_subplot(gs[1, 2])
    for i, group in enumerate(["Q_ctr", "Q_test", "R_ctr", "R_test"]):
        sub = state[state["group"] == group]
        ax6.scatter([i + (r - 2) * 0.08 for r in sub["replicate"]], sub["StateAffinity"], color=GROUP_COLORS[group], edgecolor="black", linewidth=0.4)
        ax6.errorbar(i, sub["StateAffinity"].mean(), yerr=sub["StateAffinity"].std(ddof=1), fmt="_", color="black", capsize=3, markersize=12)
    ax6.axhline(0, color="black", linewidth=0.7)
    ax6.set_xticks(range(4))
    ax6.set_xticklabels(["Q_ctr", "Q_test", "R_ctr", "R_test"], rotation=35, ha="right")
    ax6.set_ylabel("StateAffinity")
    ax6.set_title("Fig10F WT StateAffinity")
    annotate_panel(ax6, "F")
    fig.suptitle("Genotype-specific remodeling of P-site codon composition")
    save_figure(fig, dirs["fig_assemblies"], f"Fig10_integrated_summary_{version}")

    
    fig, ax = plt.subplots(figsize=(10, 11))
    heatmap(ax, codon_percent, "Supplementary Fig S3 complete 64-codon percent heatmap", cmap="rocket_r")
    save_figure(fig, dirs["fig_supp"], f"FigS3_codon64_percent_heatmap_{version}")
    fig, ax = plt.subplots(figsize=(10, 11))
    heatmap(ax, z, "Supplementary Fig S4 complete 64-codon row Z-score heatmap", center=0, cmap="vlag")
    save_figure(fig, dirs["fig_supp"], f"FigS4_codon64_zscore_heatmap_{version}")

    group_pairs = list(itertools.combinations(GROUP_ORDER, 2))
    fig, axs = plt.subplots(5, 3, figsize=(11, 15))
    for ax, (a_group, b_group) in zip(axs.ravel(), group_pairs):
        x = group_mean[a_group]
        y = group_mean[b_group]
        ax.scatter(x, y, s=12, color="#666666", alpha=0.6)
        for codon in ["ATG", "GAA"]:
            ax.scatter(x.loc[codon], y.loc[codon], color=FEATURE_COLORS[codon], edgecolor="black", s=35)
            ax.text(x.loc[codon], y.loc[codon], codon, fontsize=6)
        lim = max(x.max(), y.max()) * 1.08
        ax.plot([0, lim], [0, lim], color="gray", linestyle="--", linewidth=0.5)
        r, p = stats.pearsonr(x, y)
        ax.set_title(f"{a_group} vs {b_group}\nr={r:.2f}, P={fmt_p(p)}", fontsize=7)
        ax.set_xlim(0, lim)
        ax.set_ylim(0, lim)
    save_figure(fig, dirs["fig_supp"], f"FigS5_all15_group_scatter_{version}")

    fig, axs = plt.subplots(5, 3, figsize=(11, 15))
    ba_rows = []
    for ax, (a_group, b_group) in zip(axs.ravel(), group_pairs):
        x = group_mean[a_group]
        y = group_mean[b_group]
        mean_xy = (x + y) / 2
        diff_xy = y - x
        ax.scatter(mean_xy, diff_xy, s=12, color="#666666", alpha=0.6)
        for codon in ["ATG", "GAA"]:
            ax.scatter(mean_xy.loc[codon], diff_xy.loc[codon], color=FEATURE_COLORS[codon], edgecolor="black", s=35)
            ax.text(mean_xy.loc[codon], diff_xy.loc[codon], codon, fontsize=6)
        ax.axhline(0, color="black", linewidth=0.6)
        ax.set_title(f"{a_group} vs {b_group}", fontsize=7)
        for codon in group_mean.index:
            ba_rows.append({"pair": f"{a_group}_vs_{b_group}", "codon": codon, "mean_percent": mean_xy.loc[codon], "difference_percent": diff_xy.loc[codon]})
    save_figure(fig, dirs["fig_supp"], f"FigS6_all15_bland_altman_{version}")
    write_source(dirs, "FigS6_all15_bland_altman", pd.DataFrame(ba_rows))

    fig, ax = plt.subplots(figsize=(8, 4))
    sns.barplot(data=response["corr"], x="comparison", y="pearson_r", hue="feature_set", ax=ax)
    ax.axhline(0, color="black", linewidth=0.7)
    ax.set_title("Supplementary Fig S7 64/61/60 codon sensitivity")
    ax.tick_params(axis="x", rotation=35)
    save_figure(fig, dirs["fig_supp"], f"FigS7_64_61_60_sensitivity_{version}")
    write_source(dirs, "FigS7_64_61_60_sensitivity", response["corr"])

    aa_matrix = aa["aa_prop"][SAMPLE_ORDER] * 100.0
    fig, ax = plt.subplots(figsize=(10, 6))
    heatmap(ax, aa_matrix, "Supplementary Fig S8 20 amino acid sample heatmap", cmap="rocket_r")
    save_figure(fig, dirs["fig_supp"], f"FigS8_amino_acid_sample_heatmap_{version}")
    write_source(dirs, "FigS8_amino_acid_sample_heatmap", aa_matrix.reset_index().rename(columns={"index": "amino_acid"}))

    fig, ax = plt.subplots(figsize=(11, 5))
    bottom = np.zeros(len(SAMPLE_ORDER))
    aa_pivot = aa["long"].pivot(index="sample", columns="amino_acid", values="percent").loc[SAMPLE_ORDER, aa["aa_prop"].index]
    for aa_name in aa_pivot.columns:
        ax.bar(range(len(SAMPLE_ORDER)), aa_pivot[aa_name].values, bottom=bottom, label=aa_name)
        bottom += aa_pivot[aa_name].values
    ax.set_xticks(range(len(SAMPLE_ORDER)))
    ax.set_xticklabels(SAMPLE_ORDER, rotation=60, ha="right")
    ax.set_ylabel("amino acid percent")
    ax.set_title("Supplementary Fig S9 full 20 amino acid composition")
    ax.legend(ncol=4, fontsize=5, bbox_to_anchor=(1.02, 1), loc="upper left")
    save_figure(fig, dirs["fig_supp"], f"FigS9_full_amino_acid_composition_{version}")
    write_source(dirs, "FigS9_full_amino_acid_composition", aa["long"])

    fig, ax = plt.subplots(figsize=(10, 5))
    fam_group = aa["families"].groupby(["amino_acid", "codon", "group"], as_index=False)["family_share"].mean()
    sns.barplot(data=fam_group, x="amino_acid", y="family_share", hue="codon", ax=ax)
    ax.set_title("Supplementary Fig S10 all selected synonymous codon families")
    ax.tick_params(axis="x", rotation=35)
    save_figure(fig, dirs["fig_supp"], f"FigS10_synonymous_codon_families_{version}")
    write_source(dirs, "FigS10_synonymous_codon_families", fam_group)

    cv_rows = []
    for codon in prop.index:
        for group, samples in GROUPS.items():
            vals = prop.loc[codon, samples] * 100.0
            cv_rows.append({"codon": codon, "group": group, "mean_percent": vals.mean(), "sd_percent": vals.std(ddof=1), "cv": vals.std(ddof=1) / vals.mean() if vals.mean() else np.nan})
    cv_df = pd.DataFrame(cv_rows).merge(cmeta.reset_index(), on="codon", how="left")
    fig, ax = plt.subplots(figsize=(9, 5))
    sns.stripplot(data=cv_df, x="group", y="cv", ax=ax, palette=GROUP_COLORS, hue="group", legend=False)
    atg_cv = cv_df[cv_df["codon"] == "ATG"]
    ax.scatter([GROUP_ORDER.index(g) for g in atg_cv["group"]], atg_cv["cv"], color=FEATURE_COLORS["ATG"], edgecolor="black", s=45, label="ATG")
    ax.set_title("Supplementary Fig S11 codon CV by group")
    ax.tick_params(axis="x", rotation=35)
    ax.legend()
    save_figure(fig, dirs["fig_supp"], f"FigS11_codon_group_CV_{version}")
    write_source(dirs, "FigS11_codon_group_CV", cv_df)


def write_key_results(
    dirs: dict[str, Path],
    codon_tests: pd.DataFrame,
    response: dict[str, pd.DataFrame],
    aa: dict[str, pd.DataFrame],
    sim: dict[str, pd.DataFrame],
    qc_gate: pd.DataFrame,
    version: str,
) -> None:
    rows = []
    for codon in ["ATG", "GAA"]:
        for genotype in GENOTYPES:
            r = codon_tests[(codon_tests["codon"] == codon) & (codon_tests["genotype"] == genotype)].iloc[0]
            rows.append(
                {
                    "category": codon,
                    "item": genotype,
                    "value": f"{r['ctr_mean_percent']:.3f}% -> {r['test_mean_percent']:.3f}%; diff={r['difference_pp']:+.3f} pp; Welch P={fmt_p(r['welch_p'])}; q={fmt_p(r['BH_q'])}",
                }
            )
    for _, r in response["corr"].iterrows():
        if r["feature_set"] in ["sense_61", "sense_without_ATG_60"]:
            rows.append({"category": "codon_response_correlation", "item": f"{r['comparison']} {r['feature_set']}", "value": f"Pearson r={r['pearson_r']:.3f}, P={fmt_p(r['pearson_p'])}, n={int(r['n'])}"})
    state_summary = sim["state_group"].copy()
    for _, r in state_summary.iterrows():
        rows.append({"category": "WT_StateAffinity", "item": r["group"], "value": f"mean={r['mean_StateAffinity']:.5f}, P={fmt_p(r['one_sample_p'])}"})
    for aa_name in ["Met", "Glu", "Gly", "Asp", "Lys"]:
        for genotype in GENOTYPES:
            r = aa["tests"][(aa["tests"]["amino_acid"] == aa_name) & (aa["tests"]["genotype"] == genotype)].iloc[0]
            rows.append({"category": "amino_acid", "item": f"{aa_name}_{genotype}", "value": f"diff={r['difference_pp']:+.3f} pp, P={fmt_p(r['welch_p'])}, q={fmt_p(r['BH_q'])}"})
    rows.append({"category": "numeric_gates", "item": "all", "value": "passed" if qc_gate["passed"].all() else "failed"})
    key = pd.DataFrame(rows)
    key.to_csv(dirs["report"] / f"codon64_key_results_{version}.tsv", sep="\t", index=False)


def write_report(
    dirs: dict[str, Path],
    codon_tests: pd.DataFrame,
    response: dict[str, pd.DataFrame],
    sim: dict[str, pd.DataFrame],
    qc_checks_df: pd.DataFrame,
    gate: pd.DataFrame,
    out_root: Path,
    version: str,
) -> None:
    def stat_line(codon: str, genotype: str) -> str:
        row = codon_tests[(codon_tests["codon"] == codon) & (codon_tests["genotype"] == genotype)].iloc[0]
        return (
            f"{genotype}: ctr {row['ctr_mean_percent']:.2f}% +/- {row['ctr_sd_percent']:.2f}%, "
            f"test {row['test_mean_percent']:.2f}% +/- {row['test_sd_percent']:.2f}%, "
            f"diff {row['difference_pp']:+.2f} pp, Welch P={fmt_p(row['welch_p'])}, BH q={fmt_p(row['BH_q'])}"
        )

    corr = response["corr"]
    corr_lines = []
    for comp in ["R_vs_WT", "Q_vs_WT", "Q_vs_R"]:
        all61 = corr[(corr["comparison"] == comp) & (corr["feature_set"] == "sense_61")].iloc[0]
        no_atg = corr[(corr["comparison"] == comp) & (corr["feature_set"] == "sense_without_ATG_60")].iloc[0]
        corr_lines.append(
            f"- {comp}: all 61 r={all61['pearson_r']:.3f}, P={fmt_p(all61['pearson_p'])}; without ATG r={no_atg['pearson_r']:.3f}, P={fmt_p(no_atg['pearson_p'])}"
        )

    state_lines = []
    for _, r in sim["state_group"].iterrows():
        state_lines.append(f"- {r['group']}: mean StateAffinity={r['mean_StateAffinity']:.5f}, P={fmt_p(r['one_sample_p'])}")

    sections = [
        "# RIBO-seq 64 codon analysis report v1.2",
        "",
        f"Output directory: `{out_root}`",
        "",
        "## 1. 输入与归一化 QC",
        "",
        "目的：确认 64 个密码子、18 个样本、归一化和长表结构完整。",
        "",
        f"QC 结果：{int(qc_checks_df['passed'].sum())}/{len(qc_checks_df)} 项通过；数值闸门 {int(gate['passed'].sum())}/{len(gate)} 项通过。",
        "",
        "解释边界：raw count 仅用于测序深度和完整性 QC，不用于跨样本比较密码子高低。",
        "",
        "## 2. ATG 专项结果",
        "",
        "目的：检验 ATG 在 WT/R/Q 的 ctr 到 test 状态变化。",
        "",
        "\n".join([f"- {stat_line('ATG', g)}" for g in GENOTYPES]),
        "",
        "主要观察：WT 和 R 的 ATG 平均值同向升高；R 组因 R_test2 幅度较小导致 SD 增大；Q 从极高 ATG 水平显著下降。",
        "",
        "解释边界：该结果描述 P-site 密码子组成变化，不能单独证明 ATG 位于翻译起始位点或构成起始暂停。",
        "",
        "## 3. GAA/GAG 与 Glu",
        "",
        "目的：区分 GAA 单密码子变化、Glu 总量变化和 GAA/GAG 同义密码子内部重排。",
        "",
        "\n".join([f"- {stat_line('GAA', g)}" for g in GENOTYPES]),
        "",
        "主要观察：WT 中 GAA 显著下降，R 同向下降但未达显著，Q 基本不变。GAA/GAG share 表用于判断 Glu 内部密码子选择是否改变。",
        "",
        "## 4. R-WT 相似与 Q 反向",
        "",
        "目的：用 61 个有义密码子的 test-ctr 变化向量检验整体响应方向。",
        "",
        "\n".join(corr_lines),
        "",
        "主要观察：R-WT 的正相关在去除 ATG 后仍保留；Q 与 WT/R 的负相关在去除 ATG 后消失或转为弱正相关，说明 Q 的反向特征主要由 ATG/Met 驱动。",
        "",
        "解释边界：相关 P 值是密码子集合层面的粗略显著性，不等同于生物学重复层面的组间检验。",
        "",
        "## 5. 氨基酸、状态归属和 R_test2",
        "",
        "目的：将密码子信号合并到氨基酸层面，并评估样本相对 WT_ctr/WT_test 的状态接近性。",
        "",
        "\n".join(state_lines),
        "",
        "主要观察：Met 在 WT/R test 状态升高并进入前列，而 Q 从 Met 极高的 ctr 状态下降。R_test2 被作为异质性专题展示，不被删除。",
        "",
        "## 6. 图形验收清单",
        "",
        "- 所有主图使用 proportion/percent，而不是跨样本 raw count。",
        "- 组间图显示 3 个生物学重复点和 mean +/- SD 或 CI。",
        "- ATG 和 GAA 在相关图、热图和火山图中均被标记。",
        "- WT、R、Q 组顺序固定为 WT_ctr, WT_test, R_ctr, R_test, Q_ctr, Q_test。",
        "- Fig3 显示去除 ATG 前后的相关变化。",
        "- Fig4 区分 GAA、Glu 总量和 GAA/GAG share。",
        "- leave-one-out 只作为敏感性描述，不用于删除样本。",
        "",
        "## 7. 最终核心结论",
        "",
        "归一化后的 64 密码子分析显示，ATG 是区分基因型和状态的最突出密码子。WT 中 ATG 稳定升高，R 的平均 ATG 变化幅度与 WT 接近但受 R_test2 异质性影响，Q 呈相反方向的显著下降。61 个有义密码子的状态变化向量表明，R 与 WT 高度正相关；去除 ATG 后，该正相关仍然存在。Q 与 WT/R 在包含 ATG 时呈负相关，但去除 ATG 后负相关消失，支持 Q 的反向表型主要集中在 ATG/Met，而不是全部密码子的普遍反转。",
        "",
        "重要限制：当前表格未区分 CDS 起始 ATG 与内部 ATG，也未按每个密码子的基因组或转录组出现机会数校正，因此不能仅凭本结果将 ATG 富集直接定义为翻译起始暂停。",
        "",
    ]
    report = "\n".join(sections)
    (dirs["report"] / f"codon64_analysis_report_{version}.md").write_text(report, encoding="utf-8")


def main() -> None:
    args = parse_args()
    input_dir = Path(args.input_dir).resolve()
    out_root, dirs = setup_output(args.out)
    copy_self_and_inputs(input_dir, dirs)

    raw, rpm, prop, long = read_inputs(input_dir)
    raw = raw.loc[:, [c for c in raw.columns]]
    rpm = rpm.loc[:, [c for c in rpm.columns]]
    prop = prop.loc[:, [c for c in prop.columns]]
    qc_checks_df = qc_checks(raw, rpm, prop, long, dirs)
    long_table = build_long_table(raw, rpm, prop, dirs)
    stats_tables = compute_codon_stats(prop, dirs)
    special = compute_special_atg_gaa(prop, stats_tables, dirs)
    response = compute_response_similarity(prop, dirs)
    aa = compute_amino_acids(prop, dirs)
    sim = compute_similarity(prop, dirs)
    gate = validate_numeric_gates(stats_tables["tests"], response["corr"], dirs)
    plot_all_figures(raw=raw, rpm=rpm, prop=prop, long=long_table, stats_tables=stats_tables, special=special, response=response, aa=aa, sim=sim, dirs=dirs, version=args.version)
    write_key_results(dirs, stats_tables["tests"], response, aa, sim, gate, args.version)
    write_report(dirs, stats_tables["tests"], response, sim, qc_checks_df, gate, out_root, args.version)
    print(f"Analysis complete: {out_root}")
    print(f"Report: {dirs['report'] / f'codon64_analysis_report_{args.version}.md'}")
    print(f"Numeric gates: {dirs['qc'] / 'numeric_gates.tsv'}")


if __name__ == "__main__":
    main()
