#!/usr/bin/env python3


from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd
import PIL
import scipy
from PIL import Image
from scipy import stats


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "01_raw_inputs"
FROZEN = ROOT / "02_frozen_inputs"
SOURCE = ROOT / "04_source_data"
OUTPUT = ROOT / "05_outputs"
QA = ROOT / "07_qa"
STEM = "Fig6e_Qctr_Rctr_state_affinity_square_nature_v1.0_20260823"
EXPECTED_SAMPLES = ["Q_ctr1", "Q_ctr2", "Q_ctr3", "R_ctr1", "R_ctr2", "R_ctr3"]
EXPECTED_HASHES = {
    "01_raw_inputs/codon64_proportions.tsv": "33e07424f1aaf3609a2b1883f58737ba789fd7e34d5f7c88a2837fc717908960",
    "01_raw_inputs/codon64_raw_counts.tsv": "adc1b040abe07706f717a6d42d3a80a8a864a265e2579609a2383b7cf3270aff",
    "01_raw_inputs/codon64_raw_rpm_proportion.tsv": "af3a4891b2e83d42c991e5abc85f0f6069de87790d291ef431451ae3cbd91ecf",
    "01_raw_inputs/codon64_rpm.tsv": "34f1b5bfd95cc89939caf6bc72569caab4a2500c01245a1b5f839803b70fe554",
    "02_frozen_inputs/WT_state_affinity_by_sample.tsv": "676e6ed9dadc6dba821545e5893e25a649850c356caf19555625b1179915131c",
    "02_frozen_inputs/WT_state_affinity_group_stats.tsv": "667cd3b487a04f607dff37d6f80ffa10b2268aa8c096d186702456677d33143d",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class Audit:
    def __init__(self) -> None:
        self.rows: list[dict[str, object]] = []

    def check(self, name: str, passed: bool, observed: object, expected: object) -> None:
        self.rows.append({"check": name, "passed": bool(passed), "observed": str(observed), "expected": str(expected)})
        if not passed:
            raise AssertionError(f"{name}: observed={observed}; expected={expected}")


def assert_numeric_frame_equal(audit: Audit, name: str, observed: pd.DataFrame, expected: pd.DataFrame) -> None:
    audit.check(f"{name}:columns", observed.columns.tolist() == expected.columns.tolist(), observed.columns.tolist(), expected.columns.tolist())
    audit.check(f"{name}:rows", len(observed) == len(expected), len(observed), len(expected))
    for column in observed.columns:
        if pd.api.types.is_numeric_dtype(expected[column]):
            left = observed[column].to_numpy(float)
            right = expected[column].to_numpy(float)
            difference = float(np.max(np.abs(left - right))) if len(left) else 0.0
            audit.check(f"{name}:{column}", np.allclose(left, right, rtol=0, atol=2e-15), difference, "max abs diff <= 2e-15")
        else:
            left = observed[column].astype(str).tolist()
            right = expected[column].astype(str).tolist()
            audit.check(f"{name}:{column}", left == right, left, right)


def run_text(command: list[str]) -> str:
    return subprocess.run(command, check=True, capture_output=True, text=True).stdout


def validate() -> Audit:
    audit = Audit()
    for relative, expected in EXPECTED_HASHES.items():
        path = ROOT / relative
        audit.check(f"frozen_hash:{relative}", path.is_file() and sha256(path) == expected, sha256(path) if path.is_file() else "missing", expected)

    frozen_state = pd.read_csv(FROZEN / "WT_state_affinity_by_sample.tsv", sep="\t")
    frozen_stats = pd.read_csv(FROZEN / "WT_state_affinity_group_stats.tsv", sep="\t")
    derived_state = pd.read_csv(SOURCE / "WT_state_affinity_by_sample_recomputed.tsv", sep="\t")
    derived_stats = pd.read_csv(SOURCE / "WT_state_affinity_group_stats_recomputed.tsv", sep="\t")
    plotted = pd.read_csv(SOURCE / "Fig6e_Qctr_Rctr_sample_source.tsv", sep="\t")
    plotted_stats = pd.read_csv(SOURCE / "Fig6e_Qctr_Rctr_group_statistics_source.tsv", sep="\t")
    filter_audit = pd.read_csv(SOURCE / "filter_audit.tsv", sep="\t").iloc[0]

    assert_numeric_frame_equal(audit, "derived_vs_frozen_state", derived_state, frozen_state)
    assert_numeric_frame_equal(audit, "derived_vs_frozen_stats", derived_stats, frozen_stats)
    audit.check("complete_input_rows", len(derived_state) == 12, len(derived_state), 12)
    audit.check("complete_input_groups", set(derived_state["group"]) == {"Q_ctr", "Q_test", "R_ctr", "R_test"}, sorted(derived_state["group"].unique()), ["Q_ctr", "Q_test", "R_ctr", "R_test"])
    audit.check("plotted_rows", len(plotted) == 6, len(plotted), 6)
    audit.check("plotted_samples", plotted["sample"].tolist() == EXPECTED_SAMPLES, plotted["sample"].tolist(), EXPECTED_SAMPLES)
    audit.check("plotted_groups", plotted["group"].tolist() == ["Q_ctr"] * 3 + ["R_ctr"] * 3, plotted["group"].tolist(), ["Q_ctr"] * 3 + ["R_ctr"] * 3)
    audit.check("control_only", set(plotted["condition"]) == {"ctr"}, set(plotted["condition"]), {"ctr"})
    audit.check("filter_12_to_6", int(filter_audit["input_rows"]) == 12 and int(filter_audit["plotted_rows"]) == 6, f"{filter_audit['input_rows']}->{filter_audit['plotted_rows']}", "12->6")
    audit.check("filter_predicate", filter_audit["filter"] == "group in {Q_ctr,R_ctr}", filter_audit["filter"], "group in {Q_ctr,R_ctr}")

    expected_subset = derived_state.set_index("sample").loc[EXPECTED_SAMPLES].reset_index()
    expected_stats = derived_stats.set_index("group").loc[["Q_ctr", "R_ctr"]].reset_index()
    assert_numeric_frame_equal(audit, "plotted_vs_derived_state", plotted, expected_subset)
    assert_numeric_frame_equal(audit, "plotted_vs_derived_stats", plotted_stats, expected_stats)

    for group in ["Q_ctr", "R_ctr"]:
        values = plotted.loc[plotted["group"].eq(group), "StateAffinity"].to_numpy(float)
        row = plotted_stats.loc[plotted_stats["group"].eq(group)].iloc[0]
        test = stats.ttest_1samp(values, popmean=0.0)
        audit.check(f"n:{group}", len(values) == 3, len(values), 3)
        audit.check(f"mean:{group}", np.isclose(values.mean(), row["mean_StateAffinity"], rtol=0, atol=2e-15), values.mean(), row["mean_StateAffinity"])
        audit.check(f"sample_sd:{group}", np.isclose(values.std(ddof=1), row["sd_StateAffinity"], rtol=0, atol=2e-15), values.std(ddof=1), row["sd_StateAffinity"])
        audit.check(f"t_statistic:{group}", np.isclose(test.statistic, row["one_sample_t"], rtol=0, atol=2e-12), test.statistic, row["one_sample_t"])
        audit.check(f"p_value:{group}", np.isclose(test.pvalue, row["one_sample_p"], rtol=0, atol=2e-15), test.pvalue, row["one_sample_p"])

    geometry = pd.read_csv(QA / "axis_geometry.tsv", sep="\t").iloc[0]
    expected_font = os.environ.get("FIG6E_FONT", "Arial")
    audit.check("page_89mm", abs(float(geometry["page_width_in"]) * 25.4 - 89.0) < 1e-6, float(geometry["page_width_in"]) * 25.4, 89.0)
    audit.check("square_page", abs(float(geometry["page_width_in"]) / float(geometry["page_height_in"]) - 1.0) <= 0.005, float(geometry["page_width_in"]) / float(geometry["page_height_in"]), "1 +/- 0.005")
    audit.check("square_axis", abs(float(geometry["axis_width_height_ratio"]) - 1.0) <= 0.005, geometry["axis_width_height_ratio"], "1 +/- 0.005")
    audit.check("original_ylim_low", np.isclose(geometry["ylim_low"], -0.06790370449934519, rtol=0, atol=1e-15), geometry["ylim_low"], -0.06790370449934519)
    audit.check("original_ylim_high", np.isclose(geometry["ylim_high"], 0.08728563832645632, rtol=0, atol=1e-15), geometry["ylim_high"], 0.08728563832645632)
    audit.check("font_explicit", geometry["font"] == expected_font, geometry["font"], expected_font)

    paths = {ext: OUTPUT / f"{STEM}.{ext}" for ext in ("svg", "pdf", "tiff", "png")}
    for ext, path in paths.items():
        audit.check(f"output_exists:{ext}", path.is_file() and path.stat().st_size > 1000, path.stat().st_size if path.exists() else 0, ">1000 bytes")
    for ext in ("png", "tiff"):
        with Image.open(paths[ext]) as image:
            width, height = image.size
            dpi = image.info.get("dpi", (0, 0))
            audit.check(f"raster_dimensions:{ext}", (width, height) == (2102, 2102), f"{width}x{height}", "2102x2102")
            audit.check(f"raster_dpi:{ext}", all(abs(float(value) - 600.0) < 1.0 for value in dpi[:2]), dpi, "600x600")
            audit.check(f"raster_mode:{ext}", image.mode in {"RGB", "RGBA"}, image.mode, "RGB or RGBA")

    svg_text = paths["svg"].read_text(encoding="utf-8")
    svg_root = ET.fromstring(svg_text)
    width_pt = float(re.match(r"([0-9.]+)", svg_root.attrib["width"]).group(1))
    height_pt = float(re.match(r"([0-9.]+)", svg_root.attrib["height"]).group(1))
    audit.check("svg_square", abs(width_pt / height_pt - 1.0) <= 0.005, width_pt / height_pt, "1 +/- 0.005")
    audit.check("svg_editable_text", "<text" in svg_text, "<text present" if "<text" in svg_text else "absent", "present")
    audit.check("svg_no_raster", "<image" not in svg_text, "embedded raster" if "<image" in svg_text else "none", "none")
    lower_svg = svg_text.lower()
    for color in ("#eac0a7", "#bfdcc8", "#272727", "#8a8a8a"):
        audit.check(f"svg_color:{color}", color in lower_svg, color in lower_svg, True)
    for label in ("Q_ctr", "R_ctr", "StateAffinity", "WT-state affinity", "P=3.6e-04", "P=0.007"):
        audit.check(f"svg_label:{label}", label in svg_text, label in svg_text, True)
    for forbidden in ("Q_test", "R_test"):
        audit.check(f"svg_excludes:{forbidden}", forbidden not in svg_text, forbidden in svg_text, False)

    for tool in ("pdfinfo", "pdffonts", "pdftotext"):
        audit.check(f"system_tool:{tool}", shutil.which(tool) is not None, shutil.which(tool), "available")
    pdfinfo = run_text(["pdfinfo", str(paths["pdf"])])
    page = re.search(r"Page size:\s+([0-9.]+) x ([0-9.]+) pts", pdfinfo)
    pages = re.search(r"^Pages:\s+(\d+)$", pdfinfo, flags=re.MULTILINE)
    audit.check("pdf_single_page", pages is not None and int(pages.group(1)) == 1, pages.group(1) if pages else "missing", 1)
    audit.check("pdf_square_page", page is not None and abs(float(page.group(1)) / float(page.group(2)) - 1.0) <= 0.005, page.group(0) if page else "missing", "square")
    fonts = run_text(["pdffonts", str(paths["pdf"])])
    audit.check("pdf_fonts_embedded", "yes" in fonts.lower(), fonts.strip(), "embedded=yes")
    pdf_text = run_text(["pdftotext", str(paths["pdf"]), "-"])
    audit.check("pdf_editable_text", "StateAffinity" in pdf_text and "WT-state affinity" in pdf_text, "text extracted", "required strings present")
    audit.check("pdf_excludes_test_groups", "Q_test" not in pdf_text and "R_test" not in pdf_text, "test labels absent", "absent")
    return audit


def write_reports(audit: Audit) -> None:
    QA.mkdir(parents=True, exist_ok=True)
    expected_font = os.environ.get("FIG6E_FONT", "Arial")
    frame = pd.DataFrame(audit.rows)
    frame.to_csv(QA / "qa_summary.tsv", sep="\t", index=False)
    passed = int(frame["passed"].sum())
    total = len(frame)
    report = (
        "# Fig. 6e 便携复现自动质检报告\n\n"
        f"总体状态：**{'PASS' if passed == total else 'FAIL'}**\n\n"
        f"通过检查：**{passed}/{total}**。\n\n"
        "检查覆盖原始输入哈希、64密码子输入一致性、全链路重算与冻结结果逐列比较、"
        "12→6筛选、样本身份、均值/样本SD/单样本t检验、89 mm画布、1:1主轴、"
        f"原始y轴范围、{expected_font}字体、矢量文本、PDF字体嵌入和600 dpi栅格输出。\n"
    )
    (QA / "automated_qa_report.md").write_text(report, encoding="utf-8")


def write_environment() -> None:
    lines = [
        f"Python\t{sys.version.split()[0]}",
        f"numpy\t{np.__version__}",
        f"pandas\t{pd.__version__}",
        f"scipy\t{scipy.__version__}",
        f"matplotlib\t{matplotlib.__version__}",
        f"Pillow\t{PIL.__version__}",
    ]
    (ROOT / "06_environment" / "software_versions_observed.tsv").write_text("software\tversion\n" + "\n".join(lines) + "\n", encoding="utf-8")


def write_manifests() -> None:
    excluded = {"delivery_manifest.tsv", "SHA256SUMS"}
    files = [path for path in sorted(ROOT.rglob("*")) if path.is_file() and path.name not in excluded]
    records = [{"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)} for path in files]
    pd.DataFrame(records).to_csv(ROOT / "delivery_manifest.tsv", sep="\t", index=False)
    checksum_lines = [f"{row['sha256']}  {row['path']}" for row in records]
    (ROOT / "SHA256SUMS").write_text("\n".join(checksum_lines) + "\n", encoding="utf-8")


def main() -> None:
    audit = validate()
    write_reports(audit)
    write_environment()
    write_manifests()
    print(f"PASS: {len(audit.rows)}/{len(audit.rows)} automated checks")


if __name__ == "__main__":
    main()
