#!/usr/bin/env python3


from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "01_raw_inputs"
FROZEN = ROOT / "02_frozen_inputs"
SOURCE = ROOT / "04_source_data"
STOP_CODONS = {"TAA", "TAG", "TGA"}
STATE_GROUP_ORDER = ["Q_ctr", "Q_test", "R_ctr", "R_test"]

EXPECTED_RAW_HASHES = {
    "codon64_proportions.tsv": "33e07424f1aaf3609a2b1883f58737ba789fd7e34d5f7c88a2837fc717908960",
    "codon64_raw_counts.tsv": "adc1b040abe07706f717a6d42d3a80a8a864a265e2579609a2383b7cf3270aff",
    "codon64_raw_rpm_proportion.tsv": "af3a4891b2e83d42c991e5abc85f0f6069de87790d291ef431451ae3cbd91ecf",
    "codon64_rpm.tsv": "34f1b5bfd95cc89939caf6bc72569caab4a2500c01245a1b5f839803b70fe554",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def significance_label(p_value: float) -> str:
    if p_value < 1e-4:
        return "****"
    if p_value < 1e-3:
        return "***"
    if p_value < 1e-2:
        return "**"
    if p_value < 5e-2:
        return "*"
    return "ns"


def validate_raw_inputs() -> tuple[pd.DataFrame, pd.DataFrame, list[str]]:
    for name, expected in EXPECTED_RAW_HASHES.items():
        path = RAW / name
        require(path.is_file(), f"Missing raw input: {name}")
        observed = sha256(path)
        require(observed == expected, f"Raw-input hash mismatch for {name}: {observed}")

    prop = pd.read_csv(RAW / "codon64_proportions.tsv", sep="\t", index_col="codon")
    counts = pd.read_csv(RAW / "codon64_raw_counts.tsv", sep="\t", index_col="codon")
    rpm = pd.read_csv(RAW / "codon64_rpm.tsv", sep="\t", index_col="codon")
    long = pd.read_csv(RAW / "codon64_raw_rpm_proportion.tsv", sep="\t")
    sample_meta = pd.read_csv(FROZEN / "sample_metadata.tsv", sep="\t")
    codon_meta = pd.read_csv(FROZEN / "codon_metadata.tsv", sep="\t")

    require(prop.shape == (64, 18), f"Expected 64 x 18 proportions, observed {prop.shape}")
    require(counts.shape == prop.shape and rpm.shape == prop.shape, "Wide input dimensions disagree")
    require(long.shape == (1152, 5), f"Expected 1,152 long rows, observed {long.shape}")
    require(prop.index.is_unique and counts.index.is_unique and rpm.index.is_unique, "Duplicate codons detected")
    require(set(prop.index) == set(codon_meta["codon"]), "Codon metadata and proportion codons differ")
    require(set(prop.columns) == set(sample_meta["sample"]), "Sample metadata and proportion samples differ")
    require(list(counts.index) == list(prop.index) == list(rpm.index), "Wide-table codon order differs")
    require(list(counts.columns) == list(prop.columns) == list(rpm.columns), "Wide-table sample order differs")
    require(not prop.isna().any().any() and not counts.isna().any().any(), "Missing values detected")
    require((prop.to_numpy() >= 0).all() and (counts.to_numpy() >= 0).all(), "Negative values detected")
    require(np.allclose(prop.sum(axis=0), 1.0, rtol=0, atol=2e-15), "Proportion columns do not sum to 1")

    prop_from_counts = counts.div(counts.sum(axis=0), axis=1)
    require(np.allclose(prop, prop_from_counts, rtol=0, atol=5e-16), "Proportions do not match raw counts")
    require(np.allclose(rpm, prop * 1_000_000.0, rtol=0, atol=5e-9), "RPM does not equal proportion x 1e6")

    long_prop = long.pivot(index="codon", columns="sample", values="proportion").loc[prop.index, prop.columns]
    long_counts = long.pivot(index="codon", columns="sample", values="raw_count").loc[prop.index, prop.columns]
    long_rpm = long.pivot(index="codon", columns="sample", values="RPM").loc[prop.index, prop.columns]
    require(np.allclose(long_prop, prop, rtol=0, atol=5e-16), "Long-table proportions disagree")
    require(np.array_equal(long_counts.to_numpy(), counts.to_numpy()), "Long-table raw counts disagree")
    require(np.allclose(long_rpm, rpm, rtol=0, atol=5e-9), "Long-table RPM values disagree")

    stop_from_metadata = set(codon_meta.loc[codon_meta["is_stop"].astype(bool), "codon"])
    require(stop_from_metadata == STOP_CODONS, f"Unexpected stop-codon set: {stop_from_metadata}")
    sense = [codon for codon in prop.index if codon not in STOP_CODONS]
    require(len(sense) == 61, f"Expected 61 sense codons, observed {len(sense)}")
    return prop, sample_meta, sense


def derive() -> None:
    prop, sample_meta, sense = validate_raw_inputs()
    sample_meta = sample_meta.sort_values("sample_order").reset_index(drop=True)
    wt_ctr_samples = sample_meta.loc[sample_meta["group"].eq("WT_ctr"), "sample"].tolist()
    wt_test_samples = sample_meta.loc[sample_meta["group"].eq("WT_test"), "sample"].tolist()
    require(wt_ctr_samples == ["wt_ctr1", "wt_ctr2", "wt_ctr3"], "Unexpected WT_ctr samples")
    require(wt_test_samples == ["wt_test1", "wt_test2", "wt_test3"], "Unexpected WT_test samples")

    
    wt_ctr_center = prop.loc[sense, wt_ctr_samples].mean(axis=1)
    wt_test_center = prop.loc[sense, wt_test_samples].mean(axis=1)
    centroids = pd.DataFrame(
        {
            "codon": sense,
            "WT_ctr_centroid_proportion": wt_ctr_center.to_numpy(float),
            "WT_test_centroid_proportion": wt_test_center.to_numpy(float),
        }
    )

    state_rows: list[dict[str, object]] = []
    non_wt = sample_meta.loc[~sample_meta["genotype"].eq("WT")]
    for row in non_wt.itertuples(index=False):
        vector = prop.loc[sense, row.sample].to_numpy(float)
        distance_ctr = float(np.linalg.norm(vector - wt_ctr_center.to_numpy(float)))
        distance_test = float(np.linalg.norm(vector - wt_test_center.to_numpy(float)))
        state_rows.append(
            {
                "sample": row.sample,
                "distance_to_WT_ctr": distance_ctr,
                "distance_to_WT_test": distance_test,
                "StateAffinity": distance_ctr - distance_test,
                "genotype": row.genotype,
                "condition": row.condition,
                "replicate": row.replicate,
                "group": row.group,
                "group_order": row.group_order,
                "sample_order": row.sample_order,
            }
        )
    state = pd.DataFrame(state_rows)
    require(len(state) == 12, f"Expected 12 non-WT rows, observed {len(state)}")

    statistics_rows: list[dict[str, object]] = []
    for group in STATE_GROUP_ORDER:
        values = state.loc[state["group"].eq(group), "StateAffinity"].to_numpy(float)
        require(len(values) == 3, f"Expected n=3 for {group}, observed {len(values)}")
        result = stats.ttest_1samp(values, popmean=0.0)
        p_value = float(result.pvalue)
        statistics_rows.append(
            {
                "group": group,
                "n": len(values),
                "mean_StateAffinity": float(np.mean(values)),
                "sd_StateAffinity": float(np.std(values, ddof=1)),
                "one_sample_t": float(result.statistic),
                "one_sample_p": p_value,
                "significance_label": significance_label(p_value),
            }
        )
    group_stats = pd.DataFrame(statistics_rows)

    SOURCE.mkdir(parents=True, exist_ok=True)
    centroids.to_csv(SOURCE / "WT_centroids_61_sense_codons.tsv", sep="\t", index=False)
    state.to_csv(SOURCE / "WT_state_affinity_by_sample_recomputed.tsv", sep="\t", index=False)
    group_stats.to_csv(SOURCE / "WT_state_affinity_group_stats_recomputed.tsv", sep="\t", index=False)
    pd.DataFrame(
        [
            {
                "input_codons": 64,
                "excluded_stop_codons": "TAA,TAG,TGA",
                "retained_sense_codons": 61,
                "renormalized_after_exclusion": False,
                "reference_centroids": "WT_ctr and WT_test; arithmetic mean across n=3",
                "distance": "Euclidean L2 in 61-dimensional proportion space",
                "StateAffinity": "distance_to_WT_ctr - distance_to_WT_test",
                "statistics": "two-sided one-sample t-test against zero; sample SD; n=3",
            }
        ]
    ).to_csv(SOURCE / "calculation_audit.tsv", sep="\t", index=False)
    print("PASS: derived 12 StateAffinity rows and four group-statistics rows from 64-codon proportions")


if __name__ == "__main__":
    derive()
