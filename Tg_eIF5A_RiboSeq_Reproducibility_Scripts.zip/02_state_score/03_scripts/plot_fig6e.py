#!/usr/bin/env python3


from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib as mpl
import matplotlib.font_manager as font_manager
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / "02_frozen_inputs"
SOURCE = ROOT / "04_source_data"
OUTPUT = ROOT / "05_outputs"
QA = ROOT / "07_qa"
STEM = "Fig6e_Qctr_Rctr_state_affinity_square_nature_v1.0_20260823"
PLOT_GROUPS = ["Q_ctr", "R_ctr"]
GROUP_COLORS = {"Q_ctr": "#EAC0A7", "R_ctr": "#BFDCC8"}
BLACK = "#272727"
NEUTRAL_MID = "#8A8A8A"
FIG_WIDTH_MM = 89.0
ORIGINAL_YLIM = (-0.06790370449934519, 0.08728563832645632)
ORIGINAL_YTICKS = np.arange(-0.06, 0.0801, 0.02)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input-mode",
        choices=("derived", "frozen"),
        default="derived",
        help="Use full-chain recomputed tables or the frozen quick-reproduction tables.",
    )
    parser.add_argument(
        "--font",
        default="Arial",
        help="Explicit sans-serif font. Exact reproduction uses Arial; no silent fallback is allowed.",
    )
    return parser.parse_args()


def configure_style(font_name: str) -> None:
    try:
        font_manager.findfont(font_name, fallback_to_default=False)
    except ValueError as exc:
        raise RuntimeError(
            f"Required font '{font_name}' is unavailable. Install Arial or rerun with an explicitly approved --font."
        ) from exc
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [font_name],
            "font.size": 7.0,
            "axes.labelsize": 7.0,
            "axes.titlesize": 7.0,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "axes.linewidth": 0.75,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "xtick.major.width": 0.65,
            "ytick.major.width": 0.65,
            "xtick.major.size": 2.2,
            "ytick.major.size": 2.2,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
        }
    )


def p_text(value: float) -> str:
    if value < 1e-3:
        return f"P={value:.1e}"
    return f"P={value:.3f}".rstrip("0").rstrip(".")


def load_tables(input_mode: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    if input_mode == "derived":
        state_path = SOURCE / "WT_state_affinity_by_sample_recomputed.tsv"
        stats_path = SOURCE / "WT_state_affinity_group_stats_recomputed.tsv"
    else:
        state_path = FROZEN / "WT_state_affinity_by_sample.tsv"
        stats_path = FROZEN / "WT_state_affinity_group_stats.tsv"
    state = pd.read_csv(state_path, sep="\t")
    group_stats = pd.read_csv(stats_path, sep="\t")
    if len(state) != 12 or state.isna().any().any():
        raise RuntimeError("StateAffinity table must contain 12 complete non-WT sample rows")
    if len(group_stats) != 4 or group_stats.isna().any().any():
        raise RuntimeError("Statistics table must contain four complete groups")

    plot_state = state.loc[state["group"].isin(PLOT_GROUPS)].copy()
    plot_stats = group_stats.loc[group_stats["group"].isin(PLOT_GROUPS)].copy()
    plot_state["group"] = pd.Categorical(plot_state["group"], PLOT_GROUPS, ordered=True)
    plot_stats["group"] = pd.Categorical(plot_stats["group"], PLOT_GROUPS, ordered=True)
    plot_state = plot_state.sort_values(["group", "replicate"]).reset_index(drop=True)
    plot_stats = plot_stats.sort_values("group").reset_index(drop=True)
    plot_state["group"] = plot_state["group"].astype(str)
    plot_stats["group"] = plot_stats["group"].astype(str)

    expected_samples = ["Q_ctr1", "Q_ctr2", "Q_ctr3", "R_ctr1", "R_ctr2", "R_ctr3"]
    if plot_state["sample"].tolist() != expected_samples:
        raise RuntimeError(f"Unexpected plotting sample set: {plot_state['sample'].tolist()}")
    if set(plot_state["condition"]) != {"ctr"}:
        raise RuntimeError("A test-condition row entered the plotting data")

    SOURCE.mkdir(parents=True, exist_ok=True)
    plot_state.to_csv(SOURCE / "Fig6e_Qctr_Rctr_sample_source.tsv", sep="\t", index=False)
    plot_stats.to_csv(SOURCE / "Fig6e_Qctr_Rctr_group_statistics_source.tsv", sep="\t", index=False)
    pd.DataFrame(
        [
            {
                "input_rows": len(state),
                "plotted_rows": len(plot_state),
                "input_groups": ",".join(group_stats["group"].astype(str)),
                "plotted_groups": ",".join(PLOT_GROUPS),
                "filter": "group in {Q_ctr,R_ctr}",
                "reason": "User-requested removal of Q_test and R_test from the plot only",
                "input_mode": input_mode,
            }
        ]
    ).to_csv(SOURCE / "filter_audit.tsv", sep="\t", index=False)
    return plot_state, plot_stats


def draw(plot_state: pd.DataFrame, plot_stats: pd.DataFrame, font_name: str) -> None:
    configure_style(font_name)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    QA.mkdir(parents=True, exist_ok=True)
    page_in = FIG_WIDTH_MM / 25.4
    fig = plt.figure(figsize=(page_in, page_in), facecolor="white")
    ax = fig.add_axes([0.22, 0.22, 0.68, 0.68])
    ax.set_box_aspect(1)

    for index, group in enumerate(PLOT_GROUPS):
        subset = plot_state.loc[plot_state["group"].eq(group)].sort_values("replicate")
        x_values = index + np.array([-0.12, 0.0, 0.12])
        ax.scatter(
            x_values,
            subset["StateAffinity"],
            s=22,
            color=GROUP_COLORS[group],
            edgecolor=BLACK,
            linewidth=0.35,
            zorder=3,
        )
        ax.errorbar(
            index,
            subset["StateAffinity"].mean(),
            yerr=subset["StateAffinity"].std(ddof=1),
            fmt="none",
            color=BLACK,
            capsize=2,
            linewidth=0.75,
            zorder=2,
        )
        p_value = float(plot_stats.loc[plot_stats["group"].eq(group), "one_sample_p"].iloc[0])
        ax.text(index, subset["StateAffinity"].max() + 0.005, p_text(p_value), ha="center", va="bottom", fontsize=5.5)

    ax.axhline(0, color=NEUTRAL_MID, linestyle="--", linewidth=0.75, zorder=1)
    ax.set_xlim(-0.35, 1.35)
    ax.set_ylim(*ORIGINAL_YLIM)
    ax.set_yticks(ORIGINAL_YTICKS)
    ax.set_xticks(range(len(PLOT_GROUPS)))
    ax.set_xticklabels(PLOT_GROUPS, rotation=35, ha="right")
    ax.set_ylabel("StateAffinity")
    ax.set_title("WT-state affinity", pad=5)
    ax.text(-0.16, 1.08, "e", transform=ax.transAxes, ha="left", va="bottom", fontsize=8, fontweight="bold", color=BLACK)
    ax.grid(False)

    fig.canvas.draw()
    bbox = ax.get_position()
    width_in, height_in = fig.get_size_inches()
    pd.DataFrame(
        [
            {
                "page_width_in": width_in,
                "page_height_in": height_in,
                "axis_width_in": bbox.width * width_in,
                "axis_height_in": bbox.height * height_in,
                "axis_width_height_ratio": (bbox.width * width_in) / (bbox.height * height_in),
                "ylim_low": ax.get_ylim()[0],
                "ylim_high": ax.get_ylim()[1],
                "xlim_low": ax.get_xlim()[0],
                "xlim_high": ax.get_xlim()[1],
                "font": font_name,
            }
        ]
    ).to_csv(QA / "axis_geometry.tsv", sep="\t", index=False)

    base = OUTPUT / STEM
    metadata = {"Title": "Fig. 6e Q_ctr and R_ctr WT-state affinity", "Creator": "Matplotlib"}
    fig.savefig(Path(f"{base}.svg"), metadata=metadata)
    fig.savefig(Path(f"{base}.pdf"), metadata=metadata)
    fig.savefig(Path(f"{base}.tiff"), dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(Path(f"{base}.png"), dpi=600)
    plt.close(fig)
    print(f"PASS: created {base}.[svg|pdf|tiff|png]")


def main() -> None:
    args = parse_args()
    plot_state, plot_stats = load_tables(args.input_mode)
    draw(plot_state, plot_stats, args.font)


if __name__ == "__main__":
    main()
