from __future__ import annotations

import csv
import hashlib
import json
import zipfile
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook
from pypdf import PdfReader, PdfWriter
from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "03_tables"
FIGURES = ROOT / "04_figures"
WORKBOOK = ROOT / "05_workbook" / "APR_Strict_GSEA_analysis.xlsx"
QC = ROOT / "06_qc"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def combine_figure_pdfs() -> Path:
    output = FIGURES / "APR_Strict_GSEA_all_figures.pdf"
    writer = PdfWriter()
    for index in range(1, 6):
        pdf = next(FIGURES.glob(f"Figure{index}_*.pdf"))
        for page in PdfReader(str(pdf)).pages:
            writer.add_page(page)
    with output.open("wb") as handle:
        writer.write(handle)
    return output


def validate() -> dict:
    summary = pd.read_csv(TABLES / "gsea_summary.csv")
    primary = summary.loc[
        summary["set_id"].isin(["WT_TEST_Strict", "Q_CTR_Strict"])
        & summary["background"].eq("protein_coding")
        & summary["metric"].eq("signed_logp")
    ].set_index("set_id")
    expected = {
        "WT_TEST_Strict": {"n": 298, "ES": -0.6230592715278095, "NES": -1.863641876143764, "leading": 102},
        "Q_CTR_Strict": {"n": 695, "ES": -0.6730595359593867, "NES": -2.1347237580020493, "leading": 285},
    }
    for set_id, exp in expected.items():
        row = primary.loc[set_id]
        assert int(row["gene_set_matched_n"]) == exp["n"]
        assert abs(float(row["ES"]) - exp["ES"]) < 1e-10
        assert abs(float(row["NES"]) - exp["NES"]) < 1e-10
        assert int(row["leading_edge_n"]) == exp["leading"]
        assert row["direction"] == "WT ctr"
        assert float(row["BH_q_primary_pair"]) < 0.001

    main_sensitivity = summary.loc[summary["set_id"].isin(["WT_TEST_Strict", "Q_CTR_Strict"])]
    assert len(main_sensitivity) == 8
    assert main_sensitivity["direction"].eq("WT ctr").all()
    assert (main_sensitivity["NES"] < 0).all()

    for stem in [
        "Figure1_main_GSEA_curves",
        "Figure2_GSEA_robustness",
        "Figure3_shared_unique_GSEA",
        "Figure4_leading_edge_comparison",
        "Figure5_leading_edge_heatmap",
    ]:
        for ext in ("svg", "pdf", "tiff", "png"):
            path = FIGURES / f"{stem}.{ext}"
            assert path.is_file() and path.stat().st_size > 0
        svg = (FIGURES / f"{stem}.svg").read_text(encoding="utf-8")
        assert "<text" in svg
        with Image.open(FIGURES / f"{stem}.png") as image:
            assert min(image.size) >= 900

    wb = load_workbook(WORKBOOK, read_only=True, data_only=False)
    expected_sheets = {
        "GSEA_Summary", "Set_Metadata", "Gene_Union_712", "Leading_Edge",
        "Ranked_Coding", "Heatmap_Source", "Summary", "Figures_Index",
        "Methods_QC", "Figure_Legends",
    }
    assert set(wb.sheetnames) == expected_sheets
    assert wb["Summary"]["B8"].value == "='GSEA_Summary'!I3"
    assert wb["Summary"]["C8"].value == "='GSEA_Summary'!I4"
    wb.close()
    formula_scan = (QC / "workbook_formula_scan.ndjson").read_text(encoding="utf-8")
    assert "matched 0 entries" in formula_scan

    return {
        "status": "PASSED",
        "primary_results": primary.reset_index()[
            ["set_id", "gene_set_matched_n", "ES", "NES", "empirical_P", "BH_q_primary_pair", "direction", "leading_edge_n"]
        ].to_dict(orient="records"),
        "sensitivity_analyses_all_WT_ctr": True,
        "figures": 5,
        "formats_per_figure": ["svg", "pdf", "tiff", "png"],
        "workbook_sheets": sorted(expected_sheets),
        "formula_errors": 0,
    }


def write_manifest() -> None:
    rows = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path.name in {"MANIFEST.tsv", "checksums.sha256"}:
            continue
        rel = path.relative_to(ROOT).as_posix()
        if rel.endswith(".inspect.ndjson"):
            role = "workbook inspection trace"
        elif rel.startswith("01_inputs"):
            role = "input"
        elif rel.startswith("02_scripts"):
            role = "reproducibility script or contract"
        elif rel.startswith("03_tables"):
            role = "analysis table or source data"
        elif rel.startswith("04_figures"):
            role = "figure output"
        elif rel.startswith("05_workbook"):
            role = "analysis workbook"
        elif rel.startswith("06_qc"):
            role = "quality-control artifact"
        else:
            role = "documentation or package"
        rows.append([rel, role, path.stat().st_size, sha256(path)])
    with (ROOT / "MANIFEST.tsv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["relative_path", "role", "size_bytes", "sha256"])
        writer.writerows(rows)
    with (ROOT / "checksums.sha256").open("w", encoding="utf-8") as handle:
        for rel, _, _, digest in rows:
            handle.write(f"{digest}  {rel}\n")


def make_portable_zip() -> Path:
    output = ROOT.parent / "APR_Strict_GSEA_reproducible_package.zip"
    excluded_parts = {"workbook_previews"}
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(ROOT.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT)
            if any(part in excluded_parts for part in rel.parts):
                continue
            if path.suffix.lower() == ".tiff" or path.name.startswith("null_") or path.name.endswith(".inspect.ndjson"):
                continue
            archive.write(path, Path(ROOT.name) / rel)
    return output


def main() -> None:
    combined = combine_figure_pdfs()
    result = validate()
    result["combined_figure_pdf_pages"] = len(PdfReader(str(combined)).pages)
    (QC / "output_validation.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    write_manifest()
    package = make_portable_zip()
    print(json.dumps({"validation": result, "portable_package": str(package), "package_size": package.stat().st_size}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
