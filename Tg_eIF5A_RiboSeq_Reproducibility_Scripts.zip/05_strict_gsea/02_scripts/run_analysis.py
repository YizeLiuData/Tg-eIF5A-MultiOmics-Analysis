from __future__ import annotations

import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
INPUTS = ROOT / "01_inputs"
TABLES = ROOT / "03_tables"
FIGURES = ROOT / "04_figures"
QC = ROOT / "06_qc"
for directory in (TABLES, FIGURES, QC):
    directory.mkdir(parents=True, exist_ok=True)

APR_PATH = INPUTS / "original" / "APR_three_contrast_separate_sheets.xlsx"
MRNA_PATH = INPUTS / "standardized" / "wt_testvswt_ctr_deg.tsv"

BASE_SEED = 20260816
N_PERM = 20000
P_FLOOR = 1e-300

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["font.size"] = 7
plt.rcParams["axes.linewidth"] = 0.8
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False
plt.rcParams["legend.frameon"] = False

COLORS = {
    "wt": "#0F4D92",
    "q": "#42949E",
    "shared": "#9A4D8E",
    "wt_only": "#3775BA",
    "q_only": "#E9A6A1",
    "test": "#0F4D92",
    "ctr": "#9A4D8E",
    "neutral": "#767676",
    "light": "#D8D8D8",
    "dark": "#272727",
}

SET_LABELS = {
    "WT_TEST_Strict": "WT_TEST Strict (n=298)",
    "Q_CTR_Strict": "Q_CTR Strict (n=695)",
    "Shared_281": "Shared core (n=281)",
    "WT_TEST_only_17": "WT_TEST only (n=17)",
    "Q_CTR_only_414": "Q_CTR only (n=414)",
}

SET_COLORS = {
    "WT_TEST_Strict": COLORS["wt"],
    "Q_CTR_Strict": COLORS["q"],
    "Shared_281": COLORS["shared"],
    "WT_TEST_only_17": COLORS["wt_only"],
    "Q_CTR_only_414": COLORS["q_only"],
}

SET_ORDER = [
    "Shared_281",
    "WT_TEST_Strict",
    "Q_CTR_Strict",
    "WT_TEST_only_17",
    "Q_CTR_only_414",
]

ANALYSES = [
    ("protein_coding", "signed_logp", 1.0, "Coding | signed -log10(P), weighted"),
    ("all", "signed_logp", 1.0, "All genes | signed -log10(P), weighted"),
    ("protein_coding", "log2fc", 0.0, "Coding | log2FC, unweighted"),
    ("all", "log2fc", 0.0, "All genes | log2FC, unweighted"),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_apr_sheet(sheet: str) -> pd.DataFrame:
    df = pd.read_excel(APR_PATH, sheet_name=sheet)
    df["gene_key"] = df["gene_id"].astype(str).str.strip().str.upper()
    if df["gene_key"].duplicated().any():
        raise ValueError(f"Duplicate gene_id in {sheet}")
    return df


def bh_adjust(pvalues: list[float]) -> np.ndarray:
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    adjusted = ranked * len(p) / np.arange(1, len(p) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    out = np.empty_like(adjusted)
    out[order] = np.minimum(adjusted, 1.0)
    return out


def prepare_ranked(mrna: pd.DataFrame, background: str, metric: str) -> pd.DataFrame:
    d = mrna.copy()
    if background == "protein_coding":
        d = d.loc[d["gene_biotype"].eq("protein_coding")].copy()
    if metric == "signed_logp":
        p = d["pvalue"].astype(float).clip(lower=P_FLOOR)
        d["rank_score"] = np.sign(d["log2FoldChange"]) * (-np.log10(p))
        d = d.sort_values(
            ["rank_score", "log2FoldChange", "gene_id"],
            ascending=[False, False, True],
            kind="mergesort",
        )
    elif metric == "log2fc":
        d["rank_score"] = d["log2FoldChange"].astype(float)
        d = d.sort_values(
            ["rank_score", "pvalue", "gene_id"],
            ascending=[False, True, True],
            kind="mergesort",
        )
    else:
        raise ValueError(metric)
    d = d.reset_index(drop=True)
    d["rank"] = np.arange(1, len(d) + 1)
    return d


def enrichment_curve(scores: np.ndarray, hit_mask: np.ndarray, weight: float):
    n = len(scores)
    nh = int(hit_mask.sum())
    if nh == 0 or nh == n:
        raise ValueError("Gene set must contain between 1 and N-1 ranked genes")
    hit_weights = (np.abs(scores) ** weight) * hit_mask
    norm = hit_weights.sum()
    increments = np.where(hit_mask, hit_weights / norm, -1.0 / (n - nh))
    running = np.cumsum(increments)
    imax = int(np.argmax(running))
    imin = int(np.argmin(running))
    es = float(running[imax] if running[imax] >= abs(running[imin]) else running[imin])
    peak = imax if es >= 0 else imin
    return es, peak, running


def null_es_distribution(
    scores: np.ndarray,
    set_size: int,
    n_perm: int,
    seed: int,
    weight: float,
    batch: int = 100,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = len(scores)
    abs_scores = np.abs(scores) ** weight
    miss_step = -1.0 / (n - set_size)
    out = np.empty(n_perm, dtype=float)
    cursor = 0
    while cursor < n_perm:
        b = min(batch, n_perm - cursor)
        hits = np.zeros((b, n), dtype=bool)
        for i in range(b):
            hits[i, rng.choice(n, size=set_size, replace=False)] = True
        weights = hits * abs_scores[None, :]
        norm = weights.sum(axis=1)
        increments = np.where(hits, weights / norm[:, None], miss_step)
        running = np.cumsum(increments, axis=1)
        vmax = running.max(axis=1)
        vmin = running.min(axis=1)
        out[cursor : cursor + b] = np.where(vmax >= np.abs(vmin), vmax, vmin)
        cursor += b
    return out


def run_gsea(
    ranked: pd.DataFrame,
    gene_ids: set[str],
    set_id: str,
    background: str,
    metric: str,
    weight: float,
    seed: int,
):
    d = ranked.copy()
    d["is_hit"] = d["gene_key"].isin(gene_ids)
    scores = d["rank_score"].to_numpy(float)
    hits = d["is_hit"].to_numpy(bool)
    es, peak, running = enrichment_curve(scores, hits, weight)
    null = null_es_distribution(scores, int(hits.sum()), N_PERM, seed, weight)
    if es >= 0:
        same = null[null >= 0]
        nes = es / same.mean()
        extreme = int(np.sum(same >= es))
        leading = hits & (np.arange(len(d)) <= peak)
        direction = "WT test"
    else:
        same = null[null < 0]
        nes = es / abs(same.mean())
        extreme = int(np.sum(same <= es))
        leading = hits & (np.arange(len(d)) >= peak)
        direction = "WT ctr"
    p_emp = (extreme + 1) / (len(same) + 1)
    d["running_ES"] = running
    d["leading_edge"] = leading
    analysis_id = f"{set_id}__{background}__{metric}"
    summary = {
        "analysis_id": analysis_id,
        "set_id": set_id,
        "set_label": SET_LABELS[set_id],
        "analysis_role": "primary" if set_id in {"WT_TEST_Strict", "Q_CTR_Strict"} else "exploratory",
        "background": background,
        "metric": metric,
        "weight": weight,
        "N_ranked": int(len(d)),
        "gene_set_input_n": int(len(gene_ids)),
        "gene_set_matched_n": int(hits.sum()),
        "ES": es,
        "NES": float(nes),
        "empirical_P": float(p_emp),
        "BH_q_primary_pair": np.nan,
        "direction": direction,
        "peak_rank": int(peak + 1),
        "leading_edge_n": int(leading.sum()),
        "null_same_sign_n": int(len(same)),
        "more_extreme_null_n": extreme,
        "permutations": N_PERM,
        "seed": seed,
    }
    return summary, d, null


def p_text(row: pd.Series) -> str:
    p = float(row["empirical_P"])
    q = row.get("BH_q_primary_pair", np.nan)
    p_label = f"P={p:.2e}" if p < 0.001 else f"P={p:.3f}"
    if pd.notna(q):
        q_label = f"q={float(q):.2e}" if q < 0.001 else f"q={float(q):.3f}"
        return f"{p_label}; {q_label}"
    return p_label


def style_axis(ax):
    ax.tick_params(labelsize=6.5, width=0.7, length=3)
    ax.spines["left"].set_linewidth(0.8)
    ax.spines["bottom"].set_linewidth(0.8)


def add_panel(ax, label: str):
    ax.text(-0.07, 1.04, label, transform=ax.transAxes, fontsize=9, fontweight="bold", ha="left", va="bottom")


def save_figure(fig, stem: str):
    for ext, kwargs in {
        "svg": {},
        "pdf": {},
        "tiff": {"dpi": 600},
        "png": {"dpi": 300},
    }.items():
        fig.savefig(FIGURES / f"{stem}.{ext}", bbox_inches="tight", facecolor="white", **kwargs)
    plt.close(fig)


def plot_curve(ax, trace: pd.DataFrame, summary: pd.Series, title: str, color: str):
    x = trace["rank"].to_numpy()
    y = trace["running_ES"].to_numpy()
    hits = trace.loc[trace["is_hit"], "rank"].to_numpy()
    ax.plot(x, y, color=color, lw=1.5)
    ax.axhline(0, color=COLORS["light"], lw=0.8)
    ax.axvline(int(summary["peak_rank"]), color=color, lw=0.8, ls="--", alpha=0.75)
    ymin, ymax = float(y.min()), float(y.max())
    span = max(ymax - ymin, 1e-9)
    tick_y = ymin - 0.055 * span
    ax.vlines(hits, tick_y, tick_y + 0.035 * span, color=COLORS["dark"], lw=0.3, alpha=0.55)
    ax.set_ylim(tick_y - 0.02 * span, ymax + 0.08 * span)
    ax.set_title(
        f"{title}\nES={summary['ES']:.3f}; NES={summary['NES']:.3f}; {p_text(summary)}; leading edge={int(summary['leading_edge_n'])}",
        loc="left",
        fontsize=7.5,
        fontweight="bold",
    )
    ax.set_xlabel("Genes ranked from WT test to WT ctr")
    ax.set_ylabel("Running enrichment score")
    ax.text(0, -0.22, "WT test", transform=ax.transAxes, color=COLORS["test"], fontweight="bold", ha="left", va="top")
    ax.text(1, -0.22, "WT ctr", transform=ax.transAxes, color=COLORS["ctr"], fontweight="bold", ha="right", va="top")
    style_axis(ax)


def figure_main(primary_traces: dict[str, pd.DataFrame], primary_rows: pd.DataFrame):
    mm = 1 / 25.4
    fig, axes = plt.subplots(2, 1, figsize=(183 * mm, 138 * mm), sharex=True)
    for ax, set_id, panel in zip(axes, ["WT_TEST_Strict", "Q_CTR_Strict"], ["a", "b"]):
        row = primary_rows.loc[primary_rows["set_id"].eq(set_id)].iloc[0]
        plot_curve(ax, primary_traces[set_id], row, SET_LABELS[set_id], SET_COLORS[set_id])
        add_panel(ax, panel)
    fig.suptitle("Pre-ranked GSEA of two strict Ribo-seq APR gene sets", x=0.09, y=0.99, ha="left", fontsize=10, fontweight="bold")
    fig.subplots_adjust(left=0.12, right=0.98, top=0.91, bottom=0.10, hspace=0.50)
    save_figure(fig, "Figure1_main_GSEA_curves")


def figure_robustness(summary: pd.DataFrame):
    mm = 1 / 25.4
    fig, ax = plt.subplots(figsize=(183 * mm, 92 * mm))
    main = summary.loc[summary["set_id"].isin(["WT_TEST_Strict", "Q_CTR_Strict"])].copy()
    labels = [x[3] for x in ANALYSES]
    ybase = np.arange(len(labels))[::-1]
    offsets = {"WT_TEST_Strict": 0.11, "Q_CTR_Strict": -0.11}
    for set_id in ["WT_TEST_Strict", "Q_CTR_Strict"]:
        ss = []
        for bg, metric, _, _ in ANALYSES:
            ss.append(main.loc[(main["set_id"] == set_id) & (main["background"] == bg) & (main["metric"] == metric)].iloc[0])
        vals = np.array([r["NES"] for r in ss], dtype=float)
        yy = ybase + offsets[set_id]
        ax.scatter(vals, yy, s=34, color=SET_COLORS[set_id], edgecolor="white", linewidth=0.6, label=SET_LABELS[set_id], zorder=3)
        for x, y, r in zip(vals, yy, ss):
            ax.text(x + 0.04, y, f"{x:.2f}", fontsize=6, va="center", ha="left", color=SET_COLORS[set_id])
    ax.axvline(0, color=COLORS["light"], lw=1)
    ax.set_yticks(ybase)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Normalized enrichment score (NES)")
    ax.set_title("Direction is evaluated across backgrounds and ranking strategies", loc="left", fontsize=9, fontweight="bold")
    ax.legend(loc="lower right")
    style_axis(ax)
    fig.subplots_adjust(left=0.33, right=0.97, top=0.88, bottom=0.18)
    save_figure(fig, "Figure2_GSEA_robustness")


def figure_components(primary_traces: dict[str, pd.DataFrame], primary_rows: pd.DataFrame):
    mm = 1 / 25.4
    fig = plt.figure(figsize=(183 * mm, 150 * mm))
    gs = fig.add_gridspec(2, 2, hspace=0.58, wspace=0.38)
    ax0 = fig.add_subplot(gs[0, 0])
    cats = ["WT_TEST only", "Shared", "Q_CTR only"]
    vals = [17, 281, 414]
    cols = [COLORS["wt_only"], COLORS["shared"], COLORS["q_only"]]
    bars = ax0.bar(cats, vals, color=cols, edgecolor="white", linewidth=0.7)
    for bar, value in zip(bars, vals):
        ax0.text(bar.get_x() + bar.get_width() / 2, value + 9, str(value), ha="center", va="bottom", fontsize=7, fontweight="bold")
    ax0.set_ylabel("Genes")
    ax0.set_title("Composition of the two strict APR sets", loc="left", fontsize=8, fontweight="bold")
    ax0.set_ylim(0, 465)
    style_axis(ax0)
    add_panel(ax0, "a")

    comp_sets = ["Shared_281", "WT_TEST_only_17", "Q_CTR_only_414"]
    panels = ["b", "c", "d"]
    for idx, (set_id, panel) in enumerate(zip(comp_sets, panels), start=1):
        ax = fig.add_subplot(gs[idx // 2, idx % 2])
        row = primary_rows.loc[primary_rows["set_id"].eq(set_id)].iloc[0]
        plot_curve(ax, primary_traces[set_id], row, SET_LABELS[set_id], SET_COLORS[set_id])
        add_panel(ax, panel)
    fig.suptitle("Shared and set-specific components of strict APR enrichment", x=0.08, y=0.99, ha="left", fontsize=10, fontweight="bold")
    fig.subplots_adjust(left=0.10, right=0.98, top=0.91, bottom=0.09)
    save_figure(fig, "Figure3_shared_unique_GSEA")


def figure_leading_edge(leading: pd.DataFrame, mrna: pd.DataFrame):
    mm = 1 / 25.4
    fig, axes = plt.subplots(1, 2, figsize=(183 * mm, 100 * mm), gridspec_kw={"width_ratios": [0.8, 1.3], "wspace": 0.55})
    ax0, ax1 = axes
    wt = set(leading.loc[leading["set_id"].eq("WT_TEST_Strict"), "gene_key"])
    q = set(leading.loc[leading["set_id"].eq("Q_CTR_Strict"), "gene_key"])
    vals = [len(wt - q), len(wt & q), len(q - wt)]
    labels = ["WT leading\nonly", "Shared\nleading", "Q leading\nonly"]
    cols = [COLORS["wt_only"], COLORS["shared"], COLORS["q_only"]]
    bars = ax0.bar(labels, vals, color=cols, edgecolor="white")
    for bar, value in zip(bars, vals):
        ax0.text(bar.get_x() + bar.get_width() / 2, value + max(vals) * 0.03, str(value), ha="center", fontsize=7, fontweight="bold")
    ax0.set_ylabel("Leading-edge genes")
    ax0.set_title("Leading-edge overlap", loc="left", fontsize=8, fontweight="bold")
    ax0.set_ylim(0, max(vals) * 1.18)
    style_axis(ax0)
    add_panel(ax0, "a")

    union = wt | q
    d = mrna.loc[mrna["gene_key"].isin(union)].copy()
    d["display"] = d["gene_name"].fillna("").astype(str)
    d.loc[d["display"].isin(["", "-", "nan"]), "display"] = d["gene_id"]
    d["membership"] = np.select(
        [d["gene_key"].isin(wt & q), d["gene_key"].isin(wt - q)],
        ["Shared leading", "WT leading only"],
        default="Q leading only",
    )
    d = d.sort_values("log2FoldChange").head(18).sort_values("log2FoldChange")
    y = np.arange(len(d))
    membership_colors = {
        "Shared leading": COLORS["shared"],
        "WT leading only": COLORS["wt_only"],
        "Q leading only": COLORS["q_only"],
    }
    ax1.barh(y, d["log2FoldChange"], color=[membership_colors[x] for x in d["membership"]], edgecolor="white", linewidth=0.5)
    ax1.axvline(0, color=COLORS["light"], lw=0.8)
    ax1.set_yticks(y)
    ax1.set_yticklabels(d["display"], fontsize=6.2)
    ax1.set_xlabel("mRNA log2 fold change")
    ax1.set_title("Strongest WT-ctr-side leading-edge genes", loc="left", fontsize=8, fontweight="bold")
    from matplotlib.patches import Patch
    legend_handles = [
        Patch(facecolor=COLORS["shared"], label="Shared leading"),
        Patch(facecolor=COLORS["wt_only"], label="WT leading only"),
        Patch(facecolor=COLORS["q_only"], label="Q leading only"),
    ]
    ax0.legend(handles=legend_handles, loc="upper left", bbox_to_anchor=(0.0, 0.90), fontsize=6)
    style_axis(ax1)
    add_panel(ax1, "b")
    fig.suptitle("Leading-edge genes supporting the main enrichment results", x=0.07, y=0.99, ha="left", fontsize=10, fontweight="bold")
    fig.subplots_adjust(left=0.08, right=0.98, top=0.88, bottom=0.14)
    save_figure(fig, "Figure4_leading_edge_comparison")


def figure_heatmap(leading: pd.DataFrame, mrna: pd.DataFrame) -> pd.DataFrame:
    wt = set(leading.loc[leading["set_id"].eq("WT_TEST_Strict"), "gene_key"])
    q = set(leading.loc[leading["set_id"].eq("Q_CTR_Strict"), "gene_key"])
    d = mrna.loc[mrna["gene_key"].isin(wt | q)].copy()
    d["membership"] = np.select(
        [d["gene_key"].isin(wt & q), d["gene_key"].isin(wt - q)],
        ["Shared leading", "WT leading only"],
        default="Q leading only",
    )
    d["display"] = d["gene_name"].fillna("").astype(str)
    d.loc[d["display"].isin(["", "-", "nan"]), "display"] = d["gene_id"]
    chosen = []
    for category in ["Shared leading", "WT leading only", "Q leading only"]:
        part = d.loc[d["membership"].eq(category)].sort_values("log2FoldChange").head(10)
        chosen.append(part)
    heat = pd.concat(chosen, ignore_index=True).drop_duplicates("gene_key").sort_values(["membership", "log2FoldChange"])
    sample_cols = ["wt_test1", "wt_test2", "wt_test3", "wt_ctr1", "wt_ctr2", "wt_ctr3"]
    logmat = np.log2(heat[sample_cols].astype(float).to_numpy() + 1)
    mean = logmat.mean(axis=1, keepdims=True)
    std = logmat.std(axis=1, keepdims=True)
    std[std == 0] = 1
    z = (logmat - mean) / std
    for i, col in enumerate(sample_cols):
        heat[f"z_{col}"] = z[:, i]

    mm = 1 / 25.4
    height_mm = max(125, 4.2 * len(heat))
    fig, ax = plt.subplots(figsize=(150 * mm, height_mm * mm))
    im = ax.imshow(z, cmap="coolwarm", vmin=-2, vmax=2, aspect="auto")
    ax.set_xticks(np.arange(len(sample_cols)))
    ax.set_xticklabels(["WT test 1", "WT test 2", "WT test 3", "WT ctr 1", "WT ctr 2", "WT ctr 3"], rotation=35, ha="right")
    ax.set_yticks(np.arange(len(heat)))
    ax.set_yticklabels(heat["display"], fontsize=6.2)
    ax.set_title("Representative leading-edge genes across six mRNA-seq samples", loc="left", fontsize=9, fontweight="bold")
    cbar = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.025)
    cbar.set_label("Row z-score of log2(expression + 1)")
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(length=0)
    fig.subplots_adjust(left=0.24, right=0.91, top=0.94, bottom=0.15)
    save_figure(fig, "Figure5_leading_edge_heatmap")
    return heat


def main():
    wt = read_apr_sheet("WT_TEST_Strict_gene")
    q = read_apr_sheet("Q_CTR_Strict_gene")
    wt_ids = set(wt["gene_key"])
    q_ids = set(q["gene_key"])
    gene_sets = {
        "WT_TEST_Strict": wt_ids,
        "Q_CTR_Strict": q_ids,
        "Shared_281": wt_ids & q_ids,
        "WT_TEST_only_17": wt_ids - q_ids,
        "Q_CTR_only_414": q_ids - wt_ids,
    }
    expected_sizes = {"WT_TEST_Strict": 298, "Q_CTR_Strict": 695, "Shared_281": 281, "WT_TEST_only_17": 17, "Q_CTR_only_414": 414}
    observed_sizes = {k: len(v) for k, v in gene_sets.items()}
    if observed_sizes != expected_sizes:
        raise AssertionError({"observed": observed_sizes, "expected": expected_sizes})

    mrna = pd.read_csv(MRNA_PATH, sep="\t")
    mrna["gene_key"] = mrna["gene_id"].astype(str).str.strip().str.upper()
    if mrna["gene_key"].duplicated().any():
        raise ValueError("Duplicate gene IDs in mRNA table")
    universe = set(mrna["gene_key"])
    missing = {k: sorted(v - universe) for k, v in gene_sets.items() if v - universe}
    if missing:
        raise ValueError(f"Unmatched APR genes: {missing}")
    if len(mrna) != 9089 or int(mrna["gene_biotype"].eq("protein_coding").sum()) != 8008:
        raise AssertionError("Unexpected mRNA universe size")

    summaries = []
    traces: dict[tuple[str, str, str], pd.DataFrame] = {}
    null_files = {}
    for analysis_index, (background, metric, weight, _) in enumerate(ANALYSES):
        ranked = prepare_ranked(mrna, background, metric)
        for set_index, set_id in enumerate(SET_ORDER):
            seed = BASE_SEED + analysis_index * 100 + set_index
            s, d, null = run_gsea(ranked, gene_sets[set_id], set_id, background, metric, weight, seed)
            summaries.append(s)
            traces[(set_id, background, metric)] = d
            null_path = QC / f"null_{set_id}__{background}__{metric}.npy"
            np.save(null_path, null)
            null_files[str(null_path.relative_to(ROOT))] = sha256(null_path)

    summary = pd.DataFrame(summaries)
    primary_mask = (
        summary["set_id"].isin(["WT_TEST_Strict", "Q_CTR_Strict"])
        & summary["background"].eq("protein_coding")
        & summary["metric"].eq("signed_logp")
    )
    summary.loc[primary_mask, "BH_q_primary_pair"] = bh_adjust(summary.loc[primary_mask, "empirical_P"].tolist())
    summary.to_csv(TABLES / "gsea_summary.csv", index=False)

    primary_rows = summary.loc[(summary["background"] == "protein_coding") & (summary["metric"] == "signed_logp")].copy()
    primary_rows.to_csv(TABLES / "primary_gsea_summary.csv", index=False)

    primary_ranked = prepare_ranked(mrna, "protein_coding", "signed_logp")
    membership = pd.DataFrame({"gene_key": sorted(wt_ids | q_ids)})
    membership["in_WT_TEST_Strict"] = membership["gene_key"].isin(wt_ids)
    membership["in_Q_CTR_Strict"] = membership["gene_key"].isin(q_ids)
    membership["set_component"] = np.select(
        [membership["in_WT_TEST_Strict"] & membership["in_Q_CTR_Strict"], membership["in_WT_TEST_Strict"]],
        ["Shared_281", "WT_TEST_only_17"],
        default="Q_CTR_only_414",
    )
    ann_cols = ["gene_key", "gene_id", "gene_name", "功能描述", "综合注释", "gene类型", "RNA_log2FC", "RNA_P值", "RNA_比较内FDR"]
    ann = pd.concat([wt[ann_cols], q[ann_cols]], ignore_index=True).drop_duplicates("gene_key")
    membership = membership.merge(ann, on="gene_key", how="left", validate="one_to_one")
    membership = membership.merge(
        primary_ranked[["gene_key", "rank", "rank_score", "log2FoldChange", "pvalue", "padj", "wt_test", "wt_ctr"]],
        on="gene_key",
        how="left",
        validate="one_to_one",
        suffixes=("_APRsheet", "_mRNA"),
    )
    membership.to_csv(TABLES / "gene_set_membership_union.csv", index=False)

    set_meta = pd.DataFrame(
        [
            {"set_id": k, "set_label": SET_LABELS[k], "gene_n": len(v), "analysis_role": "primary" if k in {"WT_TEST_Strict", "Q_CTR_Strict"} else "exploratory"}
            for k, v in gene_sets.items()
        ]
    )
    set_meta["mRNA_matched_n"] = set_meta["gene_n"]
    set_meta.to_csv(TABLES / "gene_set_metadata.csv", index=False)

    leading_parts = []
    curve_parts = []
    primary_traces = {}
    for set_id in SET_ORDER:
        d = traces[(set_id, "protein_coding", "signed_logp")].copy()
        primary_traces[set_id] = d
        lead = d.loc[d["leading_edge"]].copy()
        lead.insert(0, "set_id", set_id)
        lead.insert(1, "set_label", SET_LABELS[set_id])
        leading_parts.append(lead)
        c = d[["rank", "gene_id", "gene_key", "rank_score", "is_hit", "running_ES", "leading_edge"]].copy()
        c.insert(0, "set_id", set_id)
        curve_parts.append(c)
    leading = pd.concat(leading_parts, ignore_index=True)
    leading.to_csv(TABLES / "leading_edge_genes.csv", index=False)
    pd.concat(curve_parts, ignore_index=True).to_csv(TABLES / "primary_gsea_curves.csv", index=False)
    primary_ranked.to_csv(TABLES / "ranked_protein_coding_genes.csv", index=False)

    figure_main(primary_traces, primary_rows)
    figure_robustness(summary)
    figure_components(primary_traces, primary_rows)
    figure_leading_edge(leading, mrna)
    heat = figure_heatmap(leading, mrna)
    heat.to_csv(TABLES / "heatmap_source_data.csv", index=False)

    input_qc = {
        "APR_workbook_sha256": sha256(APR_PATH),
        "mRNA_table_sha256": sha256(MRNA_PATH),
        "mRNA_rows": len(mrna),
        "protein_coding_rows": int(mrna["gene_biotype"].eq("protein_coding").sum()),
        "mRNA_unique_gene_ids": int(mrna["gene_key"].nunique()),
        "mRNA_complete_statistics": bool(mrna[["log2FoldChange", "pvalue", "padj"]].notna().all().all()),
        "gene_set_sizes": observed_sizes,
        "gene_set_all_matched": True,
        "gene_set_all_protein_coding": {
            k: bool(mrna.loc[mrna["gene_key"].isin(v), "gene_biotype"].eq("protein_coding").all()) for k, v in gene_sets.items()
        },
        "WT_Q_intersection": len(wt_ids & q_ids),
        "WT_Q_union": len(wt_ids | q_ids),
        "WT_Q_jaccard": len(wt_ids & q_ids) / len(wt_ids | q_ids),
        "sheet_scope_note": "The requested Strict sheets contain plotted finite-positive strict genes: 298/320 WT_TEST and 695/807 Q_CTR.",
    }
    (QC / "input_validation.json").write_text(json.dumps(input_qc, ensure_ascii=False, indent=2), encoding="utf-8")

    metadata = {
        "analysis_date": "2026-08-16",
        "ranking_primary": "sign(log2FoldChange) * -log10(max(raw P, 1e-300))",
        "primary_background": "protein_coding",
        "primary_weight": 1.0,
        "sensitivity_ranking": "log2FoldChange order with unweighted KS-type enrichment score",
        "permutations": N_PERM,
        "base_seed": BASE_SEED,
        "multiple_testing": "BH adjustment across the two prespecified primary gene sets",
        "stage_mapping_status": "unresolved",
        "interpretation_boundary": "mRNA direction does not measure Ribo-seq pausing intensity; Q_CTR APR genes are evaluated on the WT test vs WT ctr mRNA contrast.",
        "null_file_sha256": null_files,
    }
    (TABLES / "analysis_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")

    print(primary_rows[["set_id", "gene_set_matched_n", "ES", "NES", "empirical_P", "BH_q_primary_pair", "direction", "leading_edge_n"]].to_string(index=False))


if __name__ == "__main__":
    main()
