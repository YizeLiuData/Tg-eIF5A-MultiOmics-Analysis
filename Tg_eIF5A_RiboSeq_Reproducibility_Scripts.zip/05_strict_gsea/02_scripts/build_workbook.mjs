import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const root = process.env.APR_GSEA_ROOT ?? path.resolve(scriptDir, "..");
const tables = `${root}/03_tables`;
const figures = `${root}/04_figures`;
const outPath = `${root}/05_workbook/APR_Strict_GSEA_analysis.xlsx`;
const previewDir = `${root}/06_qc/workbook_previews`;

await fs.mkdir(previewDir, { recursive: true });
const workbook = Workbook.create();

const imports = [
  ["GSEA_Summary", "gsea_summary.csv"],
  ["Set_Metadata", "gene_set_metadata.csv"],
  ["Gene_Union_712", "gene_set_membership_union.csv"],
  ["Leading_Edge", "leading_edge_genes.csv"],
  ["Ranked_Coding", "ranked_protein_coding_genes.csv"],
  ["Heatmap_Source", "heatmap_source_data.csv"],
];

for (const [sheetName, filename] of imports) {
  const csv = await fs.readFile(`${tables}/${filename}`, "utf8");
  await workbook.fromCSV(csv, { sheetName });
}

const summary = workbook.worksheets.add("Summary");
const figuresIndex = workbook.worksheets.add("Figures_Index");
const methods = workbook.worksheets.add("Methods_QC");
const legends = workbook.worksheets.add("Figure_Legends");

const NAVY = "#0F4D92";
const TEAL = "#42949E";
const PURPLE = "#9A4D8E";
const LIGHT_BLUE = "#E8F0F8";
const LIGHT_PURPLE = "#F2E9F3";
const LIGHT_TEAL = "#E8F5F6";
const LIGHT_GRAY = "#F3F4F6";
const AMBER = "#FFF4DE";
const WHITE = "#FFFFFF";
const GRID = "#D5D7DA";

function styleHeader(sheet, cols) {
  sheet.getRange(`A1:${cols}1`).format = {
    fill: NAVY,
    font: { bold: true, color: WHITE, size: 9 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    wrapText: true,
    borders: { preset: "outside", style: "thin", color: GRID },
  };
  sheet.getRange(`A1:${cols}1`).format.rowHeight = 30;
  sheet.freezePanes.freezeRows(1);
  sheet.showGridLines = false;
}

function addTableIfReasonable(sheet, tableName, maxRows = 10000) {
  const used = sheet.getUsedRange();
  if (used && used.rowCount <= maxRows) {
    const table = sheet.tables.add(used.address, true, tableName);
    table.style = "TableStyleMedium2";
    table.showBandedColumns = false;
    table.showFilterButton = true;
  }
}

styleHeader(workbook.worksheets.getItem("GSEA_Summary"), "U");
styleHeader(workbook.worksheets.getItem("Set_Metadata"), "F");
styleHeader(workbook.worksheets.getItem("Gene_Union_712"), "R");
styleHeader(workbook.worksheets.getItem("Leading_Edge"), "AB");
styleHeader(workbook.worksheets.getItem("Ranked_Coding"), "Y");
styleHeader(workbook.worksheets.getItem("Heatmap_Source"), "AB");

addTableIfReasonable(workbook.worksheets.getItem("GSEA_Summary"), "GSEASummaryTable");
addTableIfReasonable(workbook.worksheets.getItem("Set_Metadata"), "GeneSetMetadataTable");
addTableIfReasonable(workbook.worksheets.getItem("Gene_Union_712"), "GeneUnionTable");
addTableIfReasonable(workbook.worksheets.getItem("Leading_Edge"), "LeadingEdgeTable");
addTableIfReasonable(workbook.worksheets.getItem("Heatmap_Source"), "HeatmapSourceTable");

for (const name of ["GSEA_Summary", "Set_Metadata", "Gene_Union_712", "Leading_Edge", "Ranked_Coding", "Heatmap_Source"]) {
  const sheet = workbook.worksheets.getItem(name);
  const used = sheet.getUsedRange();
  used.format.font = { name: "Arial", size: 8 };
  used.format.verticalAlignment = "center";
}

const gsea = workbook.worksheets.getItem("GSEA_Summary");
gsea.getRange("A:U").format.columnWidth = 14;
gsea.getRange("A:A").format.columnWidth = 46;
gsea.getRange("B:C").format.columnWidth = 24;
gsea.getRange("D:F").format.columnWidth = 17;
gsea.getRange("K:N").format.numberFormat = "0.0000";
gsea.getRange("M:N").format.numberFormat = "0.00E+00";
gsea.getRange("K2:L21").conditionalFormats.add("colorScale", {
  colors: [PURPLE, WHITE, NAVY],
  thresholds: ["min", { type: "num", value: 0 }, "max"],
});

const meta = workbook.worksheets.getItem("Set_Metadata");
meta.getRange("A:F").format.columnWidth = 22;
meta.getRange("B:B").format.columnWidth = 30;

const union = workbook.worksheets.getItem("Gene_Union_712");
union.getRange("A:A").format.columnWidth = 21;
union.getRange("D:D").format.columnWidth = 24;
union.getRange("E:F").format.columnWidth = 20;
union.getRange("G:H").format.columnWidth = 42;
union.getRange("I:I").format.columnWidth = 18;
union.getRange("L:R").format.columnWidth = 14;
union.getRange("M:R").format.numberFormat = "0.0000";

const lead = workbook.worksheets.getItem("Leading_Edge");
lead.getRange("A:C").format.columnWidth = 27;
lead.getRange("D:D").format.columnWidth = 21;
lead.getRange("E:E").format.columnWidth = 18;
lead.getRange("X:AB").format.columnWidth = 18;

const ranked = workbook.worksheets.getItem("Ranked_Coding");
ranked.getRange("A:A").format.columnWidth = 21;
ranked.getRange("B:G").format.columnWidth = 13;
ranked.getRange("M:M").format.columnWidth = 18;
ranked.getRange("U:Y").format.columnWidth = 15;

const heat = workbook.worksheets.getItem("Heatmap_Source");
heat.getRange("A:D").format.columnWidth = 22;
heat.getRange("E:J").format.columnWidth = 13;
heat.getRange("K:AB").format.columnWidth = 14;

summary.showGridLines = false;
summary.getRange("A1:H2").merge();
summary.getRange("A1").values = [["Pre-ranked GSEA of two strict Ribo-seq APR gene sets"]];
summary.getRange("A1:H2").format = {
  fill: NAVY,
  font: { name: "Arial", color: WHITE, bold: true, size: 17 },
  verticalAlignment: "center",
};
summary.getRange("A4:H5").merge();
summary.getRange("A4").values = [["Main result: both strict APR sets are significantly enriched toward WT ctr. The shared 281-gene core and the 414 Q_CTR-specific genes support this direction; the 17 WT_TEST-specific genes show no significant direction."]];
summary.getRange("A4:H5").format = {
  fill: LIGHT_PURPLE,
  font: { color: PURPLE, bold: true, size: 11 },
  wrapText: true,
  verticalAlignment: "center",
};

summary.getRange("A7:D7").values = [["Metric", "WT_TEST Strict", "Q_CTR Strict", "Interpretation"]];
summary.getRange("A7:D7").format = { fill: NAVY, font: { color: WHITE, bold: true }, horizontalAlignment: "center" };
summary.getRange("A8:A15").values = [
  ["Gene-set input"], ["Mapped to mRNA"], ["ES"], ["NES"], ["Empirical P"], ["BH-adjusted q"], ["Enriched end"], ["Leading-edge genes"],
];
summary.getRange("B8:C15").formulas = [
  ["='GSEA_Summary'!I3", "='GSEA_Summary'!I4"],
  ["='GSEA_Summary'!J3", "='GSEA_Summary'!J4"],
  ["='GSEA_Summary'!K3", "='GSEA_Summary'!K4"],
  ["='GSEA_Summary'!L3", "='GSEA_Summary'!L4"],
  ["='GSEA_Summary'!M3", "='GSEA_Summary'!M4"],
  ["='GSEA_Summary'!N3", "='GSEA_Summary'!N4"],
  ["='GSEA_Summary'!O3", "='GSEA_Summary'!O4"],
  ["='GSEA_Summary'!Q3", "='GSEA_Summary'!Q4"],
];
summary.getRange("D8:D15").values = [
  ["Unique gene IDs in the requested sheet"], ["100% mapping for both sets"], ["Negative values indicate the WT ctr end"], ["Enrichment strength normalized to set size"], ["20,000 size-matched gene-set permutations"], ["Correction across the two prespecified primary tests"], ["Stage labels remain unresolved"], ["Core genes driving the enrichment-score extreme"],
];
summary.getRange("A8:A15").format = { fill: LIGHT_BLUE, font: { bold: true } };
summary.getRange("B8:B15").format.fill = LIGHT_BLUE;
summary.getRange("C8:C15").format.fill = LIGHT_TEAL;
summary.getRange("B10:C11").format.numberFormat = "0.0000";
summary.getRange("B12:C13").format.numberFormat = "0.00E+00";
summary.getRange("A7:D15").format.borders = { preset: "all", style: "thin", color: GRID };

summary.getRange("A18:D18").values = [["Set component", "Genes", "Primary NES", "Interpretation"]];
summary.getRange("A18:D18").format = { fill: NAVY, font: { color: WHITE, bold: true }, horizontalAlignment: "center" };
summary.getRange("A19:D21").values = [
  ["Shared core", 281, null, "Previously analysed 281-gene set"],
  ["WT_TEST only", 17, null, "Exploratory; low statistical power"],
  ["Q_CTR only", 414, null, "Exploratory"],
];
summary.getRange("C19:C21").formulas = [["='GSEA_Summary'!L2"], ["='GSEA_Summary'!L5"], ["='GSEA_Summary'!L6"]];
summary.getRange("A19:A21").format = { fill: LIGHT_GRAY, font: { bold: true } };
summary.getRange("C19:C21").format.numberFormat = "0.0000";
summary.getRange("A18:D21").format.borders = { preset: "all", style: "thin", color: GRID };

summary.getRange("A24:H27").merge();
summary.getRange("A24").values = [["Scope: the requested sheets contain only plotted strict genes with finite positive PI/IPI (WT_TEST 298/320; Q_CTR 695/807). Q_CTR APR genes are evaluated on the WT test vs WT ctr mRNA ranking, not on a Q_CTR transcriptome contrast. The stage identities of WT test and WT ctr remain unresolved."]];
summary.getRange("A24:H27").format = { fill: AMBER, font: { color: "#7A4E00" }, wrapText: true, verticalAlignment: "center" };

summary.getRange("J7:K9").values = [["Gene set", "NES"], ["WT_TEST Strict", null], ["Q_CTR Strict", null]];
summary.getRange("K8:K9").formulas = [["='GSEA_Summary'!L3"], ["='GSEA_Summary'!L4"]];
const chart = summary.charts.add("bar", summary.getRange("J7:K9"));
chart.title = "Primary normalized enrichment scores";
chart.hasLegend = false;
chart.xAxis = { numberFormatCode: "0.0" };
chart.setPosition("F7", "M21");

summary.getRange("A:H").format.columnWidth = 16;
summary.getRange("A:A").format.columnWidth = 25;
summary.getRange("D:D").format.columnWidth = 42;
summary.freezePanes.freezeRows(2);

methods.showGridLines = false;
methods.getRange("A1:C1").values = [["Item", "Parameter / result", "Rationale or QC note"]];
methods.getRange("A2:C18").values = [
  ["Analysis question", "Direction of two strict APR sets in the mRNA ranking", "Tests concentration toward the WT test or WT ctr end."],
  ["WT_TEST input", 298, "Unique gene IDs; all mapped."],
  ["Q_CTR input", 695, "Unique gene IDs; all mapped."],
  ["Set overlap", 281, "The two primary sets are not independent evidence."],
  ["WT_TEST only", 17, "Exploratory analysis; limited power."],
  ["Q_CTR only", 414, "Exploratory analysis."],
  ["Complete mRNA results", 9089, "Includes significant and nonsignificant genes."],
  ["Primary background", 8008, "Protein-coding genes."],
  ["Primary ranking", "sign(log2FC) × -log10(raw P)", "P floor 1e-300; log2FC resolves ties."],
  ["Primary GSEA", "Weighted running sum, weight=1", "Weights genes by ranking-score magnitude."],
  ["Sensitivity analysis", "log2FC order, unweighted KS-type", "Checks that direction is not dependent on P-value weighting."],
  ["Permutations", 20000, "Size-matched random gene sets with fixed seeds."],
  ["P value", "Plus-one empirical P", "Prevents zero exceedances from being reported as P=0."],
  ["Multiple testing", "BH correction for two primary tests", "Shared/unique components are explicitly exploratory."],
  ["Stage labels", "Unresolved", "Do not replace WT test/WT ctr with tachyzoite/bradyzoite."],
  ["Cross-omics scope", "mRNA direction is not Ribo-seq pausing intensity", "The analysis evaluates concentration within an mRNA ranking."],
  ["Sheet scope", "298/320 and 695/807", "Zero, Inf, or NA excluded some complete strict genes from the requested sheets."],
];
styleHeader(methods, "C");
methods.getRange("A:A").format.columnWidth = 25;
methods.getRange("B:B").format.columnWidth = 34;
methods.getRange("C:C").format.columnWidth = 72;
methods.getRange("A2:A18").format = { fill: LIGHT_BLUE, font: { bold: true } };
methods.getRange("A1:C18").format.wrapText = true;
methods.getRange("A1:C18").format.borders = { preset: "all", style: "thin", color: GRID };

legends.showGridLines = false;
legends.getRange("A1:C1").values = [["Figure", "Title", "Interpretation"]];
legends.getRange("A2:C6").values = [
  ["Figure 1", "Pre-ranked GSEA of the two strict APR sets", "Panels a and b show WT_TEST Strict and Q_CTR Strict. The x-axis runs from WT test to WT ctr; ticks mark set members and the dashed line marks the ES extreme. Negative ES/NES indicates concentration toward WT ctr."],
  ["Figure 2", "Robustness analyses", "Compares coding/all-gene backgrounds and signed -log10(P)/log2FC rankings. All points left of zero indicate consistent WT ctr direction. NES magnitudes should not be compared across different weighting schemes."],
  ["Figure 3", "Shared and set-specific components", "Panel a shows 281 shared, 17 WT_TEST-only, and 414 Q_CTR-only genes; panels b-d show their GSEA curves. The nonsignificant 17-gene result has limited power and does not prove absence of an effect."],
  ["Figure 4", "Leading-edge comparison", "Panel a shows leading-edge overlap; panel b lists the strongest WT-ctr-side core genes. Purple is shared, blue is WT-only, and pale red is Q-only leading edge."],
  ["Figure 5", "Representative leading-edge expression heatmap", "Row-standardized log2 expression across six mRNA samples. Blue and red indicate values below and above each gene's own mean; colors do not compare absolute expression between genes."],
];
styleHeader(legends, "C");
legends.getRange("A:A").format.columnWidth = 12;
legends.getRange("B:B").format.columnWidth = 36;
legends.getRange("C:C").format.columnWidth = 100;
legends.getRange("A2:A6").format = { fill: LIGHT_BLUE, font: { bold: true } };
legends.getRange("A1:C6").format.wrapText = true;
legends.getRange("A1:C6").format.rowHeight = 62;
legends.getRange("A1:C1").format.rowHeight = 30;
legends.getRange("A1:C6").format.borders = { preset: "all", style: "thin", color: GRID };

figuresIndex.showGridLines = false;
figuresIndex.getRange("A1:D1").values = [["Figure", "Base filename", "Purpose", "Available formats"]];
figuresIndex.getRange("A2:D6").values = [
  ["Figure 1", "Figure1_main_GSEA_curves", "Primary enrichment curves for the two strict APR sets", "SVG, PDF, TIFF, PNG"],
  ["Figure 2", "Figure2_GSEA_robustness", "Background and ranking sensitivity analyses", "SVG, PDF, TIFF, PNG"],
  ["Figure 3", "Figure3_shared_unique_GSEA", "Shared and set-specific gene-set decomposition", "SVG, PDF, TIFF, PNG"],
  ["Figure 4", "Figure4_leading_edge_comparison", "Leading-edge overlap and strongest core genes", "SVG, PDF, TIFF, PNG"],
  ["Figure 5", "Figure5_leading_edge_heatmap", "Representative leading-edge mRNA expression", "SVG, PDF, TIFF, PNG"],
];
styleHeader(figuresIndex, "D");
figuresIndex.getRange("A:A").format.columnWidth = 14;
figuresIndex.getRange("B:B").format.columnWidth = 42;
figuresIndex.getRange("C:C").format.columnWidth = 62;
figuresIndex.getRange("D:D").format.columnWidth = 26;
figuresIndex.getRange("A2:A6").format = { fill: LIGHT_BLUE, font: { bold: true } };
figuresIndex.getRange("A1:D6").format.borders = { preset: "all", style: "thin", color: GRID };

const formulaScan = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "final formula error scan",
});
await fs.writeFile(`${root}/06_qc/workbook_formula_scan.ndjson`, formulaScan.ndjson ?? "", "utf8");

const summaryInspect = await workbook.inspect({
  kind: "table",
  range: "Summary!A1:M27",
  include: "values,formulas",
  tableMaxRows: 30,
  tableMaxCols: 14,
});
await fs.writeFile(`${root}/06_qc/workbook_summary_inspect.ndjson`, summaryInspect.ndjson ?? "", "utf8");

const renderRanges = [
  ["Summary", "A1:M27"],
  ["GSEA_Summary", "A1:U21"],
  ["Set_Metadata", "A1:F6"],
  ["Gene_Union_712", "A1:R30"],
  ["Leading_Edge", "A1:AB30"],
  ["Ranked_Coding", "A1:Y30"],
  ["Heatmap_Source", "A1:AB30"],
  ["Methods_QC", "A1:C18"],
  ["Figure_Legends", "A1:C6"],
  ["Figures_Index", "A1:D6"],
];
for (const [sheetName, range] of renderRanges) {
  const preview = await workbook.render({ sheetName, range, scale: 1, format: "png" });
  const safe = sheetName.replaceAll("_", "-");
  await fs.writeFile(`${previewDir}/${safe}.png`, new Uint8Array(await preview.arrayBuffer()));
}

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outPath);
console.log(JSON.stringify({ outPath, sheets: workbook.worksheets.items.map((s) => s.name) }, null, 2));
