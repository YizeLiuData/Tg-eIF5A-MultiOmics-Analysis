# Figure contract

Core conclusion: The two strict Ribo-seq APR gene sets are evaluated on one complete mRNA-seq ranking, and shared-versus-specific decomposition determines whether any enrichment direction is common or condition-specific.

Figure archetype: quantitative grid.

Target output: publication-ready double-column figures with editable SVG text, PDF, 600-dpi TIFF, and 300-dpi PNG preview.

Backend: Python (matplotlib only).

Panel map:

- Figure 1: hero evidence; aligned enrichment curves for WT_TEST_Strict and Q_CTR_Strict.
- Figure 2: robustness; NES across background and ranking choices.
- Figure 3: gene-set composition and GSEA of the shared and unique components.
- Figure 4: leading-edge overlap and strongest core genes.
- Figure 5: representative leading-edge mRNA expression heatmap.

Statistics: weighted pre-ranked GSEA for the primary analysis; 20,000 size-matched gene-set permutations; same-sign NES normalization; plus-one empirical P; BH correction across the two prespecified primary gene sets.

Source data: every quantitative panel is backed by a CSV table in `03_tables`.

Image integrity: no raster source images and no selective image adjustment; all panels are generated directly from tabular source data.

Reviewer risk: the two primary gene sets share 281 genes and are not statistically independent; the 17-gene WT_TEST-only subset has limited power; stage labels remain unresolved.
