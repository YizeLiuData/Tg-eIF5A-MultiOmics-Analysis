#!/usr/bin/env python3


from __future__ import annotations

import argparse
import hashlib
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


TARGETS = ["wt_test", "R_ctr", "R_test", "Q_ctr", "Q_test"]
LABEL = {
    "wt_test": "WT-test",
    "R_ctr": "R-CTR",
    "R_test": "R-test",
    "Q_ctr": "Q-CTR",
    "Q_test": "Q-test",
}
STATE_COLOR = {
    "wt_test": "#3775BA",
    "R_ctr": "#62BFAE",
    "R_test": "#087E75",
    "Q_ctr": "#E3A64F",
    "Q_test": "#B64342",
}
OTHER_COLOR = "#505050"
EXPECTED_ELIGIBLE = {"wt_test": 4740, "R_ctr": 5460, "R_test": 5403, "Q_ctr": 4767, "Q_test": 4643}
EXPECTED_STRICT = {"wt_test": 320, "R_ctr": 1, "R_test": 418, "Q_ctr": 807, "Q_test": 232}
EXPECTED_FINITE_PLOTTED = {"wt_test": 1068, "R_ctr": 1223, "R_test": 1422, "Q_ctr": 1375, "Q_test": 1148}
EXPECTED_STRICT_PLOTTED = {"wt_test": 298, "R_ctr": 1, "R_test": 375, "Q_ctr": 695, "Q_test": 219}

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "svg.hashsalt": "APR_WTCTR5_STRICT_ADAPTIVE_20260803",
        "pdf.fonttype": 42,
        "font.size": 7,
        "axes.linewidth": 0.7,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "legend.frameon": False,
        "savefig.facecolor": "white",
    }
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def save_fixed_artboard(fig: plt.Figure, base: Path) -> None:
    
    base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(base.with_suffix(".svg"), facecolor="white")
    fig.savefig(base.with_suffix(".pdf"), facecolor="white")
    fig.savefig(base.with_suffix(".png"), dpi=300, facecolor="white")
    fig.savefig(
        base.with_suffix(".tiff"),
        dpi=600,
        facecolor="white",
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(fig)


def integer_adaptive_bounds(values: pd.Series, padding_fraction: float = 0.05, force_zero_lower: bool = False) -> dict:
    array = pd.to_numeric(values, errors="coerce").to_numpy(dtype=float)
    finite = array[np.isfinite(array)]
    if finite.size == 0:
        raise ValueError("Cannot calculate an axis from an empty finite array")
    raw_min = float(finite.min())
    raw_max = float(finite.max())
    span = raw_max - raw_min
    if span == 0:
        span = max(abs(raw_max), 1.0)
    padding = span * padding_fraction
    if force_zero_lower:
        final_min = 0.0
        padded_min = 0.0
    else:
        padded_min = raw_min - padding
        final_min = float(math.floor(padded_min))
    padded_max = raw_max + padding
    final_max = float(math.ceil(padded_max))
    return {
        "n_finite": int(finite.size),
        "raw_min": raw_min,
        "raw_max": raw_max,
        "span": float(raw_max - raw_min),
        "padding_fraction": padding_fraction,
        "padding_value": float(padding),
        "padded_min": float(padded_min),
        "padded_max": float(padded_max),
        "final_min": final_min,
        "final_max": final_max,
    }


def percent_text(numerator: int, denominator: int) -> str:
    value = 100.0 * numerator / denominator if denominator else np.nan
    if 0 < value < 0.1:
        return "<0.1%"
    return f"{value:.1f}%"


def set_gid(artist, gid: str):
    artist.set_gid(gid)
    return artist


def finite_positive_log2(values):
    array = np.asarray(values, dtype=float)
    if np.any(~np.isfinite(array)) or np.any(array <= 0):
        raise ValueError("log2 requires finite positive values")
    return np.log2(array)


def prepare_data(run: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    inputs = run / "00_input_links"
    volcano = pd.read_csv(inputs / "strict_highlight_volcano_source_data.tsv", sep="\t", na_values=["NA"])
    quadrant = pd.read_csv(inputs / "strict_highlight_quadrant_source_data.tsv", sep="\t", na_values=["NA"])

    volcano = volcano.copy()
    volcano["adaptive_plot_x"] = pd.to_numeric(volcano["model_relative_logFC"], errors="coerce")
    volcano["adaptive_plot_y"] = pd.to_numeric(volcano["minus_log10_P"], errors="coerce")
    volcano["adaptive_display_class"] = np.where(volcano["strict_PI_rPI_evidence"], "strict", "other")

    eligible = quadrant["pairwise_common_eligible"].astype(bool)
    rpi = pd.to_numeric(quadrant["rPI"], errors="coerce")
    pi = pd.to_numeric(quadrant["target_PI_pooled"], errors="coerce")
    rpi_finite_positive = np.isfinite(rpi) & (rpi > 0)
    pi_finite_positive = np.isfinite(pi) & (pi > 0)
    plotted = eligible & rpi_finite_positive & pi_finite_positive

    quadrant = quadrant.copy()
    quadrant["rPI_is_NA"] = rpi.isna()
    quadrant["rPI_is_zero"] = rpi.eq(0)
    quadrant["rPI_is_positive_Inf"] = np.isposinf(rpi)
    quadrant["target_PI_is_NA"] = pi.isna()
    quadrant["target_PI_is_zero"] = pi.eq(0)
    quadrant["target_PI_is_positive_Inf"] = np.isposinf(pi)
    quadrant["plotted_finite_positive"] = plotted
    quadrant["adaptive_log2_rPI"] = np.nan
    quadrant["adaptive_log2_target_PI"] = np.nan
    
    quadrant.loc[plotted, "adaptive_log2_rPI"] = finite_positive_log2(rpi.loc[plotted])
    quadrant.loc[plotted, "adaptive_log2_target_PI"] = finite_positive_log2(pi.loc[plotted])

    reason = np.full(len(quadrant), "finite_positive_plotted", dtype=object)
    reason[~eligible.to_numpy()] = "not_in_pairwise_common_set"
    within = eligible.to_numpy()
    both_inf = np.isposinf(rpi.to_numpy()) & np.isposinf(pi.to_numpy())
    reason[within & both_inf] = "rPI_Inf_and_PI_Inf_not_plotted"
    reason[within & np.isposinf(rpi.to_numpy()) & ~both_inf] = "rPI_Inf_not_plotted"
    reason[within & rpi.eq(0).to_numpy()] = "rPI_zero_not_plotted"
    reason[within & rpi.isna().to_numpy()] = "rPI_NA_not_plotted"
    reason[within & np.isfinite(rpi.to_numpy()) & (rpi.to_numpy() > 0) & np.isposinf(pi.to_numpy())] = "PI_Inf_not_plotted"
    reason[within & np.isfinite(rpi.to_numpy()) & (rpi.to_numpy() > 0) & pi.eq(0).to_numpy()] = "PI_zero_not_plotted"
    reason[within & np.isfinite(rpi.to_numpy()) & (rpi.to_numpy() > 0) & pi.isna().to_numpy()] = "PI_NA_not_plotted"
    quadrant["adaptive_not_plotted_reason"] = reason
    quadrant["adaptive_display_class"] = np.select(
        [plotted & quadrant["strict_PI_rPI_evidence"], plotted],
        ["strict", "other"],
        default="not_plotted",
    )

    vxb = integer_adaptive_bounds(volcano["adaptive_plot_x"])
    vyb = integer_adaptive_bounds(volcano["adaptive_plot_y"], force_zero_lower=True)
    plotted_rows = quadrant[quadrant["plotted_finite_positive"]]
    qxb = integer_adaptive_bounds(plotted_rows["adaptive_log2_rPI"])
    qyb = integer_adaptive_bounds(plotted_rows["adaptive_log2_target_PI"])

    volcano["within_adaptive_axes"] = (
        volcano["adaptive_plot_x"].between(vxb["final_min"], vxb["final_max"], inclusive="both")
        & volcano["adaptive_plot_y"].between(vyb["final_min"], vyb["final_max"], inclusive="both")
    )
    quadrant["within_adaptive_axes"] = False
    quadrant.loc[plotted, "within_adaptive_axes"] = (
        quadrant.loc[plotted, "adaptive_log2_rPI"].between(qxb["final_min"], qxb["final_max"], inclusive="both")
        & quadrant.loc[plotted, "adaptive_log2_target_PI"].between(qyb["final_min"], qyb["final_max"], inclusive="both")
    )

    summary_rows = []
    for state in TARGETS:
        current = quadrant[(quadrant["stress_state"] == state) & quadrant["pairwise_common_eligible"]]
        current_plotted = current[current["plotted_finite_positive"]]
        strict_total = int(current["strict_PI_rPI_evidence"].sum())
        strict_plotted = int(current_plotted["strict_PI_rPI_evidence"].sum())
        summary_rows.append(
            {
                "contrast_id": f"{state}_vs_wt_ctr",
                "stress_state": state,
                "state_label": LABEL[state],
                "pairwise_common_genes": len(current),
                "finite_positive_plotted": len(current_plotted),
                "not_plotted_zero_inf_or_NA": len(current) - len(current_plotted),
                "strict_evidence_total": strict_total,
                "strict_evidence_plotted": strict_plotted,
                "strict_evidence_not_plotted": strict_total - strict_plotted,
                "strict_percent_of_pairwise_common": 100.0 * strict_total / len(current),
                "rPI_zero": int(current["rPI_is_zero"].sum()),
                "rPI_positive_Inf": int(current["rPI_is_positive_Inf"].sum()),
                "rPI_NA": int(current["rPI_is_NA"].sum()),
                "target_PI_zero": int(current["target_PI_is_zero"].sum()),
                "target_PI_positive_Inf": int(current["target_PI_is_positive_Inf"].sum()),
                "target_PI_NA": int(current["target_PI_is_NA"].sum()),
            }
        )
    summary = pd.DataFrame(summary_rows)

    max_total = int(summary["pairwise_common_genes"].max())
    label_clearance = max_total * 0.08
    safety_margin = max_total * 0.04
    summary_ymax = float(math.ceil((max_total + label_clearance + safety_margin) / 500.0) * 500.0)
    summary_label_y = summary["pairwise_common_genes"] + max_total * 0.035
    summary["label_y"] = summary_label_y
    summary["axis_ymin"] = 0.0
    summary["axis_ymax"] = summary_ymax

    axis_rows = []
    for figure, axis, bounds in [
        ("volcano", "x", vxb),
        ("volcano", "y", vyb),
        ("quadrant_finite_positive_only", "x", qxb),
        ("quadrant_finite_positive_only", "y", qyb),
    ]:
        axis_rows.append({"figure": figure, "axis": axis, **bounds})
    axis_rows.append(
        {
            "figure": "summary",
            "axis": "y",
            "n_finite": len(summary),
            "raw_min": 0.0,
            "raw_max": float(max_total),
            "span": float(max_total),
            "padding_fraction": np.nan,
            "padding_value": float(label_clearance + safety_margin),
            "padded_min": 0.0,
            "padded_max": float(max_total + label_clearance + safety_margin),
            "final_min": 0.0,
            "final_max": summary_ymax,
        }
    )
    axis_audit = pd.DataFrame(axis_rows)
    limits = {"volcano_x": vxb, "volcano_y": vyb, "quadrant_x": qxb, "quadrant_y": qyb, "summary_ymax": summary_ymax}

    source = run / "02_figures/source_data"
    volcano.to_csv(source / "adaptive_vector_volcano_source_data.tsv", sep="\t", index=False, na_rep="NA")
    quadrant.to_csv(source / "adaptive_vector_quadrant_source_data.tsv", sep="\t", index=False, na_rep="NA")
    summary.to_csv(source / "adaptive_vector_summary_source_data.tsv", sep="\t", index=False)
    axis_audit.to_csv(source / "adaptive_axis_limits.tsv", sep="\t", index=False, na_rep="NA")
    return volcano, quadrant, summary, axis_audit, limits


def make_volcano(run: Path, volcano: pd.DataFrame, summary: pd.DataFrame, limits: dict) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 5.4), sharex=True, sharey=True)
    axes = axes.flat
    fig.subplots_adjust(left=0.075, right=0.985, bottom=0.09, top=0.88, wspace=0.28, hspace=0.38)
    set_gid(fig.text(0.02, 0.975, "Strict start-pausing evidence across five stress states versus WT-CTR", ha="left", va="top", fontweight="bold", fontsize=11), "figure_title")
    set_gid(fig.text(0.025, 0.90, "a", ha="left", va="top", fontweight="bold", fontsize=10), "panel_label_a")

    xmin, xmax = limits["volcano_x"]["final_min"], limits["volcano_x"]["final_max"]
    ymin, ymax = limits["volcano_y"]["final_min"], limits["volcano_y"]["final_max"]

    for index, state in enumerate(TARGETS):
        ax = axes[index]
        ax.set_gid(f"panel_{state}")
        current = volcano[volcano["stress_state"] == state]
        other = current[~current["strict_PI_rPI_evidence"]]
        strict = current[current["strict_PI_rPI_evidence"]]

        set_gid(
            ax.scatter(other["adaptive_plot_x"], other["adaptive_plot_y"], s=4, c=OTHER_COLOR, alpha=0.23, edgecolors="none", zorder=1),
            f"{state}_other_tested_genes",
        )
        set_gid(
            ax.scatter(strict["adaptive_plot_x"], strict["adaptive_plot_y"], s=15, c=STATE_COLOR[state], alpha=0.92, edgecolors="black", linewidths=0.4, zorder=4),
            f"{state}_strict_evidence_genes",
        )
        set_gid(ax.axvline(0, color="#777777", lw=0.6, zorder=0), f"{state}_zero_effect_line")
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)
        set_gid(ax.set_title(LABEL[state], color=STATE_COLOR[state], fontweight="bold"), f"{state}_panel_title")
        ax.set_xlabel("Start/body effect (log2)")
        ax.set_ylabel("−log10 P")

        stats = summary[summary["stress_state"] == state].iloc[0]
        set_gid(
            ax.text(0.03, 0.97, f"tested n={len(current):,}\nstrict={int(stats.strict_evidence_total):,} ({percent_text(int(stats.strict_evidence_total), len(current))})", transform=ax.transAxes, va="top", fontsize=5.5, bbox=dict(facecolor="white", edgecolor="none", alpha=0.78, pad=1), zorder=6),
            f"{state}_count_annotation",
        )

        labels = strict.sort_values(["FDR_within_contrast", "model_relative_logFC"], ascending=[True, False]).head(3)
        for rank, row in enumerate(labels.itertuples()):
            name = row.gene_name if isinstance(row.gene_name, str) and row.gene_name not in ("", "-") else row.gene_id
            set_gid(
                ax.annotate(name, (row.adaptive_plot_x, row.adaptive_plot_y), xytext=(0.52, 0.90 - 0.095 * rank), textcoords=ax.transAxes, fontsize=5, color="#202020", ha="left", va="center", bbox=dict(facecolor="white", edgecolor="none", alpha=0.72, pad=0.5), arrowprops=dict(arrowstyle="-", color="#777777", lw=0.35, shrinkA=1, shrinkB=1), zorder=7),
                f"{state}_gene_label_{rank + 1}_{row.gene_id}",
            )

    axes[5].axis("off")
    axes[5].set_gid("legend_panel")
    handles = [
        plt.Line2D([], [], marker="o", ls="", markerfacecolor=OTHER_COLOR, markeredgecolor="none", alpha=0.45, label="Other tested genes"),
        plt.Line2D([], [], marker="o", ls="", markerfacecolor="white", markeredgecolor="black", label="Strict evidence\n(state colour)"),
    ]
    set_gid(axes[5].legend(handles=handles, loc="center", fontsize=7, title="Display class"), "legend_display_class")
    save_fixed_artboard(fig, run / "02_figures/volcano/Fig1_strict_highlight_adaptive_vector_volcano")


def make_quadrant(run: Path, quadrant: pd.DataFrame, summary: pd.DataFrame, limits: dict) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 5.5), sharex=True, sharey=True)
    axes = axes.flat
    fig.subplots_adjust(left=0.075, right=0.985, bottom=0.09, top=0.88, wspace=0.28, hspace=0.38)
    set_gid(fig.text(0.02, 0.975, "Strict PI/rPI evidence among finite positive values", ha="left", va="top", fontweight="bold", fontsize=11), "figure_title")
    set_gid(fig.text(0.025, 0.90, "a", ha="left", va="top", fontweight="bold", fontsize=10), "panel_label_a")

    xmin, xmax = limits["quadrant_x"]["final_min"], limits["quadrant_x"]["final_max"]
    ymin, ymax = limits["quadrant_y"]["final_min"], limits["quadrant_y"]["final_max"]

    for index, state in enumerate(TARGETS):
        ax = axes[index]
        ax.set_gid(f"panel_{state}")
        current = quadrant[(quadrant["stress_state"] == state) & quadrant["pairwise_common_eligible"]]
        plotted = current[current["plotted_finite_positive"]]
        other = plotted[~plotted["strict_PI_rPI_evidence"]]
        strict = plotted[plotted["strict_PI_rPI_evidence"]]

        set_gid(
            ax.scatter(other["adaptive_log2_rPI"], other["adaptive_log2_target_PI"], s=5, c=OTHER_COLOR, alpha=0.23, edgecolors="none", zorder=1),
            f"{state}_other_finite_positive_genes",
        )
        set_gid(
            ax.scatter(strict["adaptive_log2_rPI"], strict["adaptive_log2_target_PI"], s=17, c=STATE_COLOR[state], alpha=0.92, edgecolors="black", linewidths=0.45, zorder=4),
            f"{state}_strict_finite_positive_genes",
        )
        set_gid(ax.axvline(1, color="#666666", ls="--", lw=0.7, zorder=0), f"{state}_rPI_equals_2_line")
        set_gid(ax.axhline(1, color="#666666", ls="--", lw=0.7, zorder=0), f"{state}_PI_equals_2_line")
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)
        set_gid(ax.set_title(LABEL[state], color=STATE_COLOR[state], fontweight="bold"), f"{state}_panel_title")
        ax.set_xlabel("Relative pausing index, rPI (log2)")
        ax.set_ylabel("Pausing index, PI (log2)")

        stats = summary[summary["stress_state"] == state].iloc[0]
        annotation = (
            f"eligible={int(stats.pairwise_common_genes):,}\n"
            f"finite plotted={int(stats.finite_positive_plotted):,}; not plotted={int(stats.not_plotted_zero_inf_or_NA):,}\n"
            f"strict plotted={int(stats.strict_evidence_plotted):,}/{int(stats.strict_evidence_total):,}"
        )
        set_gid(
            ax.text(0.02, 0.98, annotation, transform=ax.transAxes, va="top", fontsize=5.1, bbox=dict(facecolor="white", edgecolor="none", alpha=0.82, pad=1), zorder=7),
            f"{state}_count_annotation",
        )

    axes[5].axis("off")
    axes[5].set_gid("legend_panel")
    handles = [
        plt.Line2D([], [], marker="o", ls="", markerfacecolor=OTHER_COLOR, markeredgecolor="none", alpha=0.45, label="Other finite positive genes"),
        plt.Line2D([], [], marker="o", ls="", markerfacecolor="white", markeredgecolor="black", label="Strict evidence\n(state colour)"),
    ]
    set_gid(axes[5].legend(handles=handles, loc="center", fontsize=7, title="Display class"), "legend_display_class")
    set_gid(
        axes[5].text(0.5, 0.15, "Only finite positive PI and rPI are plotted.\nZero, Inf and NA are counted but not drawn.", transform=axes[5].transAxes, ha="center", va="center", fontsize=6, color="#444444"),
        "legend_nonplotted_note",
    )
    save_fixed_artboard(fig, run / "02_figures/quadrant/Fig2_strict_highlight_adaptive_vector_PI_rPI")


def make_summary(run: Path, summary: pd.DataFrame, limits: dict) -> None:
    summary = summary.set_index("stress_state").loc[TARGETS].reset_index()
    x = np.arange(len(TARGETS))
    strict = summary["strict_evidence_total"].to_numpy()
    total = summary["pairwise_common_genes"].to_numpy()
    other = total - strict

    fig, ax = plt.subplots(figsize=(7.2, 3.25))
    fig.subplots_adjust(left=0.10, right=0.985, bottom=0.18, top=0.80)
    ax.set_gid("summary_panel")
    set_gid(fig.text(0.02, 0.97, "a", ha="left", va="top", fontweight="bold", fontsize=10), "panel_label_a")
    set_gid(fig.text(0.10, 0.93, "Strict evidence remains a subset of the complete testable gene set", ha="left", va="top", fontweight="bold", fontsize=10), "figure_title")

    for index, state in enumerate(TARGETS):
        set_gid(ax.bar(index, strict[index], width=0.68, color=STATE_COLOR[state], edgecolor="none", zorder=3)[0], f"{state}_strict_count_bar")
        set_gid(ax.bar(index, other[index], bottom=strict[index], width=0.68, color=OTHER_COLOR, alpha=0.78, edgecolor="none", zorder=2)[0], f"{state}_other_count_bar")
        set_gid(
            ax.text(index, summary.loc[index, "label_y"], f"strict {strict[index]:,}\n{percent_text(int(strict[index]), int(total[index]))}", ha="center", va="bottom", fontsize=6.5, color=STATE_COLOR[state], fontweight="bold"),
            f"{state}_strict_count_label",
        )
    ax.set_xticks(x, [LABEL[state] for state in TARGETS])
    ax.set_ylabel("Pairwise-common genes")
    ax.set_xlim(-0.58, 4.58)
    ax.set_ylim(0, limits["summary_ymax"])
    handles = [
        plt.Rectangle((0, 0), 1, 1, facecolor="white", edgecolor="black", label="Strict evidence (state colour)"),
        plt.Rectangle((0, 0), 1, 1, facecolor=OTHER_COLOR, alpha=0.78, edgecolor="none", label="Other pairwise-common genes"),
    ]
    set_gid(ax.legend(handles=handles, loc="upper right", fontsize=7), "legend_display_class")
    save_fixed_artboard(fig, run / "02_figures/summary/Fig3_strict_highlight_adaptive_vector_summary")


def write_numerical_audit(run: Path, volcano: pd.DataFrame, quadrant: pd.DataFrame, summary: pd.DataFrame, limits: dict) -> None:
    observed_eligible = dict(zip(summary["stress_state"], summary["pairwise_common_genes"].astype(int)))
    observed_strict = dict(zip(summary["stress_state"], summary["strict_evidence_total"].astype(int)))
    observed_plotted = dict(zip(summary["stress_state"], summary["finite_positive_plotted"].astype(int)))
    observed_strict_plotted = dict(zip(summary["stress_state"], summary["strict_evidence_plotted"].astype(int)))
    eligible = quadrant["pairwise_common_eligible"]
    forbidden = eligible & (
        quadrant["rPI_is_zero"]
        | quadrant["rPI_is_positive_Inf"]
        | quadrant["rPI_is_NA"]
        | quadrant["target_PI_is_zero"]
        | quadrant["target_PI_is_positive_Inf"]
        | quadrant["target_PI_is_NA"]
    )
    plotted = quadrant["plotted_finite_positive"]
    checks = [
        ("pairwise-common counts match anchors", observed_eligible == EXPECTED_ELIGIBLE, str(observed_eligible)),
        ("strict counts match anchors", observed_strict == EXPECTED_STRICT, str(observed_strict)),
        ("finite-positive plotted counts match anchors", observed_plotted == EXPECTED_FINITE_PLOTTED, str(observed_plotted)),
        ("plotted strict counts match anchors", observed_strict_plotted == EXPECTED_STRICT_PLOTTED, str(observed_strict_plotted)),
        ("all volcano rows retained", len(volcano) == 25013, f"rows={len(volcano)}"),
        ("all volcano points inside adaptive axes", bool(volcano["within_adaptive_axes"].all()), f"outside={int((~volcano.within_adaptive_axes).sum())}"),
        ("all plotted quadrant points inside adaptive axes", bool(quadrant.loc[plotted, "within_adaptive_axes"].all()), f"outside={int((~quadrant.loc[plotted, 'within_adaptive_axes']).sum())}"),
        ("zero Inf and NA are never plotted", not bool((forbidden & plotted).any()), f"forbidden_plotted={int((forbidden & plotted).sum())}"),
        ("quadrant full rows retained", len(quadrant) == 40700, f"rows={len(quadrant)}"),
        ("nonplotted rows have explicit reason", quadrant.loc[~plotted, "adaptive_not_plotted_reason"].notna().all(), f"not_plotted={int((~plotted).sum())}"),
        ("quadrant thresholds lie within axes", limits["quadrant_x"]["final_min"] < 1 < limits["quadrant_x"]["final_max"] and limits["quadrant_y"]["final_min"] < 1 < limits["quadrant_y"]["final_max"], "PI=2 and rPI=2 log2 threshold = 1"),
    ]
    audit = pd.DataFrame([{"check": name, "status": "PASS" if passed else "FAIL", "evidence": evidence} for name, passed, evidence in checks])
    audit.to_csv(run / "01_audit/numerical_and_axis_audit.tsv", sep="\t", index=False)
    if audit["status"].eq("FAIL").any():
        raise SystemExit("Adaptive-vector numerical/axis audit failed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir")
    args = parser.parse_args()
    run = Path(args.run_dir).resolve()

    volcano, quadrant, summary, _, limits = prepare_data(run)
    write_numerical_audit(run, volcano, quadrant, summary, limits)
    make_volcano(run, volcano, summary, limits)
    make_quadrant(run, quadrant, summary, limits)
    make_summary(run, summary, limits)

    with (run / "00_manifest/input_checksums.sha256").open("w", encoding="utf-8") as handle:
        for path in sorted((run / "00_input_links").iterdir()):
            handle.write(f"{sha256(path.resolve())}  00_input_links/{path.name}\n")


if __name__ == "__main__":
    main()
