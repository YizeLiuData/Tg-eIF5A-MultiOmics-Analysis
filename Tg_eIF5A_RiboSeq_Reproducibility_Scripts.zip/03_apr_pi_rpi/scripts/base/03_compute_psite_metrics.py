#!/usr/bin/env python3


from __future__ import annotations

import argparse
import csv
import gzip
import math
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd
from Bio import SeqIO


START_MIN, START_MAX = -60, 150
STOP_MIN, STOP_MAX = -150, 60
INTERNAL_MIN, INTERNAL_MAX = -30, 30


def read_tsv(path: Path) -> list[dict[str, str]]:
    with open(path, encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def load_counts(path: Path) -> dict[str, Counter]:
    out: dict[str, Counter] = defaultdict(Counter)
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        for row in reader:
            out[row["transcript_id"]][int(row["position0"])] = int(row["count"])
    return out


def finite_or_text(value: float) -> str:
    if math.isnan(value):
        return "NA"
    if math.isinf(value):
        return "Inf" if value > 0 else "-Inf"
    return f"{value:.10g}"


def aggregate_profile(
    counts: dict[str, Counter],
    metas: dict[str, dict],
    genes: set[str],
    center_key: str,
    rel_min: int,
    rel_max: int,
) -> tuple[dict[int, float], dict[int, int], dict[int, tuple[str, float]]]:
    sums = Counter()
    ns = Counter()
    maxima: dict[int, tuple[str, float]] = {}
    for tid, meta in metas.items():
        if meta["gene_id"] not in genes:
            continue
        cds_codons = meta["cds_length"] / 3.0
        tx_counts = counts.get(tid, {})
        cds_total = sum(v for p, v in tx_counts.items() if meta["cds_start0"] <= p < meta["cds_end0"])
        cds_mean = cds_total / cds_codons if cds_codons > 0 else 0.0
        if cds_mean <= 0:
            continue
        center = meta[center_key]
        for rel in range(rel_min, rel_max + 1):
            value = tx_counts.get(center + rel, 0) / cds_mean
            sums[rel] += value
            ns[rel] += 1
            if rel not in maxima or value > maxima[rel][1]:
                maxima[rel] = (meta["gene_id"], value)
    return dict(sums), dict(ns), maxima


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--samtools", default="samtools")
    args = ap.parse_args()
    run = Path(args.run_dir)

    ref_rows = read_tsv(run / "01_reference/canonical_transcripts.tsv")
    metas: dict[str, dict] = {}
    gene_to_tid: dict[str, str] = {}
    for row in ref_rows:
        item = dict(row)
        for key in ["transcript_length", "cds_start0", "cds_end0", "sense_cds_end0", "cds_length", "sense_cds_length"]:
            item[key] = int(item[key])
        for key in ["start_is_aug", "stop_in_cds", "cds_intervals_contiguous"]:
            item[key] = item[key] == "True"
        item["stop_start0"] = item["sense_cds_end0"]
        metas[item["transcript_id"]] = item
        gene_to_tid[item["gene_id"]] = item["transcript_id"]

    fasta = {r.id: str(r.seq).upper() for r in SeqIO.parse(run / "01_reference/canonical_transcripts.fasta", "fasta")}
    sample_meta = read_tsv(run / "00_manifest/sample_metadata.tsv")
    samples = [r["sample"] for r in sample_meta]
    sample_info = {r["sample"]: r for r in sample_meta}

    offsets: dict[tuple[str, int], int] = {}
    offset_rows = read_tsv(run / "00_input/psite_offsets_all_lengths.tsv")
    for row in offset_rows:
        offsets[(row["sample"], int(row["length"]))] = int(row["corrected_offset_from_5"])

    psite_dir = run / "03_psite"
    qc_dir = run / "04_qc"
    meta_dir = run / "05_metagene"
    pi_dir = run / "06_pi_rpi"
    for d in [psite_dir, qc_dir, meta_dir, pi_dir]:
        d.mkdir(parents=True, exist_ok=True)

    metric_rows: list[dict] = []
    sample_qc_rows: list[dict] = []
    length_qc_rows: list[dict] = []
    frame_rows: list[dict] = []
    own_profile_rows: list[dict] = []
    own_stop_rows: list[dict] = []

    for sample in samples:
        bam = run / "02_alignment" / f"{sample}.bam"
        counts: dict[str, Counter] = defaultdict(Counter)
        length_total = Counter()
        length_used = Counter()
        missing_offset = Counter()
        out_of_bounds = Counter()
        reverse_seen = 0
        unknown_transcript = 0
        proc = subprocess.Popen([args.samtools, "view", str(bam)], stdout=subprocess.PIPE, text=True)
        assert proc.stdout is not None
        for line in proc.stdout:
            fields = line.rstrip("\n").split("\t")
            if len(fields) < 11:
                continue
            flag = int(fields[1])
            tid = fields[2]
            pos0 = int(fields[3]) - 1
            seq = fields[9]
            read_len = len(seq)
            length_total[read_len] += 1
            if flag & 16:
                reverse_seen += 1
                continue
            if tid not in metas:
                unknown_transcript += 1
                continue
            key = (sample, read_len)
            if key not in offsets:
                missing_offset[read_len] += 1
                continue
            psite0 = pos0 + offsets[key]
            if psite0 < 0 or psite0 >= metas[tid]["transcript_length"]:
                out_of_bounds[read_len] += 1
                continue
            counts[tid][psite0] += 1
            length_used[read_len] += 1
        if proc.wait() != 0:
            raise RuntimeError(f"samtools view failed for {sample}")

        counts_path = psite_dir / f"{sample}.psite_counts.tsv.gz"
        with gzip.open(counts_path, "wt", encoding="utf-8", newline="") as out:
            writer = csv.writer(out, delimiter="\t")
            writer.writerow(["transcript_id", "position0", "count"])
            for tid in sorted(counts):
                for position0, count in sorted(counts[tid].items()):
                    writer.writerow([tid, position0, count])

        for length in sorted(set(length_total) | set(length_used) | set(missing_offset) | set(out_of_bounds)):
            length_qc_rows.append({
                "sample": sample,
                "length": length,
                "aligned_sense_reads": length_total[length],
                "offset_available": (sample, length) in offsets,
                "corrected_offset_from_5": offsets.get((sample, length), ""),
                "psite_used_reads": length_used[length],
                "missing_offset_reads": missing_offset[length],
                "out_of_bounds_reads": out_of_bounds[length],
            })

        region_counts = Counter()
        frame_counts = Counter()
        eligible_genes: set[str] = set()
        for tid, meta in metas.items():
            c = counts.get(tid, Counter())
            utr5 = sum(v for p, v in c.items() if p < meta["cds_start0"])
            cds_total = sum(v for p, v in c.items() if meta["cds_start0"] <= p < meta["cds_end0"])
            sense_total = sum(v for p, v in c.items() if meta["cds_start0"] <= p < meta["sense_cds_end0"])
            utr3 = sum(v for p, v in c.items() if p >= meta["cds_end0"])
            start_count = sum(c.get(p, 0) for p in range(meta["cds_start0"], meta["cds_start0"] + 3))
            body_start = meta["cds_start0"] + 3
            body_end = meta["sense_cds_end0"]
            body_count = sum(v for p, v in c.items() if body_start <= p < body_end)
            body_codons = max(0, (body_end - body_start) // 3)
            body_mean = body_count / body_codons if body_codons > 0 else float("nan")
            if body_count == 0:
                pi = float("inf") if start_count > 0 else float("nan")
            else:
                pi = start_count / body_mean
            eligible = cds_total > 3 and meta["start_is_aug"]
            if eligible:
                eligible_genes.add(meta["gene_id"])
            for p, v in c.items():
                if meta["cds_start0"] <= p < meta["sense_cds_end0"]:
                    frame_counts[(p - meta["cds_start0"]) % 3] += v
            region_counts["utr5"] += utr5
            region_counts["cds"] += cds_total
            region_counts["utr3"] += utr3
            metric_rows.append({
                "sample": sample,
                "genotype": sample_info[sample]["genotype"],
                "condition": sample_info[sample]["condition"],
                "replicate": sample_info[sample]["replicate"],
                "gene_id": meta["gene_id"],
                "transcript_id": tid,
                "start_is_aug": meta["start_is_aug"],
                "cds_length": meta["cds_length"],
                "cds_codons": meta["cds_length"] / 3.0,
                "utr5_psites": utr5,
                "cds_psites": cds_total,
                "sense_cds_psites": sense_total,
                "utr3_psites": utr3,
                "start_codon_psites": start_count,
                "body_psites": body_count,
                "body_codons": body_codons,
                "body_mean_per_codon": finite_or_text(body_mean),
                "PI": finite_or_text(pi),
                "PI_ge_2": (not math.isnan(pi)) and pi >= 2,
                "zero_body_flag": body_count == 0,
                "metagene_eligible_cds_gt3": eligible,
            })

        start_sums, start_ns, _ = aggregate_profile(counts, metas, eligible_genes, "cds_start0", START_MIN, START_MAX)
        stop_sums, stop_ns, _ = aggregate_profile(counts, metas, eligible_genes, "stop_start0", STOP_MIN, STOP_MAX)
        for rel in range(START_MIN, START_MAX + 1):
            own_profile_rows.append({
                "sample": sample, "set": "sample_own", "position_nt": rel,
                "sum_normalized": start_sums.get(rel, 0.0), "n_genes": start_ns.get(rel, 0),
                "mean_normalized": start_sums.get(rel, 0.0) / start_ns[rel] if start_ns.get(rel, 0) else float("nan"),
            })
        for rel in range(STOP_MIN, STOP_MAX + 1):
            own_stop_rows.append({
                "sample": sample, "set": "sample_own", "position_nt": rel,
                "sum_normalized": stop_sums.get(rel, 0.0), "n_genes": stop_ns.get(rel, 0),
                "mean_normalized": stop_sums.get(rel, 0.0) / stop_ns[rel] if stop_ns.get(rel, 0) else float("nan"),
            })
        total_used = sum(length_used.values())
        frame_total = sum(frame_counts.values())
        for frame in range(3):
            frame_rows.append({
                "sample": sample, "frame": frame, "cds_psite_reads": frame_counts[frame],
                "fraction": frame_counts[frame] / frame_total if frame_total else float("nan"),
            })
        sample_qc_rows.append({
            "sample": sample,
            "sense_unique_alignments": sum(length_total.values()),
            "psite_used_reads": total_used,
            "missing_offset_reads": sum(missing_offset.values()),
            "out_of_bounds_reads": sum(out_of_bounds.values()),
            "reverse_reads_seen_in_sense_bam": reverse_seen,
            "unknown_transcript_reads": unknown_transcript,
            "utr5_psites": region_counts["utr5"],
            "cds_psites": region_counts["cds"],
            "utr3_psites": region_counts["utr3"],
            "eligible_genes_cds_gt3_aug": len(eligible_genes),
        })

    pd.DataFrame(metric_rows).to_csv(pi_dir / "per_gene_per_sample_PI.tsv", sep="\t", index=False, na_rep="NA")
    pd.DataFrame(sample_qc_rows).to_csv(qc_dir / "sample_psite_qc.tsv", sep="\t", index=False)
    pd.DataFrame(length_qc_rows).to_csv(qc_dir / "length_offset_qc.tsv", sep="\t", index=False)
    pd.DataFrame(frame_rows).to_csv(qc_dir / "frame_periodicity.tsv", sep="\t", index=False)
    pd.DataFrame(own_profile_rows).to_csv(meta_dir / "start_metagene_sample_own.tsv", sep="\t", index=False)
    pd.DataFrame(own_stop_rows).to_csv(meta_dir / "stop_metagene_sample_own.tsv", sep="\t", index=False)

    metrics = pd.DataFrame(metric_rows)
    metrics["metagene_eligible_cds_gt3"] = metrics["metagene_eligible_cds_gt3"].astype(bool)
    common_rows: list[dict] = []
    stop_common_rows: list[dict] = []
    drop_rows: list[dict] = []
    loo_rows: list[dict] = []
    common_sets: dict[str, set[str]] = {}
    for genotype in ["wt", "R", "Q"]:
        sub = metrics[metrics["genotype"] == genotype]
        pass_n = sub.groupby("gene_id")["metagene_eligible_cds_gt3"].sum()
        common = set(pass_n[pass_n == 6].index)
        common_sets[genotype] = common
        with open(meta_dir / f"common_genes_{genotype}.txt", "w", encoding="utf-8") as out:
            for gene in sorted(common):
                out.write(gene + "\n")

    for sample in samples:
        genotype = sample_info[sample]["genotype"]
        common = common_sets[genotype]
        counts = load_counts(psite_dir / f"{sample}.psite_counts.tsv.gz")
        start_sums, start_ns, maxima = aggregate_profile(counts, metas, common, "cds_start0", START_MIN, START_MAX)
        stop_sums, stop_ns, _ = aggregate_profile(counts, metas, common, "stop_start0", STOP_MIN, STOP_MAX)
        sample_metrics = metrics[(metrics["sample"] == sample) & (metrics["gene_id"].isin(common))]
        cutoff = sample_metrics["cds_psites"].quantile(0.99) if len(sample_metrics) else float("inf")
        drop_genes = set(sample_metrics.loc[sample_metrics["cds_psites"] < cutoff, "gene_id"])
        drop_sums, drop_ns, _ = aggregate_profile(counts, metas, drop_genes, "cds_start0", START_MIN, START_MAX)
        for rel in range(START_MIN, START_MAX + 1):
            n = start_ns.get(rel, 0)
            common_rows.append({
                "sample": sample, "genotype": genotype, "condition": sample_info[sample]["condition"],
                "position_nt": rel, "sum_normalized": start_sums.get(rel, 0.0), "n_genes": n,
                "mean_normalized": start_sums.get(rel, 0.0) / n if n else float("nan"),
            })
            dn = drop_ns.get(rel, 0)
            drop_rows.append({
                "sample": sample, "genotype": genotype, "condition": sample_info[sample]["condition"],
                "position_nt": rel, "sum_normalized": drop_sums.get(rel, 0.0), "n_genes": dn,
                "mean_normalized": drop_sums.get(rel, 0.0) / dn if dn else float("nan"),
            })
        for rel in range(STOP_MIN, STOP_MAX + 1):
            n = stop_ns.get(rel, 0)
            stop_common_rows.append({
                "sample": sample, "genotype": genotype, "condition": sample_info[sample]["condition"],
                "position_nt": rel, "sum_normalized": stop_sums.get(rel, 0.0), "n_genes": n,
                "mean_normalized": stop_sums.get(rel, 0.0) / n if n else float("nan"),
            })
        n0 = start_ns.get(0, 0)
        sum0 = start_sums.get(0, 0.0)
        max_gene, max_value = maxima.get(0, ("", 0.0))
        loo_rows.append({
            "sample": sample, "n_genes": n0, "start_mean": sum0 / n0 if n0 else float("nan"),
            "max_contributor_gene": max_gene, "max_contributor_value": max_value,
            "max_fraction_of_sum": max_value / sum0 if sum0 else float("nan"),
            "mean_without_max": (sum0 - max_value) / (n0 - 1) if n0 > 1 else float("nan"),
        })

    pd.DataFrame(common_rows).to_csv(meta_dir / "start_metagene_common.tsv", sep="\t", index=False)
    pd.DataFrame(stop_common_rows).to_csv(meta_dir / "stop_metagene_common.tsv", sep="\t", index=False)
    pd.DataFrame(drop_rows).to_csv(meta_dir / "start_metagene_common_drop_top1pct.tsv", sep="\t", index=False)
    pd.DataFrame(loo_rows).to_csv(meta_dir / "start_position_leave_one_out.tsv", sep="\t", index=False)


if __name__ == "__main__":
    main()
