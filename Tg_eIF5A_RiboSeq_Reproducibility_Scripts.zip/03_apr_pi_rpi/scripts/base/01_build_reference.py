#!/usr/bin/env python3


from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path
from urllib.parse import unquote

from Bio import SeqIO
from Bio.Seq import Seq


def parse_attrs(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for item in text.strip().split(";"):
        if not item:
            continue
        if "=" in item:
            key, value = item.split("=", 1)
            out[key] = unquote(value)
    return out


def revcomp(seq: str) -> str:
    return str(Seq(seq).reverse_complement())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--gff", required=True)
    ap.add_argument("--genome", required=True)
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    genome = {rec.id: str(rec.seq).upper() for rec in SeqIO.parse(args.genome, "fasta")}
    tx: dict[str, dict] = {}
    exons: dict[str, list[tuple[int, int]]] = defaultdict(list)
    cds: dict[str, list[tuple[int, int, str]]] = defaultdict(list)

    with open(args.gff, encoding="utf-8") as handle:
        for line in handle:
            if not line or line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) != 9:
                continue
            seqid, source, feature, start, end, score, strand, phase, attr_text = fields
            start0, end0 = int(start) - 1, int(end)
            attrs = parse_attrs(attr_text)
            if feature in {"mRNA", "transcript"} and "ID" in attrs:
                tid = attrs["ID"]
                parent = attrs.get("Parent", attrs.get("gene_id", "")).split(",")[0]
                tx[tid] = {
                    "transcript_id": tid,
                    "gene_id": parent,
                    "seqid": seqid,
                    "strand": strand,
                    "gff_start0": start0,
                    "gff_end0": end0,
                    "biotype": attrs.get("gene_ebi_biotype", ""),
                    "description": attrs.get("description", ""),
                }
            elif feature == "exon":
                for parent in attrs.get("Parent", "").split(","):
                    if parent:
                        exons[parent].append((start0, end0))
            elif feature == "CDS":
                for parent in attrs.get("Parent", "").split(","):
                    if parent:
                        cds[parent].append((start0, end0, phase))

    records: list[dict] = []
    seqs: dict[str, str] = {}
    for tid, meta in tx.items():
        if not cds.get(tid):
            continue
        tx_exons = exons.get(tid)
        if not tx_exons:
            
            tx_exons = [(a, b) for a, b, _ in cds[tid]]
            exon_source = "CDS_fallback"
        else:
            exon_source = "exon"
        if meta["seqid"] not in genome or meta["strand"] not in {"+", "-"}:
            continue
        ordered_exons = sorted(tx_exons, reverse=(meta["strand"] == "-"))
        pieces: list[str] = []
        cds_tx_intervals: list[tuple[int, int]] = []
        cursor = 0
        for ex_start, ex_end in ordered_exons:
            piece = genome[meta["seqid"]][ex_start:ex_end]
            if meta["strand"] == "-":
                piece = revcomp(piece)
            pieces.append(piece)
            for cds_start, cds_end, _phase in cds[tid]:
                ov_start = max(ex_start, cds_start)
                ov_end = min(ex_end, cds_end)
                if ov_start >= ov_end:
                    continue
                if meta["strand"] == "+":
                    local_start = cursor + (ov_start - ex_start)
                    local_end = cursor + (ov_end - ex_start)
                else:
                    local_start = cursor + (ex_end - ov_end)
                    local_end = cursor + (ex_end - ov_start)
                cds_tx_intervals.append((local_start, local_end))
            cursor += ex_end - ex_start

        transcript_seq = "".join(pieces).upper()
        if not cds_tx_intervals:
            continue
        cds_start0 = min(a for a, _ in cds_tx_intervals)
        cds_end0 = max(b for _, b in cds_tx_intervals)
        cds_len_sum = sum(b - a for a, b in cds_tx_intervals)
        cds_seq = transcript_seq[cds_start0:cds_end0]
        intervals_contiguous = cds_len_sum == (cds_end0 - cds_start0)
        start_codon = cds_seq[:3] if len(cds_seq) >= 3 else ""
        last_codon = cds_seq[-3:] if len(cds_seq) >= 3 else ""
        stop_in_cds = last_codon in {"TAA", "TAG", "TGA"}
        sense_cds_end0 = cds_end0 - 3 if stop_in_cds else cds_end0
        row = dict(meta)
        row.update(
            transcript_length=len(transcript_seq),
            cds_start0=cds_start0,
            cds_end0=cds_end0,
            sense_cds_end0=sense_cds_end0,
            cds_length=cds_len_sum,
            sense_cds_length=max(0, sense_cds_end0 - cds_start0),
            start_codon=start_codon,
            terminal_codon=last_codon,
            start_is_aug=start_codon == "ATG",
            stop_in_cds=stop_in_cds,
            cds_mod3=(cds_len_sum % 3),
            cds_intervals_contiguous=intervals_contiguous,
            exon_source=exon_source,
            exon_count=len(tx_exons),
        )
        records.append(row)
        seqs[tid] = transcript_seq

    by_gene: dict[str, list[dict]] = defaultdict(list)
    for row in records:
        if row["gene_id"]:
            by_gene[row["gene_id"]].append(row)

    selected: list[dict] = []
    selected_ids: set[str] = set()
    for gene_id, rows in by_gene.items():
        rows.sort(key=lambda r: (-r["cds_length"], -r["transcript_length"], r["transcript_id"]))
        chosen = rows[0]
        selected.append(chosen)
        selected_ids.add(chosen["transcript_id"])
    selected.sort(key=lambda r: (r["gene_id"], r["transcript_id"]))

    fields = [
        "gene_id", "transcript_id", "seqid", "strand", "biotype", "transcript_length",
        "cds_start0", "cds_end0", "sense_cds_end0", "cds_length", "sense_cds_length",
        "start_codon", "terminal_codon", "start_is_aug", "stop_in_cds", "cds_mod3",
        "cds_intervals_contiguous", "exon_source", "exon_count", "description",
    ]
    with open(outdir / "canonical_transcripts.tsv", "w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fieldnames=fields, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(selected)

    all_fields = fields + ["selected", "selection_rank"]
    with open(outdir / "all_transcript_selection.tsv", "w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fieldnames=all_fields, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        for gene_id in sorted(by_gene):
            rows = sorted(by_gene[gene_id], key=lambda r: (-r["cds_length"], -r["transcript_length"], r["transcript_id"]))
            for rank, row in enumerate(rows, 1):
                item = dict(row)
                item["selected"] = row["transcript_id"] in selected_ids
                item["selection_rank"] = rank
                writer.writerow(item)

    with open(outdir / "canonical_transcripts.fasta", "w", encoding="utf-8") as out:
        for row in selected:
            tid = row["transcript_id"]
            seq = seqs[tid]
            out.write(f">{tid}\n")
            for i in range(0, len(seq), 80):
                out.write(seq[i:i+80] + "\n")

    summary = {
        "gff_transcripts": len(tx),
        "transcripts_with_cds": len(records),
        "genes_with_cds": len(by_gene),
        "canonical_transcripts": len(selected),
        "canonical_start_aug": sum(bool(r["start_is_aug"]) for r in selected),
        "canonical_stop_in_cds": sum(bool(r["stop_in_cds"]) for r in selected),
        "canonical_cds_mod3_zero": sum(r["cds_mod3"] == 0 for r in selected),
        "canonical_contiguous_cds": sum(bool(r["cds_intervals_contiguous"]) for r in selected),
        "canonical_exon_fallback": sum(r["exon_source"] != "exon" for r in selected),
    }
    with open(outdir / "reference_summary.tsv", "w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out, delimiter="\t")
        writer.writerow(["metric", "value"])
        writer.writerows(summary.items())


if __name__ == "__main__":
    main()
