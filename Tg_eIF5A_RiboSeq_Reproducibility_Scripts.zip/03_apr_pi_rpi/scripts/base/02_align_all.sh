#!/usr/bin/env bash
set -euo pipefail

run_dir=${1:?run directory required}
bowtie_bin=${BOWTIE_BIN:-$(command -v bowtie)}
samtools_bin=${SAMTOOLS_BIN:-$(command -v samtools)}
threads=${THREADS_PER_ALIGNMENT:-3}
index_prefix="$run_dir/01_reference/canonical_transcripts"
fastq_dir="$run_dir/00_input/fastq"
out_dir="$run_dir/02_alignment"
log_dir="$run_dir/logs"
mkdir -p "$out_dir" "$log_dir"

align_one() {
    local fq=$1
    local sample
    sample=$(basename "$fq" .fastq.gz)
    if [[ -s "$out_dir/$sample.bam" && -s "$out_dir/$sample.all_strands.bam" ]]; then
        return 0
    fi
    gzip -cd "$fq" |
        "$bowtie_bin" -q -S -v 2 -a --best --strata -m 1 -p "$threads" "$index_prefix" - \
        2> "$log_dir/$sample.bowtie.log" |
        "$samtools_bin" view -b -F 4 -o "$out_dir/$sample.all_strands.bam" -
    "$samtools_bin" view -b -F 16 -o "$out_dir/$sample.bam" "$out_dir/$sample.all_strands.bam"
    "$samtools_bin" flagstat "$out_dir/$sample.all_strands.bam" > "$out_dir/$sample.all_strands.flagstat.txt"
    "$samtools_bin" flagstat "$out_dir/$sample.bam" > "$out_dir/$sample.flagstat.txt"
}

export -f align_one
export run_dir bowtie_bin samtools_bin threads index_prefix fastq_dir out_dir log_dir

mapfile -t fastqs < <(find -L "$fastq_dir" -maxdepth 1 -type f -name '*.fastq.gz' | sort)

running=0
for fq in "${fastqs[@]}"; do
    sample=$(basename "$fq" .fastq.gz)
    align_one "$fq" &
    running=$((running + 1))
    if (( running >= 3 )); then
        wait -n
        running=$((running - 1))
    fi
done
wait

printf 'sample\tinput_reads\treads_with_alignment\tsuppressed_multimapper\tunique_all_strands\tsense_plus\tantisense_reverse\n' > "$out_dir/alignment_summary.tsv"
for fq in "${fastqs[@]}"; do
    sample=$(basename "$fq" .fastq.gz)
    input=$(awk '/# reads processed:/{print $4}' "$log_dir/$sample.bowtie.log")
    any=$(awk '/# reads with at least one alignment:/{print $8}' "$log_dir/$sample.bowtie.log")
    suppressed=$(awk '/# reads with alignments suppressed due to -m:/{print $9}' "$log_dir/$sample.bowtie.log")
    all=$($samtools_bin view -c "$out_dir/$sample.all_strands.bam")
    sense=$($samtools_bin view -c "$out_dir/$sample.bam")
    antisense=$((all - sense))
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$sample" "$input" "$any" "$suppressed" "$all" "$sense" "$antisense" >> "$out_dir/alignment_summary.tsv"
done
