#!/usr/bin/env python3

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

TARGETS=["wt_test","R_ctr","R_test","Q_ctr","Q_test"]
XMIN,XMAX=-6.0,8.0; YMIN,YMAX=-6.0,12.0

def plot_coord(v,lo,hi):
    if pd.isna(v): return np.nan,"not_computable"
    if v==0: return lo,"zero_low_boundary"
    if np.isposinf(v): return hi,"positive_inf_high_boundary"
    if v<0: return np.nan,"negative_invalid"
    z=np.log2(v)
    if z<lo: return lo,"finite_clipped_low"
    if z>hi: return hi,"finite_clipped_high"
    return z,"finite_in_range"

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("run_dir"); a=ap.parse_args(); run=Path(a.run_dir).resolve(); inp=run/"00_input_links"
    full=pd.read_csv(run/"02_PI_rPI/gene_level_five_stress_PI_rPI_full.tsv",sep="\t",na_values=["NA"])
    edge=pd.read_csv(run/"03_statistics/edgeR_start_body_five_stress.tsv",sep="\t",na_values=["NA"])
    rna=pd.read_csv(inp/"mRNA_five_contrasts.tsv",sep="\t",na_values=["NA"])
    ref=pd.read_csv(inp/"reference/canonical_transcripts.tsv",sep="\t")
    annot=pd.read_csv(inp/"mrna/gene_count.xls",sep="\t",usecols=["gene_id","gene_name","gene_description","gene_chr","gene_strand","gene_biotype"])
    e=edge[["contrast_id","gene_id","model_relative_logFC","exon_F","PValue","FDR_within_contrast","FDR_global_five_contrasts","transparent_log2_start_body_pc05"]].rename(columns={"PValue":"start_body_PValue","FDR_within_contrast":"start_body_FDR","FDR_global_five_contrasts":"start_body_global_FDR"})
    rn=rna[["contrast_id","gene_id","logFC","PValue","FDR","tested_by_edgeR","FDR_global_across_5contrasts"]].rename(columns={"logFC":"RNA_log2FC","PValue":"RNA_PValue","FDR":"RNA_FDR","FDR_global_across_5contrasts":"RNA_global_FDR"})
    z=full.merge(e,on=["contrast_id","gene_id"],how="left",validate="many_to_one").merge(rn,on=["contrast_id","gene_id"],how="left",validate="many_to_one")
    z=z.merge(ref[["gene_id","description","stop_in_cds","cds_length"]],on="gene_id",how="left").merge(annot,on="gene_id",how="left")
    z["edgeR_positive_FDR05"]=(z.start_body_FDR<.05)&(z.model_relative_logFC>0)
    z["edgeR_negative_FDR05"]=(z.start_body_FDR<.05)&(z.model_relative_logFC<0)
    z["repeat_support_ge_2of3"]=z.direction_support_label.isin(["2/3","3/3"])
    z["strict_PI_rPI_evidence"]=z.pairwise_common_eligible&(z.PI_rPI_evidence_class=="PI_and_rPI")&z.repeat_support_ge_2of3&z.edgeR_positive_FDR05
    z["RNA_no_significant_upregulation"]=~((z.RNA_FDR<.05)&(z.RNA_log2FC>0))
    
    px=[]; py=[]; xs=[]; ys=[]
    for r in z.itertuples(index=False):
        a,aa=plot_coord(r.rPI,XMIN,XMAX); b,bb=plot_coord(r.target_PI_pooled,YMIN,YMAX); px.append(a); xs.append(aa); py.append(b); ys.append(bb)
    z["plot_log2_rPI"]=px; z["rPI_plot_status"]=xs; z["plot_log2_target_PI"]=py; z["PI_plot_status"]=ys
    z["quadrant_point_plotted"]=z.plot_log2_rPI.notna()&z.plot_log2_target_PI.notna()
    z.to_csv(run/"02_PI_rPI/gene_level_five_stress_PI_rPI_with_statistics.tsv",sep="\t",index=False,na_rep="NA")

    
    rows=[]
    for cid,g in z.groupby("contrast_id",sort=False):
        for scope,q in [("all_8140",g),("pairwise_common",g[g.pairwise_common_eligible])]:
            row={"contrast_id":cid,"stress_state":g.stress_state.iloc[0],"scope":scope,"n_rows":len(q),"quadrant_points_plotted":int(q.quadrant_point_plotted.sum()),"not_computable":int((q.PI_rPI_evidence_class=="not_computable").sum())}
            for c in ["PI_and_rPI","PI_only","rPI_only","neither"]: row[c]=int((q.PI_rPI_evidence_class==c).sum())
            row.update({"support_3of3":int((q.direction_support_label=="3/3").sum()),"support_2of3":int((q.direction_support_label=="2/3").sum()),"support_lt2of3":int((q.direction_support_label=="<2/3").sum()),"support_not_computable":int((q.direction_support_label=="not_computable").sum()),"edgeR_positive_FDR05":int(q.edgeR_positive_FDR05.sum()),"edgeR_negative_FDR05":int(q.edgeR_negative_FDR05.sum()),"strict_PI_rPI_evidence":int(q.strict_PI_rPI_evidence.sum())})
            rows.append(row)
    summary=pd.DataFrame(rows); summary.to_csv(run/"03_statistics/PI_rPI_evidence_counts.tsv",sep="\t",index=False)

    
    v=edge.merge(z[["contrast_id","gene_id","PI_rPI_evidence_class","direction_support_label","strict_PI_rPI_evidence","gene_name","description"]],on=["contrast_id","gene_id"],how="left",validate="one_to_one")
    v["volcano_class"]=np.select([v.strict_PI_rPI_evidence,v.FDR_within_contrast.lt(.05)&v.model_relative_logFC.gt(0),v.FDR_within_contrast.lt(.05)&v.model_relative_logFC.lt(0)],["strict_PI_rPI","positive_FDR05","negative_FDR05"],default="not_significant")
    v["minus_log10_P"]=-np.log10(v.PValue.clip(lower=np.nextafter(0,1)))
    v.to_csv(run/"04_figures/source_data/volcano_source_data.tsv",sep="\t",index=False,na_rep="NA")
    z.to_csv(run/"04_figures/source_data/quadrant_source_data.tsv",sep="\t",index=False,na_rep="NA")
    summary.to_csv(run/"04_figures/source_data/evidence_count_source_data.tsv",sep="\t",index=False)

    
    significant=edge.FDR_within_contrast<.05
    direction_concordance=((edge.loc[significant,"model_relative_logFC"]*edge.loc[significant,"transparent_log2_start_body_pc05"])>=0).mean()
    effect_correlation=edge[["model_relative_logFC","transparent_log2_start_body_pc05"]].corr().iloc[0,1]
    audits=[
        ("integrated full rows",len(z)==40700,f"{len(z)}"),
        ("each contrast retains 8140 genes",z.groupby("contrast_id").size().eq(8140).all(),str(z.groupby('contrast_id').size().to_dict())),
        ("edgeR rows equal pairwise-common sizes",all(len(edge[edge.contrast_id==c])==int(summary[(summary.contrast_id==c)&(summary.scope=='pairwise_common')].n_rows.iloc[0]) for c in edge.contrast_id.unique()),f"edgeR={len(edge)}"),
        ("edgeR FDR values valid",edge.FDR_within_contrast.between(0,1).all() and edge.FDR_global_five_contrasts.between(0,1).all(),"all in [0,1]"),
        ("significant model and transparent effect directions concordant",direction_concordance>.99,f"fraction={direction_concordance:.6f}"),
        ("model and transparent effect sizes strongly correlated",effect_correlation>.9,f"correlation={effect_correlation:.6f}"),
        ("not-computable rows excluded only from coordinates",(z.PI_rPI_evidence_class.eq('not_computable')==~z.quadrant_point_plotted).all(),f"not_computable={int(z.PI_rPI_evidence_class.eq('not_computable').sum())}"),
        ("threshold classes exhaustive",z.PI_rPI_evidence_class.isin(["PI_and_rPI","PI_only","rPI_only","neither","not_computable"]).all(),str(z.PI_rPI_evidence_class.value_counts().to_dict())),
    ]
    ad=pd.DataFrame([{"check":a,"status":"PASS" if ok else "FAIL","evidence":ev} for a,ok,ev in audits]); ad.to_csv(run/"01_audit/integration_statistics_audit.tsv",sep="\t",index=False)
    if (ad.status=="FAIL").any(): raise SystemExit("integration audit failed")

if __name__=="__main__": main()
