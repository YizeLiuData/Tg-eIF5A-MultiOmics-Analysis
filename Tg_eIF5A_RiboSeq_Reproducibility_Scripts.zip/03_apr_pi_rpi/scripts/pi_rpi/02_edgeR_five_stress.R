#!/usr/bin/env Rscript
suppressPackageStartupMessages({library(edgeR); library(data.table)})
args <- commandArgs(trailingOnly=TRUE)
if (length(args)!=1L) stop("Usage: 02_edgeR_five_stress.R RUN_DIR")
run <- normalizePath(args[[1]],mustWork=TRUE)
pi <- fread(file.path(run,"02_PI_rPI","per_gene_per_sample_PI_recomputed.tsv"),na.strings=c("NA","Inf","-Inf"))
rpi <- fread(file.path(run,"02_PI_rPI","gene_level_five_stress_PI_rPI_full.tsv"),na.strings=c("NA","Inf","-Inf"))
meta <- fread(file.path(run,"00_manifest","stress_state_metadata.tsv"))
out <- file.path(run,"03_statistics"); dir.create(out,showWarnings=FALSE,recursive=TRUE)

levels <- c("wt_ctr","wt_test","R_ctr","R_test","Q_ctr","Q_test")
meta[,stress_state:=factor(stress_state,levels=levels)]; setorder(meta,stress_state,replicate)
samples <- meta$sample; design <- model.matrix(~0+stress_state,data=meta); colnames(design)<-levels
contrasts <- list(
 wt_test_vs_wt_ctr=c(wt_ctr=-1,wt_test=1,R_ctr=0,R_test=0,Q_ctr=0,Q_test=0),
 R_ctr_vs_wt_ctr=c(wt_ctr=-1,wt_test=0,R_ctr=1,R_test=0,Q_ctr=0,Q_test=0),
 R_test_vs_wt_ctr=c(wt_ctr=-1,wt_test=0,R_ctr=0,R_test=1,Q_ctr=0,Q_test=0),
 Q_ctr_vs_wt_ctr=c(wt_ctr=-1,wt_test=0,R_ctr=0,R_test=0,Q_ctr=1,Q_test=0),
 Q_test_vs_wt_ctr=c(wt_ctr=-1,wt_test=0,R_ctr=0,R_test=0,Q_ctr=0,Q_test=1)
)

model_genes <- unique(rpi[pairwise_common_eligible==TRUE,gene_id])
x <- pi[gene_id %in% model_genes]
sw <- dcast(x,gene_id~sample,value.var="start_codon_psites",fill=0)
bw <- dcast(x,gene_id~sample,value.var="body_psites",fill=0)
setkey(sw,gene_id); setkey(bw,gene_id); genes <- sort(intersect(sw$gene_id,bw$gene_id))
smat <- as.matrix(sw[genes,..samples]); bmat <- as.matrix(bw[genes,..samples]); storage.mode(smat)<-"integer"; storage.mode(bmat)<-"integer"
counts <- matrix(0L,nrow=2L*length(genes),ncol=length(samples)); counts[seq(1,2L*length(genes),2),]<-smat; counts[seq(2,2L*length(genes),2),]<-bmat; colnames(counts)<-samples
ann <- data.frame(gene_id=rep(genes,each=2),feature_id=rep(c("start","body"),length(genes)))
y <- DGEList(counts=counts,genes=ann); y<-calcNormFactors(y); y<-estimateDisp(y,design,robust=TRUE); fit<-glmQLFit(y,design,robust=TRUE)

all <- list()
for (nm in names(contrasts)) {
  state <- sub("_vs_wt_ctr$","",nm); eligible <- rpi[contrast_id==nm & pairwise_common_eligible==TRUE,gene_id]
  ds <- diffSpliceDGE(fit,contrast=contrasts[[nm]],geneid="gene_id",exonid="feature_id",verbose=FALSE)
  ex <- as.data.table(ds$genes); ex[,model_relative_logFC:=as.numeric(ds$coefficients)/log(2)]; ex[,exon_F:=as.numeric(ds$exon.F)]; ex[,PValue:=as.numeric(ds$exon.p.value)]
  z <- ex[feature_id=="start" & gene_id %in% eligible]; z[,contrast_id:=nm]; z[,stress_state:=state]; z[,FDR_within_contrast:=p.adjust(PValue,"BH")]
  tm <- meta[stress_state==state,sample]; cm <- meta[stress_state=="wt_ctr",sample]
  ef <- data.table(gene_id=genes,start_target=rowSums(smat[,tm,drop=FALSE]),start_wt_ctr=rowSums(smat[,cm,drop=FALSE]),body_target=rowSums(bmat[,tm,drop=FALSE]),body_wt_ctr=rowSums(bmat[,cm,drop=FALSE]))
  ef[,transparent_log2_start_body_pc05:=log2(((start_target+.5)/(start_wt_ctr+.5))/((body_target+.5)/(body_wt_ctr+.5)))]
  all[[nm]] <- merge(z,ef,by="gene_id",all.x=TRUE)
}
res <- rbindlist(all,fill=TRUE); res[,FDR_global_five_contrasts:=p.adjust(PValue,"BH")]
setcolorder(res,c("contrast_id","stress_state","gene_id","feature_id")); setorder(res,contrast_id,FDR_within_contrast,-model_relative_logFC)
fwrite(res,file.path(out,"edgeR_start_body_five_stress.tsv"),sep="\t",na="NA")
fwrite(data.table(sample=samples,stress_state=as.character(meta$stress_state),library_size=colSums(counts),norm_factor=y$samples$norm.factors),file.path(out,"edgeR_library_normalization.tsv"),sep="\t")
writeLines(capture.output(sessionInfo()),file.path(out,"R_sessionInfo.txt"))
