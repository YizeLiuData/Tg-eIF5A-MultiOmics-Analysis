#!/usr/bin/env python3


from __future__ import annotations
import argparse, csv, gzip, hashlib, math
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np
import pandas as pd

STATES = ["wt_ctr", "wt_test", "R_ctr", "R_test", "Q_ctr", "Q_test"]
TARGETS = STATES[1:]

def load_counts(path: Path):
    out = defaultdict(Counter)
    with gzip.open(path, "rt", encoding="utf-8") as h:
        for r in csv.DictReader(h, delimiter="\t"):
            out[r["transcript_id"]][int(r["position0"])] = int(r["count"])
    return out

def raw_pi(start, body, ncod):
    if ncod <= 0: return np.nan
    if body == 0: return np.inf if start > 0 else np.nan
    return start * ncod / body

def rpi_value(target, ref):
    if pd.isna(target) or pd.isna(ref): return np.nan, "PI_NA"
    if np.isinf(target) and np.isinf(ref): return np.nan, "Inf_over_Inf"
    if ref == 0:
        if target == 0: return np.nan, "zero_over_zero"
        return np.inf, "positive_over_zero"
    if np.isinf(ref): return 0.0, "finite_over_Inf"
    return target / ref, "finite" if np.isfinite(target) else "Inf_over_finite"

def summary(vals):
    x = pd.Series(vals, dtype=float)
    finite = x[np.isfinite(x)]
    return {
        "mean_finite": finite.mean() if len(finite) else np.nan,
        "median_finite": finite.median() if len(finite) else np.nan,
        "sd_finite": finite.std(ddof=1) if len(finite) > 1 else np.nan,
        "iqr_finite": finite.quantile(.75)-finite.quantile(.25) if len(finite) else np.nan,
        "n_finite": len(finite), "n_inf": int(np.isinf(x).sum()), "n_na": int(x.isna().sum()),
    }

def sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(8*1024*1024),b""): h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("run_dir"); a=ap.parse_args()
    run=Path(a.run_dir).resolve(); inp=run/"00_input_links"; out=run/"02_PI_rPI"; out.mkdir(exist_ok=True)
    sm=pd.read_csv(run/"00_manifest/stress_state_metadata.tsv",sep="\t")
    ref=pd.read_csv(inp/"reference/canonical_transcripts.tsv",sep="\t")
    refs=ref.set_index("transcript_id").to_dict("index")
    samples=sm["sample"].tolist(); state_of=dict(zip(sm["sample"],sm["stress_state"])); rep_of=dict(zip(sm["sample"],sm["replicate"]))

    rows=[]
    for sample in samples:
        counts=load_counts(inp/f"psite/{sample}.psite_counts.tsv.gz")
        for r in ref.itertuples(index=False):
            c=counts.get(r.transcript_id,Counter()); s0=int(r.cds_start0); sense_end=int(r.sense_cds_end0); cds_end=int(r.cds_end0)
            cds=sum(v for p,v in c.items() if s0 <= p < cds_end)
            start=sum(c.get(p,0) for p in range(s0,s0+3))
            body=sum(v for p,v in c.items() if s0+3 <= p < sense_end)
            body_codons=max(0,(sense_end-s0-3)//3)
            body_with_stop=sum(v for p,v in c.items() if s0+3 <= p < cds_end)
            codons_with_stop=max(0,(cds_end-s0-3)//3)
            pi=raw_pi(start,body,body_codons); pi_stop=raw_pi(start,body_with_stop,codons_with_stop)
            rows.append({
                "sample":sample,"stress_state":state_of[sample],"replicate":rep_of[sample],"gene_id":r.gene_id,"transcript_id":r.transcript_id,
                "start_is_aug":bool(r.start_is_aug),"cds_length":int(r.cds_length),"cds_psites":cds,
                "start_codon_psites":start,"body_psites":body,"body_codons":body_codons,"PI":pi,"PI_ge_2":bool(pd.notna(pi) and pi>=2),
                "zero_body_flag":body==0,"eligible_cds_gt3_aug":bool(r.start_is_aug and cds>3),
                "body_with_stop_psites":body_with_stop,"body_with_stop_codons":codons_with_stop,"PI_include_stop":pi_stop,
            })
    per=pd.DataFrame(rows)
    per.to_csv(out/"per_gene_per_sample_PI_recomputed.tsv",sep="\t",index=False,na_rep="NA")

    
    groups={(g,s):z.sort_values("replicate") for (g,s),z in per.groupby(["gene_id","stress_state"],sort=False)}
    full=[]
    for target in TARGETS:
        cid=f"{target}_vs_wt_ctr"
        for rr in ref.itertuples(index=False):
            gene=rr.gene_id; t=groups[(gene,target)]; c=groups[(gene,"wt_ctr")]
            nt=int(t.body_codons.iloc[0]); target_pi=raw_pi(t.start_codon_psites.sum(),t.body_psites.sum(),nt); ctrl_pi=raw_pi(c.start_codon_psites.sum(),c.body_psites.sum(),nt)
            rpi,reason=rpi_value(target_pi,ctrl_pi)
            tvals=pd.to_numeric(t.PI,errors="coerce").to_numpy(); cvals=pd.to_numeric(c.PI,errors="coerce").to_numpy()
            ts=summary(tvals); cs=summary(cvals)
            ctrl_median=np.nanmedian(cvals[np.isfinite(cvals)]) if np.isfinite(cvals).any() else np.nan
            comparable=np.isfinite(tvals) | np.isinf(tvals)
            support=int(np.sum(tvals[comparable] > ctrl_median)) if pd.notna(ctrl_median) else 0
            ncomp=int(comparable.sum()) if pd.notna(ctrl_median) else 0
            support_label=("3/3" if ncomp==3 and support==3 else "2/3" if ncomp==3 and support==2 else "<2/3" if ncomp==3 else "not_computable")
            pi_ge=bool(pd.notna(target_pi) and target_pi>=2); rpi_ge=bool(pd.notna(rpi) and rpi>=2)
            if pd.isna(target_pi) or pd.isna(rpi): evidence="not_computable"
            elif pi_ge and rpi_ge: evidence="PI_and_rPI"
            elif pi_ge: evidence="PI_only"
            elif rpi_ge: evidence="rPI_only"
            else: evidence="neither"
            eligible=bool(t.eligible_cds_gt3_aug.all() and c.eligible_cds_gt3_aug.all())
            row={
                "contrast_id":cid,"stress_state":target,"reference_state":"wt_ctr","gene_id":gene,"transcript_id":rr.transcript_id,
                "start_is_aug":bool(rr.start_is_aug),"pairwise_common_eligible":eligible,"body_codons":nt,
                "target_start_sum":int(t.start_codon_psites.sum()),"target_body_sum":int(t.body_psites.sum()),
                "wt_ctr_start_sum":int(c.start_codon_psites.sum()),"wt_ctr_body_sum":int(c.body_psites.sum()),
                "target_PI_pooled":target_pi,"wt_ctr_PI_pooled":ctrl_pi,"rPI":rpi,"rPI_calculation_reason":reason,
                "target_PI_ge_2":pi_ge,"rPI_ge_2":rpi_ge,"PI_rPI_evidence_class":evidence,
                "target_replicates_above_wt_ctr_median":support,"n_target_PI_comparable":ncomp,"direction_support_label":support_label,
                "low_coverage_flag":not eligible,"target_any_zero_body":bool(t.zero_body_flag.any()),"wt_ctr_any_zero_body":bool(c.zero_body_flag.any()),
                "target_PI_mean_finite":ts["mean_finite"],"target_PI_median_finite":ts["median_finite"],"target_PI_sd_finite":ts["sd_finite"],"target_PI_IQR_finite":ts["iqr_finite"],
                "target_PI_n_finite":ts["n_finite"],"target_PI_n_Inf":ts["n_inf"],"target_PI_n_NA":ts["n_na"],
                "wt_ctr_PI_mean_finite":cs["mean_finite"],"wt_ctr_PI_median_finite":cs["median_finite"],"wt_ctr_PI_sd_finite":cs["sd_finite"],"wt_ctr_PI_IQR_finite":cs["iqr_finite"],
                "wt_ctr_PI_n_finite":cs["n_finite"],"wt_ctr_PI_n_Inf":cs["n_inf"],"wt_ctr_PI_n_NA":cs["n_na"],
            }
            for i,v in enumerate(tvals,1): row[f"target_PI_rep{i}"]=v
            for i,v in enumerate(cvals,1): row[f"wt_ctr_PI_rep{i}"]=v
            
            t_stop=raw_pi(t.start_codon_psites.sum(),t.body_with_stop_psites.sum(),int(t.body_with_stop_codons.iloc[0])); c_stop=raw_pi(c.start_codon_psites.sum(),c.body_with_stop_psites.sum(),int(c.body_with_stop_codons.iloc[0])); rpi_stop,_=rpi_value(t_stop,c_stop)
            row["target_PI_include_stop"]=t_stop; row["wt_ctr_PI_include_stop"]=c_stop; row["rPI_include_stop"]=rpi_stop
            full.append(row)
    full=pd.DataFrame(full)
    full.to_csv(out/"gene_level_five_stress_PI_rPI_full.tsv",sep="\t",index=False,na_rep="NA")

    
    old=pd.read_csv(inp/"upstream_per_gene_per_sample_PI.tsv",sep="\t",na_values=["NA"])
    keys=["sample","gene_id"]
    chk=per.merge(old[keys+["start_codon_psites","body_psites","body_codons","PI"]],on=keys,suffixes=("_new","_old"),validate="one_to_one")
    def same(a,b):
        return (a.isna()&b.isna()) | (np.isinf(a)&np.isinf(b)) | (np.isfinite(a)&np.isfinite(b)&np.isclose(a,b,rtol=1e-9,atol=1e-9))
    pi_same=same(pd.to_numeric(chk.PI_new,errors="coerce"),pd.to_numeric(chk.PI_old,errors="coerce"))
    audit=[
        ("sample PI row count",len(per)==8140*18,f"{len(per)}"),
        ("five-state rPI row count",len(full)==8140*5,f"{len(full)}"),
        ("sample start/body counts match independent upstream implementation",(chk.start_codon_psites_new==chk.start_codon_psites_old).all() and (chk.body_psites_new==chk.body_psites_old).all(),f"rows={len(chk)}"),
        ("sample PI matches independent upstream implementation",bool(pi_same.all()),f"matches={int(pi_same.sum())}/{len(pi_same)}"),
        ("not_computable separated from neither",not ((full.PI_rPI_evidence_class=="neither")&full.rPI.isna()).any(),f"not_computable={(full.PI_rPI_evidence_class=='not_computable').sum()}"),
        ("all five target states represented as rPI contrasts",set(full.stress_state)==set(TARGETS),",".join(sorted(full.stress_state.unique()))),
    ]
    adf=pd.DataFrame([{"check":x,"status":"PASS" if ok else "FAIL","evidence":e} for x,ok,e in audit])
    adf.to_csv(run/"01_audit/PI_rPI_recalculation_audit.tsv",sep="\t",index=False)
    if (adf.status=="FAIL").any(): raise SystemExit("PI/rPI audit failed")

    inputs=[inp/"reference/canonical_transcripts.tsv",inp/"upstream_per_gene_per_sample_PI.tsv"]+[inp/f"psite/{s}.psite_counts.tsv.gz" for s in samples]
    with open(run/"00_manifest/input_checksums.sha256","w") as h:
        for p in inputs: h.write(f"{sha256(p)}  {p.name}\n")

if __name__=="__main__": main()
