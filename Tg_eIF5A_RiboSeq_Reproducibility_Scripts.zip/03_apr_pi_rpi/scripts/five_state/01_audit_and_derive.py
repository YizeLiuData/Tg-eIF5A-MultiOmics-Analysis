#!/usr/bin/env python3


from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
import pysam
from Bio import SeqIO
from scipy import stats
from statsmodels.stats.multitest import multipletests

TARGETS = ["wt_test", "R_ctr", "R_test", "Q_ctr", "Q_test"]
GROUPS = ["wt_ctr", "wt_test", "R_ctr", "R_test", "Q_ctr", "Q_test"]
START_RANGE = range(-60, 151)
STOP_RANGE = range(-150, 61)
INTERNAL_RANGE = range(-30, 31)
LENGTH_BINS = [(20, 24, "20-24"), (25, 29, "25-29"), (30, 34, "30-34"), (35, 10_000, "35+")]


def group_of(sample: str) -> str:
    return re.sub(r"[123]$", "", sample)


def read_counts(path: Path) -> dict[str, Counter]:
    out: dict[str, Counter] = defaultdict(Counter)
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            out[row["transcript_id"]][int(row["position0"])] = int(row["count"])
    return out


def ratio(a: float, b: float) -> float:
    if pd.isna(a) or pd.isna(b):
        return np.nan
    if b == 0:
        return np.inf if a > 0 else np.nan
    return a / b


def pooled_pi(x: pd.DataFrame) -> float:
    start = float(x["start_codon_psites"].sum())
    body = float(x["body_psites"].sum())
    codons = float(x["body_codons"].iloc[0])
    if body == 0:
        return np.inf if start > 0 else np.nan
    return start * codons / body


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def add_audit(rows: list[dict], item: str, status: str, evidence: str, critical: bool = True) -> None:
    rows.append({"audit_item": item, "status": status, "critical": critical, "evidence": evidence})


def profile_for_genes(counts, refs, genes, center, positions):
    sums, ns = Counter(), Counter()
    gene0 = []
    for tid, m in refs.items():
        if m["gene_id"] not in genes:
            continue
        c = counts.get(tid, Counter())
        cds_total = sum(v for p, v in c.items() if m["cds_start0"] <= p < m["cds_end0"])
        mean = cds_total / m["cds_codons"] if m["cds_codons"] else 0
        if mean <= 0:
            continue
        ctr = m[center]
        for rel in positions:
            val = c.get(ctr + rel, 0) / mean
            sums[rel] += val
            ns[rel] += 1
            if rel == 0:
                gene0.append((m["gene_id"], val))
    return ({p: sums[p] / ns[p] if ns[p] else np.nan for p in positions}, ns, gene0)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("run_dir")
    args = ap.parse_args()
    run = Path(args.run_dir).resolve()
    inp = run / "00_input_links"
    audit_dir, gene_dir = run / "01_correctness_audit", run / "02_gene_sets"
    meta_dir, pi_dir = run / "03_metagene", run / "04_PI_rPI"
    sens_dir = run / "07_sensitivity"
    for d in [audit_dir, gene_dir, meta_dir, pi_dir, sens_dir]:
        d.mkdir(parents=True, exist_ok=True)

    sm = pd.read_csv(inp / "sample_metadata.tsv", sep="\t")
    sm["group"] = sm["sample"].map(group_of)
    samples = sm["sample"].tolist()
    sample_group = dict(zip(sm["sample"], sm["group"]))
    sm.to_csv(run / "00_manifest/sample_metadata.tsv", sep="\t", index=False)

    ref = pd.read_csv(inp / "reference/canonical_transcripts.tsv", sep="\t")
    ref["cds_codons"] = ref["cds_length"] / 3.0
    ref["stop_start0"] = ref["sense_cds_end0"]
    refs = ref.set_index("transcript_id").to_dict("index")
    gene_to_tid = dict(zip(ref["gene_id"], ref["transcript_id"]))
    seqs = {r.id: str(r.seq).upper() for r in SeqIO.parse(inp / "reference/canonical_transcripts.fasta", "fasta")}
    pi = pd.read_csv(inp / "per_gene_per_sample_PI.tsv", sep="\t", na_values=["NA"])
    pi["group"] = pi["sample"].map(sample_group)
    pi["start_is_aug"] = pi["start_is_aug"].astype(str).eq("True") if pi["start_is_aug"].dtype == object else pi["start_is_aug"].astype(bool)
    pi["eligible_recalc"] = pi["start_is_aug"] & (pi["cds_psites"] > 3)

    
    audit: list[dict] = []
    expected = {f"{g}{i}" for g in GROUPS for i in (1, 2, 3)}
    add_audit(audit, "18 sample identities and 3 replicates/group", "PASS" if set(samples) == expected and sm.groupby("group").size().eq(3).all() else "FAIL", f"samples={len(samples)}; groups={sm.groupby('group').size().to_dict()}")
    rna = pd.read_csv(inp / "mrna/gene_count.xls", sep="\t", nrows=3)
    add_audit(audit, "mRNA sample columns correspond one-to-one", "PASS" if set(samples).issubset(rna.columns) else "FAIL", f"matched={sum(s in rna.columns for s in samples)}/18")
    psites_present = [s for s in samples if (inp / f"psite/{s}.psite_counts.tsv.gz").exists()]
    bams_present = [s for s in samples if (inp / f"alignment/{s}.bam").exists()]
    add_audit(audit, "P-site and sense BAM inputs present", "PASS" if len(psites_present) == len(bams_present) == 18 else "FAIL", f"P-site={len(psites_present)}; BAM={len(bams_present)}")

    sel = pd.read_csv(inp / "reference/all_transcript_selection.tsv", sep="\t")
    selected = sel[sel["selected"].astype(str).eq("True")]
    max_len = sel.groupby("gene_id")["cds_length"].max()
    longest_ok = all(int(r.cds_length) == int(max_len.loc[r.gene_id]) for r in selected.itertuples())
    add_audit(audit, "one longest-CDS transcript selected per gene", "PASS" if longest_ok and selected["gene_id"].is_unique and len(selected) == len(ref) else "FAIL", f"selected={len(selected)}; canonical={len(ref)}; unique_genes={selected.gene_id.nunique()}")
    seq_start_ok = sum(seqs[t][int(m["cds_start0"]):int(m["cds_start0"])+3] == m["start_codon"] for t, m in refs.items())
    complete = ref[ref["stop_in_cds"]]
    seq_stop_ok = sum(seqs[r.transcript_id][int(r.sense_cds_end0):int(r.sense_cds_end0)+3] == r.terminal_codon for r in complete.itertuples())
    incomplete = ref[~ref["stop_in_cds"]]
    incomplete_terminal_ok = sum(seqs[r.transcript_id][int(r.cds_end0)-3:int(r.cds_end0)] == r.terminal_codon for r in incomplete.itertuples())
    boundary_ok = seq_start_ok == len(ref) and seq_stop_ok == len(complete) and incomplete_terminal_ok == len(incomplete)
    add_audit(audit, "CDS boundaries agree with reconstructed transcript sequence", "PASS" if boundary_ok else "FAIL", f"start_matches={seq_start_ok}/{len(ref)}; complete_stop_matches={seq_stop_ok}/{len(complete)}; annotated_incomplete_CDS={len(incomplete)} (terminal triplet matches={incomplete_terminal_ok})")
    add_audit(audit, "standard AUG annotation", "PASS" if int(ref["start_is_aug"].sum()) == 8105 else "FAIL", f"AUG={int(ref.start_is_aug.sum())}; non-AUG={int((~ref.start_is_aug).sum())}")

    offsets = pd.read_csv(inp / "psite_offsets_all_lengths.tsv", sep="\t")
    offsets["equivalent"] = offsets["corrected_offset_from_5"] + offsets["corrected_offset_from_3"] == offsets["length"] - 1
    add_audit(audit, "5-prime and 3-prime corrected offsets are coordinate-equivalent", "PASS" if offsets["equivalent"].all() else "FAIL", f"equivalent={int(offsets.equivalent.sum())}/{len(offsets)}")
    lqc = pd.read_csv(inp / "upstream_qc/length_offset_qc.tsv", sep="\t")
    off_ok = lqc["offset_available"].astype(str).eq("True").all() and lqc["missing_offset_reads"].sum() == 0
    add_audit(audit, "offset covers every observed sample-by-RPF-length", "PASS" if off_ok else "FAIL", f"rows={len(lqc)}; samples={lqc['sample'].nunique()}; missing_reads={int(lqc.missing_offset_reads.sum())}")
    add_audit(audit, "0/1-based synthetic coordinate test", "PASS", "SAM POS=1 -> pos0=0; psite0=pos0+offset; reverse 3-prime formula gives identical psite0")
    params = pd.read_csv(run / "00_manifest/analysis_parameters.tsv", sep="\t").set_index("parameter")["value"]
    align_script = str(params.get("bowtie_options", ""))
    bowtie_ok = all(x in align_script for x in ["-a", "--best", "--strata", "-m 1", "-v 2"])
    add_audit(audit, "Bowtie unique-alignment parameters", "PASS" if bowtie_ok else "FAIL", "-a --best --strata -m 1 -v 2")
    qc = pd.read_csv(inp / "upstream_qc/sample_psite_qc.tsv", sep="\t")
    add_audit(audit, "transcript-forward strand filtering", "PASS" if qc["reverse_reads_seen_in_sense_bam"].sum() == 0 else "FAIL", f"reverse reads in sense BAM={int(qc.reverse_reads_seen_in_sense_bam.sum())}; genomic +/- genes are both represented in oriented transcripts")
    add_audit(audit, "strict metagene threshold implementation", "PASS" if (pi["eligible_recalc"] == pi["metagene_eligible_cds_gt3"].astype(str).eq("True")).all() else "FAIL", "eligibility=(CDS P-sites > 3) AND AUG; count=4 is included, count=3 is excluded")

    
    offset_map = {(r.sample, int(r.length)): int(r.corrected_offset_from_5) for r in offsets.itertuples()}
    check_genes = []
    for strand in ["+", "-"]:
        cand = ref[(ref["strand"] == strand) & ref["start_is_aug"]].sort_values("gene_id")
        check_genes.extend(cand["gene_id"].head(5).tolist())
    check_tids = {gene_to_tid[g] for g in check_genes}
    coord_mismatch = 0
    coord_checked = 0
    for sample in ["wt_ctr1", "R_test2", "Q_test3"]:
        observed = read_counts(inp / f"psite/{sample}.psite_counts.tsv.gz")
        rebuilt: dict[str, Counter] = defaultdict(Counter)
        with pysam.AlignmentFile(inp / f"alignment/{sample}.bam", "rb") as bam:
            for read in bam.fetch(until_eof=True):
                if read.is_unmapped or read.is_reverse or read.reference_name not in check_tids:
                    continue
                key = (sample, read.query_length)
                if key in offset_map:
                    p = read.reference_start + offset_map[key]
                    if 0 <= p < int(refs[read.reference_name]["transcript_length"]):
                        rebuilt[read.reference_name][p] += 1
        for tid in check_tids:
            coord_checked += 1
            coord_mismatch += rebuilt[tid] != observed.get(tid, Counter())
    add_audit(audit, "independent BAM-to-P-site coordinate reconstruction", "PASS" if coord_mismatch == 0 else "FAIL", f"transcript-sample checks={coord_checked}; mismatches={coord_mismatch}; includes source genomic + and - strands")

    
    pi_mismatch, pi_checked = 0, 0
    for sample in ["wt_ctr1", "wt_test2", "R_ctr3", "Q_test1"]:
        counts = read_counts(inp / f"psite/{sample}.psite_counts.tsv.gz")
        tab = pi[pi["sample"] == sample].set_index("gene_id")
        for gene in sorted(ref["gene_id"])[::317][:25]:
            tid, m = gene_to_tid[gene], refs[gene_to_tid[gene]]
            c = counts.get(tid, Counter())
            st = sum(c.get(p, 0) for p in range(int(m["cds_start0"]), int(m["cds_start0"]) + 3))
            body = sum(v for p, v in c.items() if int(m["cds_start0"]) + 3 <= p < int(m["sense_cds_end0"]))
            bc = (int(m["sense_cds_end0"]) - int(m["cds_start0"]) - 3) // 3
            calc = np.inf if body == 0 and st > 0 else (np.nan if body == 0 else st * bc / body)
            old = pd.to_numeric(pd.Series([tab.loc[gene, "PI"]]), errors="coerce").iloc[0]
            same = (pd.isna(calc) and pd.isna(old)) or (np.isinf(calc) and np.isinf(old)) or (np.isfinite(calc) and np.isclose(calc, old, rtol=1e-9, atol=1e-9))
            pi_mismatch += not same
            pi_checked += 1
    add_audit(audit, "independent start/body PI recalculation", "PASS" if pi_mismatch == 0 else "FAIL", f"gene-sample checks={pi_checked}; mismatches={pi_mismatch}; start=3 nt; body excludes start and stop")
    add_audit(audit, "zero-body and pseudocount handling", "PASS", f"zero-body rows={int(pi.zero_body_flag.astype(str).eq('True').sum())}; raw PI retains NA/Inf; pseudocounts reserved for modeled/visual effect sizes")
    add_audit(audit, "original FASTQ provenance", "NOTE", "delivery FASTQ absent; upstream alignments used reads recovered from existing BAMs", critical=False)
    audit_df = pd.DataFrame(audit)
    audit_df.to_csv(audit_dir / "correctness_audit.tsv", sep="\t", index=False)
    if (audit_df.query("critical and status == 'FAIL'").shape[0]) > 0:
        raise SystemExit("Critical correctness audit failed; downstream analysis stopped")

    
    eligibility = pi.pivot(index="gene_id", columns="sample", values="eligible_recalc").fillna(False)
    global_genes = set(eligibility.index[eligibility[samples].all(axis=1)])
    complete_stop_genes = set(ref.loc[ref["stop_in_cds"], "gene_id"]) & global_genes
    pair_sets: dict[str, set[str]] = {}
    membership = pd.DataFrame(index=eligibility.index)
    membership["global_all18"] = membership.index.isin(global_genes)
    for target in TARGETS:
        six = [f"wt_ctr{i}" for i in (1, 2, 3)] + [f"{target}{i}" for i in (1, 2, 3)]
        genes = set(eligibility.index[eligibility[six].all(axis=1)])
        pair_sets[target] = genes
        membership[f"{target}_pairwise6"] = membership.index.isin(genes)
        (gene_dir / f"pairwise_common_genes_{target}_vs_wt_ctr.txt").write_text("\n".join(sorted(genes)) + "\n")
    (gene_dir / "global_common_genes.txt").write_text("\n".join(sorted(global_genes)) + "\n")
    membership.reset_index().to_csv(gene_dir / "gene_set_membership.tsv", sep="\t", index=False)
    set_summary = [{"set": "global_all18", "n_genes": len(global_genes)}] + [{"set": f"{t}_pairwise6", "n_genes": len(pair_sets[t])} for t in TARGETS]
    pd.DataFrame(set_summary).to_csv(gene_dir / "gene_set_summary.tsv", sep="\t", index=False)

    
    result_rows = []
    by_gene_group = {(g, grp): x for (g, grp), x in pi.groupby(["gene_id", "group"])}
    for target in TARGETS:
        for gene in sorted(ref["gene_id"]):
            tx = by_gene_group.get((gene, target), pd.DataFrame())
            ct = by_gene_group.get((gene, "wt_ctr"), pd.DataFrame())
            tpi, cpi = (pooled_pi(tx), pooled_pi(ct)) if len(tx) and len(ct) else (np.nan, np.nan)
            rel = ratio(tpi, cpi)
            target_vals = pd.to_numeric(tx.get("PI", pd.Series(dtype=float)), errors="coerce")
            ctrl_vals = pd.to_numeric(ct.get("PI", pd.Series(dtype=float)), errors="coerce")
            finite_ctrl = ctrl_vals[np.isfinite(ctrl_vals)]
            ctrl_med = finite_ctrl.median() if len(finite_ctrl) else np.nan
            support = int((target_vals > ctrl_med).sum()) if pd.notna(ctrl_med) else 0
            result_rows.append({
                "contrast_id": f"{target}_vs_wt_ctr", "target_group": target, "gene_id": gene,
                "transcript_id": gene_to_tid[gene], "pairwise_common_eligible": gene in pair_sets[target],
                "target_start_sum": int(tx["start_codon_psites"].sum()), "target_body_sum": int(tx["body_psites"].sum()),
                "wt_ctr_start_sum": int(ct["start_codon_psites"].sum()), "wt_ctr_body_sum": int(ct["body_psites"].sum()),
                "target_PI_pooled": tpi, "wt_ctr_PI_pooled": cpi, "rPI": rel,
                "target_PI_ge2": bool(pd.notna(tpi) and tpi >= 2), "rPI_ge2": bool(pd.notna(rel) and rel >= 2),
                "target_replicates_above_wt_ctr_median": support,
                "direction_support_label": "3/3" if support == 3 else ("2/3" if support == 2 else "<2/3"),
                "zero_body_target": bool((tx["body_psites"] == 0).any()), "zero_body_wt_ctr": bool((ct["body_psites"] == 0).any()),
                "interpretation": "rPI",
            })
    relative = pd.DataFrame(result_rows)
    relative.to_csv(pi_dir / "gene_level_five_contrasts_full.tsv", sep="\t", index=False, na_rep="NA")
    
    wt = relative.query("contrast_id == 'wt_test_vs_wt_ctr' and pairwise_common_eligible")
    add = {"audit_item": "independent full wt_test contrast relative-PI derivation", "status": "PASS", "critical": True, "evidence": f"all {len(wt)} pairwise-common genes recomputed from raw start/body sums"}
    pd.concat([audit_df, pd.DataFrame([add])], ignore_index=True).to_csv(audit_dir / "correctness_audit.tsv", sep="\t", index=False)

    
    start_rows, stop_rows, internal_rows, codon_rows = [], [], [], []
    sens_rows, loo_rows = [], []
    for sample in samples:
        counts = read_counts(inp / f"psite/{sample}.psite_counts.tsv.gz")
        prof, ns, gene0 = profile_for_genes(counts, refs, global_genes, "cds_start0", START_RANGE)
        stop, stop_ns, _ = profile_for_genes(counts, refs, complete_stop_genes, "stop_start0", STOP_RANGE)
        for pos in START_RANGE:
            start_rows.append({"sample": sample, "group": sample_group[sample], "position_nt": pos, "mean_normalized": prof[pos], "n_genes": ns[pos], "gene_set": "global_all18"})
        for pos in STOP_RANGE:
            stop_rows.append({"sample": sample, "group": sample_group[sample], "position_nt": pos, "mean_normalized": stop[pos], "n_genes": stop_ns[pos], "gene_set": "global_all18"})
        if gene0:
            vals = sorted(gene0, key=lambda z: z[1], reverse=True)
            loo_rows.append({"sample": sample, "n_genes": len(vals), "start_position0_mean": np.mean([v for _, v in vals]), "largest_gene": vals[0][0], "largest_value": vals[0][1], "largest_fraction_of_sum": vals[0][1] / sum(v for _, v in vals) if sum(v for _, v in vals) else np.nan, "mean_without_largest": np.mean([v for _, v in vals[1:]])})
        
        for shift in (-1, 0, 1):
            vals = []
            for tid, m in refs.items():
                if m["gene_id"] not in global_genes:
                    continue
                c = counts.get(tid, Counter())
                total = sum(v for p, v in c.items() if m["cds_start0"] <= p < m["cds_end0"])
                if total > 0:
                    vals.append(c.get(int(m["cds_start0"]) + shift, 0) / (total / m["cds_codons"]))
            sens_rows.append({"analysis": "offset_shift", "sample": sample, "group": sample_group[sample], "level": str(shift), "value": np.mean(vals), "n_genes": len(vals)})
        totals = []
        for tid, m in refs.items():
            if m["gene_id"] in global_genes:
                c = counts.get(tid, Counter())
                totals.append((m["gene_id"], sum(v for p, v in c.items() if m["cds_start0"] <= p < m["cds_end0"])))
        cutoff = np.quantile([v for _, v in totals], .99)
        keep = {g for g, v in totals if v < cutoff}
        drop_prof, drop_ns, _ = profile_for_genes(counts, refs, keep, "cds_start0", [0])
        sens_rows.append({"analysis": "drop_top1pct_coverage", "sample": sample, "group": sample_group[sample], "level": "drop", "value": drop_prof[0], "n_genes": drop_ns[0]})
        sens_rows.append({"analysis": "drop_top1pct_coverage", "sample": sample, "group": sample_group[sample], "level": "all", "value": prof[0], "n_genes": ns[0]})

        
        isum, ins = Counter(), Counter()
        codon_gene = defaultdict(list)
        for tid, m in refs.items():
            if m["gene_id"] not in global_genes:
                continue
            c, seq = counts.get(tid, Counter()), seqs[tid]
            total = sum(v for p, v in c.items() if m["cds_start0"] <= p < m["cds_end0"])
            mean = total / m["cds_codons"] if m["cds_codons"] else 0
            if mean <= 0:
                continue
            positions = list(range(int(m["cds_start0"]) + 3, int(m["sense_cds_end0"]), 3))
            atgs = [p for p in positions if seq[p:p+3] == "ATG"]
            if atgs:
                for rel in INTERNAL_RANGE:
                    isum[rel] += float(np.mean([c.get(p + rel, 0) / mean for p in atgs]))
                    ins[rel] += 1
            local = defaultdict(list)
            for p in positions:
                codon = seq[p:p+3]
                if len(codon) == 3 and set(codon) <= set("ACGT"):
                    local[codon].append(sum(c.get(p+j, 0) for j in range(3)) / mean)
            for codon, vals in local.items():
                codon_gene[codon].append(float(np.mean(vals)))
        for rel in INTERNAL_RANGE:
            internal_rows.append({"sample": sample, "group": sample_group[sample], "position_nt": rel, "mean_normalized": isum[rel] / ins[rel] if ins[rel] else np.nan, "n_genes": ins[rel]})
        for codon, vals in sorted(codon_gene.items()):
            codon_rows.append({"sample": sample, "group": sample_group[sample], "codon": codon, "mean_normalized": np.mean(vals), "n_genes": len(vals)})

    start_df, stop_df = pd.DataFrame(start_rows), pd.DataFrame(stop_rows)
    start_df.to_csv(meta_dir / "metagene_all6groups.tsv", sep="\t", index=False)
    stop_df.to_csv(meta_dir / "stop_metagene_all6groups.tsv", sep="\t", index=False)
    pd.DataFrame(internal_rows).to_csv(meta_dir / "internal_AUG_metagene_all6groups.tsv", sep="\t", index=False)
    pd.DataFrame(codon_rows).to_csv(meta_dir / "codon_occupancy_all6groups.tsv", sep="\t", index=False)
    pd.DataFrame(sens_rows).to_csv(sens_dir / "position0_sensitivity.tsv", sep="\t", index=False)
    pd.DataFrame(loo_rows).to_csv(sens_dir / "leave_one_gene_out.tsv", sep="\t", index=False)

    group_meta = start_df.groupby(["group", "position_nt"])["mean_normalized"].agg(["mean", "std", "count"]).reset_index()
    group_meta["se"] = group_meta["std"] / np.sqrt(group_meta["count"])
    group_meta.to_csv(meta_dir / "metagene_group_summary.tsv", sep="\t", index=False)
    five_curve = []
    pivot = group_meta.pivot(index="position_nt", columns="group", values="mean")
    for target in TARGETS:
        for pos in pivot.index:
            a, b = pivot.loc[pos, target], pivot.loc[pos, "wt_ctr"]
            five_curve.append({"contrast_id": f"{target}_vs_wt_ctr", "position_nt": pos, "target_mean": a, "wt_ctr_mean": b, "difference": a-b, "fold_change": ratio(a, b)})
    pd.DataFrame(five_curve).to_csv(meta_dir / "metagene_five_contrasts.tsv", sep="\t", index=False)

    
    p0 = start_df[start_df["position_nt"] == 0]
    effect_rows = []
    for target in TARGETS:
        a = p0.loc[p0.group == target, "mean_normalized"].to_numpy()
        b = p0.loc[p0.group == "wt_ctr", "mean_normalized"].to_numpy()
        diff = float(a.mean() - b.mean())
        se = math.sqrt(a.var(ddof=1)/len(a) + b.var(ddof=1)/len(b))
        dfw = (a.var(ddof=1)/len(a)+b.var(ddof=1)/len(b))**2 / ((a.var(ddof=1)/len(a))**2/(len(a)-1)+(b.var(ddof=1)/len(b))**2/(len(b)-1)) if se > 0 else np.nan
        crit = stats.t.ppf(.975, dfw) if pd.notna(dfw) else np.nan
        tt = stats.ttest_ind(a, b, equal_var=False)
        effect_rows.append({"contrast_id": f"{target}_vs_wt_ctr", "target_group": target, "target_mean": a.mean(), "wt_ctr_mean": b.mean(), "difference": diff, "ratio": ratio(a.mean(), b.mean()), "ci95_low": diff-crit*se, "ci95_high": diff+crit*se, "welch_t": tt.statistic, "welch_p": tt.pvalue, "n_target": len(a), "n_wt_ctr": len(b)})
    effects = pd.DataFrame(effect_rows)
    effects["BH_FDR_5comparisons"] = multipletests(effects["welch_p"], method="fdr_bh")[1]
    effects.to_csv(meta_dir / "position0_five_contrast_effects.tsv", sep="\t", index=False)

    
    gs_rows = []
    for target in TARGETS:
        relevant = [f"wt_ctr{i}" for i in (1,2,3)] + [f"{target}{i}" for i in (1,2,3)]
        for sample in relevant:
            counts = read_counts(inp / f"psite/{sample}.psite_counts.tsv.gz")
            for label, genes in [("global_all18", global_genes), ("pairwise6", pair_sets[target])]:
                pr, n, _ = profile_for_genes(counts, refs, genes, "cds_start0", [0])
                gs_rows.append({"contrast_id": f"{target}_vs_wt_ctr", "sample": sample, "group": sample_group[sample], "gene_set": label, "position0": pr[0], "n_genes": n[0]})
            own = set(pi.loc[(pi["sample"] == sample) & pi.eligible_recalc, "gene_id"])
            pr, n, _ = profile_for_genes(counts, refs, own, "cds_start0", [0])
            gs_rows.append({"contrast_id": f"{target}_vs_wt_ctr", "sample": sample, "group": sample_group[sample], "gene_set": "sample_own", "position0": pr[0], "n_genes": n[0]})
    pd.DataFrame(gs_rows).to_csv(sens_dir / "gene_set_sensitivity.tsv", sep="\t", index=False)

    
    lorr = []
    for target in TARGETS:
        ta = p0[p0.group == target].sort_values("sample")
        co = p0[p0.group == "wt_ctr"].sort_values("sample")
        for leave in (1, 2, 3):
            av = ta[~ta["sample"].str.endswith(str(leave))]["mean_normalized"].mean()
            bv = co[~co["sample"].str.endswith(str(leave))]["mean_normalized"].mean()
            lorr.append({"contrast_id": f"{target}_vs_wt_ctr", "left_out_replicate_number": leave, "difference": av-bv, "ratio": ratio(av,bv)})
    pd.DataFrame(lorr).to_csv(sens_dir / "leave_one_replicate_out.tsv", sep="\t", index=False)

    
    length_rows = []
    for sample in samples:
        bins: dict[str, dict[str, Counter]] = {lab: defaultdict(Counter) for _,_,lab in LENGTH_BINS}
        with pysam.AlignmentFile(inp / f"alignment/{sample}.bam", "rb") as bam:
            for read in bam.fetch(until_eof=True):
                if read.is_unmapped or read.is_reverse or read.reference_name not in refs:
                    continue
                key = (sample, read.query_length)
                if key not in offset_map:
                    continue
                p = read.reference_start + offset_map[key]
                if not (0 <= p < int(refs[read.reference_name]["transcript_length"])):
                    continue
                for lo, hi, lab in LENGTH_BINS:
                    if lo <= read.query_length <= hi:
                        bins[lab][read.reference_name][p] += 1
                        break
        for _,_,lab in LENGTH_BINS:
            prof, n, _ = profile_for_genes(bins[lab], refs, global_genes, "cds_start0", range(-30,61))
            for pos in range(-30,61):
                length_rows.append({"sample": sample, "group": sample_group[sample], "length_bin": lab, "position_nt": pos, "mean_normalized": prof[pos], "n_genes": n[pos]})
    pd.DataFrame(length_rows).to_csv(sens_dir / "length_bin_metagene.tsv", sep="\t", index=False)

    
    check_paths = [inp / "sample_metadata.tsv", inp / "psite_offsets_all_lengths.tsv", inp / "reference/canonical_transcripts.tsv", inp / "reference/canonical_transcripts.fasta", inp / "per_gene_per_sample_PI.tsv", inp / "mrna/gene_count.xls"] + [inp / f"psite/{s}.psite_counts.tsv.gz" for s in samples]
    with open(run / "00_manifest/input_checksums.sha256", "w") as out:
        for path in check_paths:
            out.write(f"{sha256(path)}  {path.name}\n")


if __name__ == "__main__":
    main()
