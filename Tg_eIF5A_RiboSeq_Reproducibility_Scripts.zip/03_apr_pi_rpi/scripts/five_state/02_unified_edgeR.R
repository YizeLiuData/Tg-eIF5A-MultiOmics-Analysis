#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(edgeR)
  library(data.table)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Usage: 02_unified_edgeR.R RUN_DIR")
run_dir <- normalizePath(args[[1]], mustWork = TRUE)
pi <- fread(file.path(run_dir, "00_input_links", "per_gene_per_sample_PI.tsv"), na.strings = c("NA", "Inf", "-Inf"))
meta <- fread(file.path(run_dir, "00_manifest", "sample_metadata.tsv"))
rna <- fread(file.path(run_dir, "00_input_links", "mrna", "gene_count.xls"))
membership <- fread(file.path(run_dir, "02_gene_sets", "gene_set_membership.tsv"))
out_start <- file.path(run_dir, "05_statistics")
out_rna <- file.path(run_dir, "06_RNA_integration")
dir.create(out_start, recursive = TRUE, showWarnings = FALSE)
dir.create(out_rna, recursive = TRUE, showWarnings = FALSE)

group_levels <- c("wt_ctr", "wt_test", "R_ctr", "R_test", "Q_ctr", "Q_test")
meta[, group := factor(group, levels = group_levels)]
setorder(meta, group, replicate)
sample_order <- meta$sample
design <- model.matrix(~ 0 + group, data = meta)
colnames(design) <- group_levels

contrast_defs <- list(
  wt_test_vs_wt_ctr = c(wt_ctr=-1, wt_test=1, R_ctr=0, R_test=0, Q_ctr=0, Q_test=0),
  R_ctr_vs_wt_ctr   = c(wt_ctr=-1, wt_test=0, R_ctr=1, R_test=0, Q_ctr=0, Q_test=0),
  R_test_vs_wt_ctr  = c(wt_ctr=-1, wt_test=0, R_ctr=0, R_test=1, Q_ctr=0, Q_test=0),
  Q_ctr_vs_wt_ctr   = c(wt_ctr=-1, wt_test=0, R_ctr=0, R_test=0, Q_ctr=1, Q_test=0),
  Q_test_vs_wt_ctr  = c(wt_ctr=-1, wt_test=0, R_ctr=0, R_test=0, Q_ctr=0, Q_test=1)
)
interaction_defs <- list(
  R_interaction = c(wt_ctr=1, wt_test=-1, R_ctr=-1, R_test=1, Q_ctr=0, Q_test=0),
  Q_interaction = c(wt_ctr=1, wt_test=-1, R_ctr=0, R_test=0, Q_ctr=-1, Q_test=1)
)

pair_cols <- grep("_pairwise6$", names(membership), value = TRUE)
model_genes <- membership[rowSums(as.matrix(membership[, ..pair_cols])) > 0, gene_id]
x <- pi[gene_id %in% model_genes]
start_wide <- dcast(x, gene_id ~ sample, value.var = "start_codon_psites", fill = 0)
body_wide <- dcast(x, gene_id ~ sample, value.var = "body_psites", fill = 0)
setkey(start_wide, gene_id); setkey(body_wide, gene_id)
genes <- sort(intersect(start_wide$gene_id, body_wide$gene_id))
start_mat <- as.matrix(start_wide[genes, ..sample_order])
body_mat <- as.matrix(body_wide[genes, ..sample_order])
storage.mode(start_mat) <- "integer"; storage.mode(body_mat) <- "integer"
counts <- matrix(0L, nrow = 2L * length(genes), ncol = length(sample_order))
counts[seq(1L, 2L * length(genes), by = 2L), ] <- start_mat
counts[seq(2L, 2L * length(genes), by = 2L), ] <- body_mat
colnames(counts) <- sample_order
annotation <- data.frame(gene_id = rep(genes, each=2L), feature_id = rep(c("start", "body"), length(genes)))
y <- DGEList(counts = counts, genes = annotation)
y <- calcNormFactors(y)
y <- estimateDisp(y, design, robust = TRUE)
fit <- glmQLFit(y, design, robust = TRUE)

get_usage <- function(contrast_name, contrast_vector, eligible_genes) {
  ds <- diffSpliceDGE(fit, contrast = contrast_vector, geneid = "gene_id", exonid = "feature_id", verbose = FALSE)
  ex <- as.data.table(ds$genes)
  ex[, model_relative_logFC := as.numeric(ds$coefficients) / log(2)]
  ex[, exon_F := as.numeric(ds$exon.F)]
  ex[, PValue := as.numeric(ds$exon.p.value)]
  ans <- ex[feature_id == "start" & gene_id %in% eligible_genes]
  ans[, contrast_id := contrast_name]
  ans[, FDR_within_contrast := p.adjust(PValue, method = "BH")]
  ans
}

usage_list <- list()
for (nm in names(contrast_defs)) {
  col <- paste0(sub("_vs_wt_ctr$", "", nm), "_pairwise6")
  eligible <- membership[get(col) == TRUE, gene_id]
  z <- get_usage(nm, contrast_defs[[nm]], eligible)
  target <- sub("_vs_wt_ctr$", "", nm)
  tm <- meta[group == target]
  cm <- meta[group == "wt_ctr"]
  eff <- data.table(
    gene_id = genes,
    start_target = rowSums(start_mat[, tm$sample, drop=FALSE]),
    start_wt_ctr = rowSums(start_mat[, cm$sample, drop=FALSE]),
    body_target = rowSums(body_mat[, tm$sample, drop=FALSE]),
    body_wt_ctr = rowSums(body_mat[, cm$sample, drop=FALSE])
  )
  eff[, log2_start_body_interaction_pc05 := log2(((start_target+0.5)/(start_wt_ctr+0.5))/((body_target+0.5)/(body_wt_ctr+0.5)))]
  z <- merge(z, eff, by="gene_id", all.x=TRUE)
  usage_list[[nm]] <- z
}
usage <- rbindlist(usage_list, fill=TRUE)
usage[, FDR_global_across_5contrasts := p.adjust(PValue, method="BH")]
setcolorder(usage, c("contrast_id", "gene_id", "feature_id"))
setorder(usage, contrast_id, FDR_within_contrast, -log2_start_body_interaction_pc05)
fwrite(usage, file.path(out_start, "edgeR_start_usage_five_contrasts.tsv"), sep="\t", na="NA")

inter_list <- list()
for (nm in names(interaction_defs)) {
  grps <- if (nm == "R_interaction") c("wt_ctr","wt_test","R_ctr","R_test") else c("wt_ctr","wt_test","Q_ctr","Q_test")
  ss <- meta[group %in% grps, sample]
  eligible <- pi[sample %in% ss, .(ok=all(metagene_eligible_cds_gt3 == TRUE & start_is_aug == TRUE)), by=gene_id][ok == TRUE, gene_id]
  z <- get_usage(nm, interaction_defs[[nm]], eligible)
  inter_list[[nm]] <- z
}
interactions <- rbindlist(inter_list, fill=TRUE)
interactions[, FDR_global_across_2interactions := p.adjust(PValue, method="BH")]
setorder(interactions, contrast_id, FDR_within_contrast)
fwrite(interactions, file.path(out_start, "edgeR_start_usage_interactions.tsv"), sep="\t", na="NA")

rna_counts <- as.matrix(rna[, ..sample_order])
rownames(rna_counts) <- rna$gene_id
storage.mode(rna_counts) <- "integer"
ry <- DGEList(counts = rna_counts)
keep <- filterByExpr(ry, design = design)
ryf <- ry[keep, , keep.lib.sizes=FALSE]
ryf <- calcNormFactors(ryf)
ryf <- estimateDisp(ryf, design, robust=TRUE)
rfit <- glmQLFit(ryf, design, robust=TRUE)

rna_test <- function(nm, vec) {
  tst <- glmQLFTest(rfit, contrast=vec)
  tab <- as.data.table(topTags(tst, n=Inf, sort.by="none")$table, keep.rownames="gene_id")
  tab[, tested_by_edgeR := TRUE]
  ans <- merge(data.table(gene_id=rna$gene_id), tab, by="gene_id", all.x=TRUE)
  ans[is.na(tested_by_edgeR), tested_by_edgeR := FALSE]
  ans[, contrast_id := nm]
  ans
}
rna_main <- rbindlist(lapply(names(contrast_defs), function(nm) rna_test(nm, contrast_defs[[nm]])), fill=TRUE)
rna_main[, FDR_global_across_5contrasts := p.adjust(PValue, method="BH")]
setcolorder(rna_main, c("contrast_id","gene_id"))
fwrite(rna_main, file.path(out_rna, "mRNA_five_contrasts.tsv"), sep="\t", na="NA")
rna_inter <- rbindlist(lapply(names(interaction_defs), function(nm) rna_test(nm, interaction_defs[[nm]])), fill=TRUE)
rna_inter[, FDR_global_across_2interactions := p.adjust(PValue, method="BH")]
setcolorder(rna_inter, c("contrast_id","gene_id"))
fwrite(rna_inter, file.path(out_rna, "mRNA_interactions.tsv"), sep="\t", na="NA")

writeLines(capture.output(sessionInfo()), file.path(out_start, "R_sessionInfo.txt"))
fwrite(data.table(sample=sample_order, group=as.character(meta$group), library_size=colSums(counts), norm_factor=y$samples$norm.factors), file.path(out_start, "edgeR_library_normalization.tsv"), sep="\t")
