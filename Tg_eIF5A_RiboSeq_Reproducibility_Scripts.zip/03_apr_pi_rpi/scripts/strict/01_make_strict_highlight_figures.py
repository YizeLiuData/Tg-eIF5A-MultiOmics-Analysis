#!/usr/bin/env python3


from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


TARGETS = ["wt_test", "R_ctr", "R_test", "Q_ctr", "Q_test"]
LABEL = {
    "wt_test": "WT-test",
    "R_ctr": "R-CTR",
    "R_test": "R-test",
    "Q_ctr": "Q-CTR",
    "Q_test": "Q-test",
}
STATE_COLOR = {
    "wt_test": "#3775BA",
    "R_ctr": "#62BFAE",
    "R_test": "#087E75",
    "Q_ctr": "#E3A64F",
    "Q_test": "#B64342",
}
OTHER_COLOR = "#505050"
EXPECTED_STRICT = {"wt_test": 320, "R_ctr": 1, "R_test": 418, "Q_ctr": 807, "Q_test": 232}

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 7,
        "axes.linewidth": 0.7,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "legend.frameon": False,
    }
)


def panel(ax: plt.Axes, label: str) -> None:
    ax.text(-0.12, 1.05, label, transform=ax.transAxes, fontweight="bold", fontsize=10, va="bottom")


def save_figure(fig: plt.Figure, base: Path) -> None:
    base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(base.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(base.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(base.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(
        base.with_suffix(".tiff"),
        dpi=600,
        bbox_inches="tight",
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(fig)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def percent_text(numerator: int, denominator: int) -> str:
    value = 100.0 * numerator / denominator if denominator else np.nan
    if value > 0 and value < 0.1:
        return "<0.1%"
    return f"{value:.1f}%"


def point_marker(rpi_status: str, pi_status: str) -> str:
    low_x = "low" in rpi_status
    high_x = "high" in rpi_status
    low_y = "low" in pi_status
    high_y = "high" in pi_status
    if (low_x or high_x) and (low_y or high_y):
        return "D"
    if low_x:
        return "<"
    if high_x:
        return ">"
    if low_y:
        return "v"
    if high_y:
        return "^"
    return "o"


def draw_quadrant_points(
    ax: plt.Axes,
    frame: pd.DataFrame,
    color: str,
    size: float,
    alpha: float,
    strict: bool,
) -> None:
    if frame.empty:
        return
    marks = frame.apply(lambda row: point_marker(row["rPI_plot_status"], row["PI_plot_status"]), axis=1)
    for marker, subset in frame.assign(_marker=marks).groupby("_marker", sort=False):
        ax.scatter(
            subset["plot_log2_rPI"],
            subset["plot_log2_target_PI"],
            s=size,
            marker=marker,
            facecolors=color,
            edgecolors="black" if strict else "none",
            linewidths=0.45 if strict else 0,
            alpha=alpha,
            rasterized=True,
            zorder=4 if strict else 1,
        )


def prepare_source_data(run: Path, volcano: pd.DataFrame, genes: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    volcano = volcano.copy()
    volcano["display_class"] = np.where(volcano["strict_PI_rPI_evidence"], "strict", "other")
    volcano["display_color"] = volcano["stress_state"].map(STATE_COLOR).where(
        volcano["strict_PI_rPI_evidence"], OTHER_COLOR
    )

    genes = genes.copy()
    eligible = genes["pairwise_common_eligible"]
    plotted = genes["quadrant_point_plotted"]
    genes["display_class"] = np.select(
        [eligible & genes["strict_PI_rPI_evidence"], eligible & plotted],
        ["strict", "other"],
        default="not_plotted",
    )
    genes["display_reason"] = np.select(
        [~eligible, eligible & ~plotted, eligible & genes["strict_PI_rPI_evidence"]],
        ["not_in_pairwise_common_set", "PI_or_rPI_not_computable", "strict_evidence"],
        default="other_plotted_gene",
    )
    genes["display_color"] = genes["stress_state"].map(STATE_COLOR).where(
        genes["display_class"].eq("strict"), OTHER_COLOR
    )

    summary_rows = []
    for state in TARGETS:
        current = genes[(genes["stress_state"] == state) & genes["pairwise_common_eligible"]]
        strict_n = int(current["strict_PI_rPI_evidence"].sum())
        summary_rows.append(
            {
                "contrast_id": f"{state}_vs_wt_ctr",
                "stress_state": state,
                "state_label": LABEL[state],
                "pairwise_common_genes": len(current),
                "strict_evidence_genes": strict_n,
                "other_genes": len(current) - strict_n,
                "strict_percent": 100.0 * strict_n / len(current),
                "quadrant_points_plotted": int(current["quadrant_point_plotted"].sum()),
                "quadrant_not_computable": int((~current["quadrant_point_plotted"]).sum()),
            }
        )
    summary = pd.DataFrame(summary_rows)

    source_dir = run / "02_figures/source_data"
    volcano.to_csv(source_dir / "strict_highlight_volcano_source_data.tsv", sep="\t", index=False, na_rep="NA")
    genes.to_csv(source_dir / "strict_highlight_quadrant_source_data.tsv", sep="\t", index=False, na_rep="NA")
    summary.to_csv(source_dir / "strict_highlight_summary_source_data.tsv", sep="\t", index=False)
    return volcano, genes, summary


def make_volcano(run: Path, volcano: pd.DataFrame, summary: pd.DataFrame) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 5.4), sharex=True, sharey=True)
    axes = axes.flat
    xmax = max(6, np.ceil(np.nanquantile(np.abs(volcano["model_relative_logFC"]), 0.998)))
    ymax = max(8, np.ceil(np.nanquantile(volcano["minus_log10_P"], 0.998)))

    for index, state in enumerate(TARGETS):
        ax = axes[index]
        contrast = f"{state}_vs_wt_ctr"
        current = volcano[volcano["contrast_id"] == contrast]
        other = current[~current["strict_PI_rPI_evidence"]]
        strict = current[current["strict_PI_rPI_evidence"]]

        ax.scatter(
            other["model_relative_logFC"].clip(-xmax, xmax),
            other["minus_log10_P"].clip(0, ymax),
            s=4,
            c=OTHER_COLOR,
            alpha=0.23,
            edgecolors="none",
            rasterized=True,
            zorder=1,
        )
        ax.scatter(
            strict["model_relative_logFC"].clip(-xmax, xmax),
            strict["minus_log10_P"].clip(0, ymax),
            s=15,
            c=STATE_COLOR[state],
            alpha=0.92,
            edgecolors="black",
            linewidths=0.4,
            rasterized=True,
            zorder=4,
        )
        ax.axvline(0, color="#777777", lw=0.6, zorder=0)
        ax.set_xlim(-xmax, xmax)
        ax.set_ylim(0, ymax)
        ax.set_title(LABEL[state], color=STATE_COLOR[state], fontweight="bold")
        ax.set_xlabel("Start/body effect (log2)")
        ax.set_ylabel("−log10 P")

        stats = summary[summary["stress_state"] == state].iloc[0]
        ax.text(
            0.03,
            0.97,
            f"tested n={len(current):,}\nstrict={int(stats.strict_evidence_genes):,} ({percent_text(int(stats.strict_evidence_genes), len(current))})",
            transform=ax.transAxes,
            va="top",
            fontsize=5.5,
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.78, pad=1),
            zorder=6,
        )

        labels = strict.sort_values(["FDR_within_contrast", "model_relative_logFC"], ascending=[True, False]).head(3)
        for rank, row in enumerate(labels.itertuples()):
            name = row.gene_name if isinstance(row.gene_name, str) and row.gene_name not in ("", "-") else row.gene_id
            ax.annotate(
                name,
                (np.clip(row.model_relative_logFC, -xmax, xmax), np.clip(row.minus_log10_P, 0, ymax)),
                xytext=(0.52, 0.90 - 0.095 * rank),
                textcoords=ax.transAxes,
                fontsize=5,
                color="#202020",
                ha="left",
                va="center",
                bbox=dict(facecolor="white", edgecolor="none", alpha=0.72, pad=0.5),
                arrowprops=dict(arrowstyle="-", color="#777777", lw=0.35, shrinkA=1, shrinkB=1),
                zorder=7,
            )
        if index == 0:
            panel(ax, "a")

    axes[5].axis("off")
    handles = [
        plt.Line2D([], [], marker="o", ls="", markerfacecolor=OTHER_COLOR, markeredgecolor="none", alpha=0.45, label="Other tested genes"),
        plt.Line2D([], [], marker="o", ls="", markerfacecolor="white", markeredgecolor="black", label="Strict evidence\n(state colour)"),
    ]
    axes[5].legend(handles=handles, loc="center", fontsize=7, title="Display class")
    fig.suptitle(
        "Strict start-pausing evidence across five stress states versus WT-CTR",
        x=0.02,
        y=0.995,
        ha="left",
        fontweight="bold",
        fontsize=11,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    save_figure(fig, run / "02_figures/volcano/Fig1_strict_highlight_start_body_volcano")


def make_quadrant(run: Path, genes: pd.DataFrame, summary: pd.DataFrame) -> None:
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 5.5), sharex=True, sharey=True)
    axes = axes.flat

    for index, state in enumerate(TARGETS):
        ax = axes[index]
        current = genes[(genes["stress_state"] == state) & genes["pairwise_common_eligible"]]
        plotted = current[current["quadrant_point_plotted"]]
        other = plotted[~plotted["strict_PI_rPI_evidence"]]
        strict = plotted[plotted["strict_PI_rPI_evidence"]]

        draw_quadrant_points(ax, other, OTHER_COLOR, size=5, alpha=0.23, strict=False)
        draw_quadrant_points(ax, strict, STATE_COLOR[state], size=17, alpha=0.92, strict=True)
        ax.axvline(1, color="#666666", ls="--", lw=0.7, zorder=0)
        ax.axhline(1, color="#666666", ls="--", lw=0.7, zorder=0)
        ax.set_xlim(-6.25, 8.25)
        ax.set_ylim(-6.25, 12.25)
        ax.set_title(LABEL[state], color=STATE_COLOR[state], fontweight="bold")
        ax.set_xlabel("Relative pausing index, rPI (log2)")
        ax.set_ylabel("Pausing index, PI (log2)")

        stats = summary[summary["stress_state"] == state].iloc[0]
        ax.text(
            0.02,
            0.98,
            f"plotted={int(stats.quadrant_points_plotted):,}\nnot computable={int(stats.quadrant_not_computable):,}\nstrict={int(stats.strict_evidence_genes):,} ({percent_text(int(stats.strict_evidence_genes), int(stats.pairwise_common_genes))})",
            transform=ax.transAxes,
            va="top",
            fontsize=5.3,
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.82, pad=1),
            zorder=7,
        )
        if index == 0:
            panel(ax, "a")

    axes[5].axis("off")
    handles = [
        plt.Line2D([], [], marker="o", ls="", markerfacecolor=OTHER_COLOR, markeredgecolor="none", alpha=0.45, label="Other plottable genes"),
        plt.Line2D([], [], marker="o", ls="", markerfacecolor="white", markeredgecolor="black", label="Strict evidence\n(state colour)"),
        plt.Line2D([], [], marker=">", ls="", color="#666666", label="0 / Inf / clipped boundary"),
    ]
    axes[5].legend(handles=handles, loc="center", fontsize=7, title="Display class")
    axes[5].text(
        0.5,
        0.13,
        "Arrows point toward the true off-scale value.\nNA, 0/0 and Inf/Inf are counted but not plotted.",
        transform=axes[5].transAxes,
        ha="center",
        va="center",
        fontsize=6,
        color="#444444",
    )
    fig.suptitle(
        "Strict PI/rPI evidence highlighted against all plottable genes",
        x=0.02,
        y=0.995,
        ha="left",
        fontweight="bold",
        fontsize=11,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    save_figure(fig, run / "02_figures/quadrant/Fig2_strict_highlight_PI_rPI_quadrants")


def make_summary(run: Path, summary: pd.DataFrame) -> None:
    summary = summary.set_index("stress_state").loc[TARGETS].reset_index()
    x = np.arange(len(TARGETS))
    strict = summary["strict_evidence_genes"].to_numpy()
    other = summary["other_genes"].to_numpy()
    total = summary["pairwise_common_genes"].to_numpy()

    fig, ax = plt.subplots(figsize=(7.2, 3.25))
    for index, state in enumerate(TARGETS):
        ax.bar(index, strict[index], width=0.68, color=STATE_COLOR[state], edgecolor="none", zorder=3)
        ax.bar(index, other[index], bottom=strict[index], width=0.68, color=OTHER_COLOR, alpha=0.78, edgecolor="none", zorder=2)
        ax.text(
            index,
            total[index] + 125,
            f"strict {strict[index]:,}\n{percent_text(int(strict[index]), int(total[index]))}",
            ha="center",
            va="bottom",
            fontsize=6.5,
            color=STATE_COLOR[state],
            fontweight="bold",
        )
    ax.set_xticks(x, [LABEL[state] for state in TARGETS])
    ax.set_ylabel("Pairwise-common genes")
    ax.set_ylim(0, max(total) * 1.18)
    ax.set_title("Strict evidence remains a subset of the complete testable gene set", loc="left", fontweight="bold", fontsize=10)
    handles = [
        plt.Rectangle((0, 0), 1, 1, facecolor="white", edgecolor="black", label="Strict evidence (state colour)"),
        plt.Rectangle((0, 0), 1, 1, facecolor=OTHER_COLOR, alpha=0.78, edgecolor="none", label="Other pairwise-common genes"),
    ]
    ax.legend(handles=handles, loc="upper right", fontsize=7)
    panel(ax, "a")
    fig.tight_layout()
    save_figure(fig, run / "02_figures/summary/Fig3_strict_highlight_counts_and_proportions")


def write_audit(run: Path, volcano: pd.DataFrame, genes: pd.DataFrame, summary: pd.DataFrame) -> None:
    checks = []
    observed = dict(zip(summary["stress_state"], summary["strict_evidence_genes"].astype(int)))
    checks.append(("strict counts match frozen anchors", observed == EXPECTED_STRICT, str(observed)))
    checks.append(("volcano source retains all tested genes", len(volcano) == 25013, f"rows={len(volcano)}"))
    checks.append(("quadrant source retains all gene-state rows", len(genes) == 40700, f"rows={len(genes)}"))
    checks.append(
        (
            "all pairwise-common genes classified for display",
            genes.loc[genes.pairwise_common_eligible, "display_class"].isin(["strict", "other", "not_plotted"]).all(),
            f"rows={int(genes.pairwise_common_eligible.sum())}",
        )
    )
    checks.append(
        (
            "strict genes are pairwise-common and plotted",
            (genes.loc[genes.strict_PI_rPI_evidence, "pairwise_common_eligible"] & genes.loc[genes.strict_PI_rPI_evidence, "quadrant_point_plotted"]).all(),
            f"strict={int(genes.strict_PI_rPI_evidence.sum())}",
        )
    )
    checks.append(
        (
            "strict genes meet PI and rPI thresholds",
            (genes.loc[genes.strict_PI_rPI_evidence, "target_PI_ge_2"] & genes.loc[genes.strict_PI_rPI_evidence, "rPI_ge_2"]).all(),
            "all strict rows PI>=2 and rPI>=2",
        )
    )
    checks.append(
        (
            "non-strict genes not sampled",
            int((volcano.display_class == "other").sum() + (volcano.display_class == "strict").sum()) == len(volcano),
            "all volcano rows retained",
        )
    )
    checks.append(
        (
            "not-plotted quadrant rows have explicit reason",
            genes.loc[genes.display_class == "not_plotted", "display_reason"].notna().all(),
            f"not_plotted={int((genes.display_class == 'not_plotted').sum())}",
        )
    )
    audit = pd.DataFrame(
        [{"check": name, "status": "PASS" if passed else "FAIL", "evidence": evidence} for name, passed, evidence in checks]
    )
    audit.to_csv(run / "01_audit/numerical_and_display_audit.tsv", sep="\t", index=False)
    if audit["status"].eq("FAIL").any():
        raise SystemExit("Strict-highlight numerical/display audit failed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir")
    args = parser.parse_args()
    run = Path(args.run_dir).resolve()
    inputs = run / "00_input_links"

    volcano = pd.read_csv(inputs / "volcano_source_data.tsv", sep="\t", na_values=["NA"])
    genes = pd.read_csv(inputs / "gene_level_five_stress_PI_rPI_with_statistics.tsv", sep="\t", na_values=["NA"])
    volcano, genes, summary = prepare_source_data(run, volcano, genes)
    write_audit(run, volcano, genes, summary)
    make_volcano(run, volcano, summary)
    make_quadrant(run, genes, summary)
    make_summary(run, summary)

    with (run / "00_manifest/input_checksums.sha256").open("w", encoding="utf-8") as handle:
        for path in sorted(inputs.iterdir()):
            handle.write(f"{sha256(path.resolve())}  00_input_links/{path.name}\n")


if __name__ == "__main__":
    main()
